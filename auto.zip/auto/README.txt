1. Go to chrome://extensions in Google Chrome.
2. Toggle on the "Developer mode" toggle in the upper-right of the page.
3. Click the "Load unpacked" button in the upper-left of the page.
4. Navigate to the "app" folder you downloaded and click "Select Folder" to load it.
5. Disable the official version of shortfuts auto in the meantime so they don't collide.

This version will stop working on October 16.
