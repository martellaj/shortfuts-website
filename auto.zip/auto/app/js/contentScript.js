/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/contentScript.tsx");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function (useSourceMap) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item, useSourceMap);

      if (item[2]) {
        return '@media ' + item[2] + '{' + content + '}';
      } else {
        return content;
      }
    }).join('');
  }; // import a list of modules into the list


  list.i = function (modules, mediaQuery) {
    if (typeof modules === 'string') {
      modules = [[null, modules, '']];
    }

    var alreadyImportedModules = {};

    for (var i = 0; i < this.length; i++) {
      var id = this[i][0];

      if (id != null) {
        alreadyImportedModules[id] = true;
      }
    }

    for (i = 0; i < modules.length; i++) {
      var item = modules[i]; // skip already imported module
      // this implementation is not 100% perfect for weird media query combinations
      // when a module is imported multiple times with different media queries.
      // I hope this will never occur (Hey this way we have smaller bundles)

      if (item[0] == null || !alreadyImportedModules[item[0]]) {
        if (mediaQuery && !item[2]) {
          item[2] = mediaQuery;
        } else if (mediaQuery) {
          item[2] = '(' + item[2] + ') and (' + mediaQuery + ')';
        }

        list.push(item);
      }
    }
  };

  return list;
};

function cssWithMappingToString(item, useSourceMap) {
  var content = item[1] || '';
  var cssMapping = item[3];

  if (!cssMapping) {
    return content;
  }

  if (useSourceMap && typeof btoa === 'function') {
    var sourceMapping = toComment(cssMapping);
    var sourceURLs = cssMapping.sources.map(function (source) {
      return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */';
    });
    return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
  }

  return [content].join('\n');
} // Adapted from convert-source-map (MIT)


function toComment(sourceMap) {
  // eslint-disable-next-line no-undef
  var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
  var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;
  return '/*# ' + data + ' */';
}

/***/ }),

/***/ "./node_modules/css-modules-typescript-loader/index.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/sass-loader/lib/loader.js!./src/contentScript.scss":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-modules-typescript-loader!./node_modules/css-loader/dist/cjs.js??ref--5-2!./node_modules/sass-loader/lib/loader.js!./src/contentScript.scss ***!
  \**********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js")(false);
// Module
exports.push([module.i, "#_12f_qBdAf_c3g9osSLZec4,\n#_19jaCs7JmPI-XnVJ-LiEkE,\n#_31Fm_EkdWZhyuefUk8Kj4C,\n#_30ALGLrGGF_fZgDj5d6XOi {\n  display: none; }\n\n#_14VQM7xvac82mCTw8_t4Xb {\n  display: flex; }\n", ""]);

// Exports
exports.locals = {
	"audio": "_12f_qBdAf_c3g9osSLZec4",
	"loopDoneSound": "_19jaCs7JmPI-XnVJ-LiEkE",
	"cardSeenSound": "_31Fm_EkdWZhyuefUk8Kj4C",
	"cardPurchasedSound": "_30ALGLrGGF_fZgDj5d6XOi",
	"cleanupButton": "_14VQM7xvac82mCTw8_t4Xb"
};

/***/ }),

/***/ "./node_modules/style-loader/lib/addStyles.js":
/*!****************************************************!*\
  !*** ./node_modules/style-loader/lib/addStyles.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/

var stylesInDom = {};

var	memoize = function (fn) {
	var memo;

	return function () {
		if (typeof memo === "undefined") memo = fn.apply(this, arguments);
		return memo;
	};
};

var isOldIE = memoize(function () {
	// Test for IE <= 9 as proposed by Browserhacks
	// @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
	// Tests for existence of standard globals is to allow style-loader
	// to operate correctly into non-standard environments
	// @see https://github.com/webpack-contrib/style-loader/issues/177
	return window && document && document.all && !window.atob;
});

var getTarget = function (target) {
  return document.querySelector(target);
};

var getElement = (function (fn) {
	var memo = {};

	return function(target) {
                // If passing function in options, then use it for resolve "head" element.
                // Useful for Shadow Root style i.e
                // {
                //   insertInto: function () { return document.querySelector("#foo").shadowRoot }
                // }
                if (typeof target === 'function') {
                        return target();
                }
                if (typeof memo[target] === "undefined") {
			var styleTarget = getTarget.call(this, target);
			// Special case to return head of iframe instead of iframe itself
			if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
				try {
					// This will throw an exception if access to iframe is blocked
					// due to cross-origin restrictions
					styleTarget = styleTarget.contentDocument.head;
				} catch(e) {
					styleTarget = null;
				}
			}
			memo[target] = styleTarget;
		}
		return memo[target]
	};
})();

var singleton = null;
var	singletonCounter = 0;
var	stylesInsertedAtTop = [];

var	fixUrls = __webpack_require__(/*! ./urls */ "./node_modules/style-loader/lib/urls.js");

module.exports = function(list, options) {
	if (typeof DEBUG !== "undefined" && DEBUG) {
		if (typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
	}

	options = options || {};

	options.attrs = typeof options.attrs === "object" ? options.attrs : {};

	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	if (!options.singleton && typeof options.singleton !== "boolean") options.singleton = isOldIE();

	// By default, add <style> tags to the <head> element
        if (!options.insertInto) options.insertInto = "head";

	// By default, add <style> tags to the bottom of the target
	if (!options.insertAt) options.insertAt = "bottom";

	var styles = listToStyles(list, options);

	addStylesToDom(styles, options);

	return function update (newList) {
		var mayRemove = [];

		for (var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];

			domStyle.refs--;
			mayRemove.push(domStyle);
		}

		if(newList) {
			var newStyles = listToStyles(newList, options);
			addStylesToDom(newStyles, options);
		}

		for (var i = 0; i < mayRemove.length; i++) {
			var domStyle = mayRemove[i];

			if(domStyle.refs === 0) {
				for (var j = 0; j < domStyle.parts.length; j++) domStyle.parts[j]();

				delete stylesInDom[domStyle.id];
			}
		}
	};
};

function addStylesToDom (styles, options) {
	for (var i = 0; i < styles.length; i++) {
		var item = styles[i];
		var domStyle = stylesInDom[item.id];

		if(domStyle) {
			domStyle.refs++;

			for(var j = 0; j < domStyle.parts.length; j++) {
				domStyle.parts[j](item.parts[j]);
			}

			for(; j < item.parts.length; j++) {
				domStyle.parts.push(addStyle(item.parts[j], options));
			}
		} else {
			var parts = [];

			for(var j = 0; j < item.parts.length; j++) {
				parts.push(addStyle(item.parts[j], options));
			}

			stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
		}
	}
}

function listToStyles (list, options) {
	var styles = [];
	var newStyles = {};

	for (var i = 0; i < list.length; i++) {
		var item = list[i];
		var id = options.base ? item[0] + options.base : item[0];
		var css = item[1];
		var media = item[2];
		var sourceMap = item[3];
		var part = {css: css, media: media, sourceMap: sourceMap};

		if(!newStyles[id]) styles.push(newStyles[id] = {id: id, parts: [part]});
		else newStyles[id].parts.push(part);
	}

	return styles;
}

function insertStyleElement (options, style) {
	var target = getElement(options.insertInto)

	if (!target) {
		throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");
	}

	var lastStyleElementInsertedAtTop = stylesInsertedAtTop[stylesInsertedAtTop.length - 1];

	if (options.insertAt === "top") {
		if (!lastStyleElementInsertedAtTop) {
			target.insertBefore(style, target.firstChild);
		} else if (lastStyleElementInsertedAtTop.nextSibling) {
			target.insertBefore(style, lastStyleElementInsertedAtTop.nextSibling);
		} else {
			target.appendChild(style);
		}
		stylesInsertedAtTop.push(style);
	} else if (options.insertAt === "bottom") {
		target.appendChild(style);
	} else if (typeof options.insertAt === "object" && options.insertAt.before) {
		var nextSibling = getElement(options.insertInto + " " + options.insertAt.before);
		target.insertBefore(style, nextSibling);
	} else {
		throw new Error("[Style Loader]\n\n Invalid value for parameter 'insertAt' ('options.insertAt') found.\n Must be 'top', 'bottom', or Object.\n (https://github.com/webpack-contrib/style-loader#insertat)\n");
	}
}

function removeStyleElement (style) {
	if (style.parentNode === null) return false;
	style.parentNode.removeChild(style);

	var idx = stylesInsertedAtTop.indexOf(style);
	if(idx >= 0) {
		stylesInsertedAtTop.splice(idx, 1);
	}
}

function createStyleElement (options) {
	var style = document.createElement("style");

	options.attrs.type = "text/css";

	addAttrs(style, options.attrs);
	insertStyleElement(options, style);

	return style;
}

function createLinkElement (options) {
	var link = document.createElement("link");

	options.attrs.type = "text/css";
	options.attrs.rel = "stylesheet";

	addAttrs(link, options.attrs);
	insertStyleElement(options, link);

	return link;
}

function addAttrs (el, attrs) {
	Object.keys(attrs).forEach(function (key) {
		el.setAttribute(key, attrs[key]);
	});
}

function addStyle (obj, options) {
	var style, update, remove, result;

	// If a transform function was defined, run it on the css
	if (options.transform && obj.css) {
	    result = options.transform(obj.css);

	    if (result) {
	    	// If transform returns a value, use that instead of the original css.
	    	// This allows running runtime transformations on the css.
	    	obj.css = result;
	    } else {
	    	// If the transform function returns a falsy value, don't add this css.
	    	// This allows conditional loading of css
	    	return function() {
	    		// noop
	    	};
	    }
	}

	if (options.singleton) {
		var styleIndex = singletonCounter++;

		style = singleton || (singleton = createStyleElement(options));

		update = applyToSingletonTag.bind(null, style, styleIndex, false);
		remove = applyToSingletonTag.bind(null, style, styleIndex, true);

	} else if (
		obj.sourceMap &&
		typeof URL === "function" &&
		typeof URL.createObjectURL === "function" &&
		typeof URL.revokeObjectURL === "function" &&
		typeof Blob === "function" &&
		typeof btoa === "function"
	) {
		style = createLinkElement(options);
		update = updateLink.bind(null, style, options);
		remove = function () {
			removeStyleElement(style);

			if(style.href) URL.revokeObjectURL(style.href);
		};
	} else {
		style = createStyleElement(options);
		update = applyToTag.bind(null, style);
		remove = function () {
			removeStyleElement(style);
		};
	}

	update(obj);

	return function updateStyle (newObj) {
		if (newObj) {
			if (
				newObj.css === obj.css &&
				newObj.media === obj.media &&
				newObj.sourceMap === obj.sourceMap
			) {
				return;
			}

			update(obj = newObj);
		} else {
			remove();
		}
	};
}

var replaceText = (function () {
	var textStore = [];

	return function (index, replacement) {
		textStore[index] = replacement;

		return textStore.filter(Boolean).join('\n');
	};
})();

function applyToSingletonTag (style, index, remove, obj) {
	var css = remove ? "" : obj.css;

	if (style.styleSheet) {
		style.styleSheet.cssText = replaceText(index, css);
	} else {
		var cssNode = document.createTextNode(css);
		var childNodes = style.childNodes;

		if (childNodes[index]) style.removeChild(childNodes[index]);

		if (childNodes.length) {
			style.insertBefore(cssNode, childNodes[index]);
		} else {
			style.appendChild(cssNode);
		}
	}
}

function applyToTag (style, obj) {
	var css = obj.css;
	var media = obj.media;

	if(media) {
		style.setAttribute("media", media)
	}

	if(style.styleSheet) {
		style.styleSheet.cssText = css;
	} else {
		while(style.firstChild) {
			style.removeChild(style.firstChild);
		}

		style.appendChild(document.createTextNode(css));
	}
}

function updateLink (link, options, obj) {
	var css = obj.css;
	var sourceMap = obj.sourceMap;

	/*
		If convertToAbsoluteUrls isn't defined, but sourcemaps are enabled
		and there is no publicPath defined then lets turn convertToAbsoluteUrls
		on by default.  Otherwise default to the convertToAbsoluteUrls option
		directly
	*/
	var autoFixUrls = options.convertToAbsoluteUrls === undefined && sourceMap;

	if (options.convertToAbsoluteUrls || autoFixUrls) {
		css = fixUrls(css);
	}

	if (sourceMap) {
		// http://stackoverflow.com/a/26603875
		css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
	}

	var blob = new Blob([css], { type: "text/css" });

	var oldSrc = link.href;

	link.href = URL.createObjectURL(blob);

	if(oldSrc) URL.revokeObjectURL(oldSrc);
}


/***/ }),

/***/ "./node_modules/style-loader/lib/urls.js":
/*!***********************************************!*\
  !*** ./node_modules/style-loader/lib/urls.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {


/**
 * When source maps are enabled, `style-loader` uses a link element with a data-uri to
 * embed the css on the page. This breaks all relative urls because now they are relative to a
 * bundle instead of the current page.
 *
 * One solution is to only use full urls, but that may be impossible.
 *
 * Instead, this function "fixes" the relative urls to be absolute according to the current page location.
 *
 * A rudimentary test suite is located at `test/fixUrls.js` and can be run via the `npm test` command.
 *
 */

module.exports = function (css) {
  // get current location
  var location = typeof window !== "undefined" && window.location;

  if (!location) {
    throw new Error("fixUrls requires window.location");
  }

	// blank or null?
	if (!css || typeof css !== "string") {
	  return css;
  }

  var baseUrl = location.protocol + "//" + location.host;
  var currentDir = baseUrl + location.pathname.replace(/\/[^\/]*$/, "/");

	// convert each url(...)
	/*
	This regular expression is just a way to recursively match brackets within
	a string.

	 /url\s*\(  = Match on the word "url" with any whitespace after it and then a parens
	   (  = Start a capturing group
	     (?:  = Start a non-capturing group
	         [^)(]  = Match anything that isn't a parentheses
	         |  = OR
	         \(  = Match a start parentheses
	             (?:  = Start another non-capturing groups
	                 [^)(]+  = Match anything that isn't a parentheses
	                 |  = OR
	                 \(  = Match a start parentheses
	                     [^)(]*  = Match anything that isn't a parentheses
	                 \)  = Match a end parentheses
	             )  = End Group
              *\) = Match anything and then a close parens
          )  = Close non-capturing group
          *  = Match anything
       )  = Close capturing group
	 \)  = Match a close parens

	 /gi  = Get all matches, not the first.  Be case insensitive.
	 */
	var fixedCss = css.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi, function(fullMatch, origUrl) {
		// strip quotes (if they exist)
		var unquotedOrigUrl = origUrl
			.trim()
			.replace(/^"(.*)"$/, function(o, $1){ return $1; })
			.replace(/^'(.*)'$/, function(o, $1){ return $1; });

		// already a full url? no change
		if (/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/|\s*$)/i.test(unquotedOrigUrl)) {
		  return fullMatch;
		}

		// convert the url to a full url
		var newUrl;

		if (unquotedOrigUrl.indexOf("//") === 0) {
		  	//TODO: should we add protocol?
			newUrl = unquotedOrigUrl;
		} else if (unquotedOrigUrl.indexOf("/") === 0) {
			// path should be relative to the base url
			newUrl = baseUrl + unquotedOrigUrl; // already starts with '/'
		} else {
			// path should be relative to current directory
			newUrl = currentDir + unquotedOrigUrl.replace(/^\.\//, ""); // Strip leading './'
		}

		// send back the fixed url(...)
		return "url(" + JSON.stringify(newUrl) + ")";
	});

	// send back the fixed css
	return fixedCss;
};


/***/ }),

/***/ "./src/actions/back.ts":
/*!*****************************!*\
  !*** ./src/actions/back.ts ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var getListItems_1 = __importDefault(__webpack_require__(/*! ./helpers/getListItems */ "./src/actions/helpers/getListItems.ts"));
var isUserOnSearchResultsPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchResultsPage */ "./src/actions/helpers/isUserOnSearchResultsPage.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
var isUserOnTransfersPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnTransfersPage */ "./src/actions/helpers/isUserOnTransfersPage.ts"));
var isUserOnTransferTargetsPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnTransferTargetsPage */ "./src/actions/helpers/isUserOnTransferTargetsPage.ts"));
var isUserOnUnassignedPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnUnassignedPage */ "./src/actions/helpers/isUserOnUnassignedPage.ts"));
function goBack() {
    // Prioritizes back button in secondary nav.
    var secondaryHeader = document.getElementsByClassName("navbar-style-secondary")[0];
    if (secondaryHeader && secondaryHeader.getElementsByTagName("button")[0]) {
        clickElement_1.default(secondaryHeader.getElementsByTagName("button")[0]);
        return;
    }
    // Falls back to primary nav back button.
    if (isUserOnSearchTransferMarketPage_1.default() ||
        isUserOnSearchResultsPage_1.default() ||
        isUserOnUnassignedPage_1.default() ||
        isUserOnTransfersPage_1.default() ||
        isUserOnTransferTargetsPage_1.default()) {
        if (isUserOnSearchResultsPage_1.default()) {
            var hasSearchResults = getListItems_1.default().length > 0;
            // If there are no results, we'll go back regardless.
            if (!hasSearchResults) {
                clickElement_1.default(document.getElementsByClassName("ut-navigation-button-control")[0]);
                return;
            }
            // If there are results, check setting and if last search was less than 2.5 seconds ago.
            chrome.storage.sync.get(["lastSearchTime", "disableBack"], function (data) {
                var lastSearchTime = data.lastSearchTime, disableBack = data.disableBack;
                var now = Date.now();
                var timeSinceSearch = now - (lastSearchTime || 0);
                if (timeSinceSearch < 2500 && disableBack) {
                    return;
                }
                else {
                    clickElement_1.default(document.getElementsByClassName("ut-navigation-button-control")[0]);
                }
            });
        }
        else {
            clickElement_1.default(document.getElementsByClassName("ut-navigation-button-control")[0]);
        }
    }
}
exports.default = goBack;


/***/ }),

/***/ "./src/actions/buyNow.ts":
/*!*******************************!*\
  !*** ./src/actions/buyNow.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var confirmConfirmationDialog_1 = __importDefault(__webpack_require__(/*! ./helpers/confirmConfirmationDialog */ "./src/actions/helpers/confirmConfirmationDialog.ts"));
var isUserOnSearchResultsPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchResultsPage */ "./src/actions/helpers/isUserOnSearchResultsPage.ts"));
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
function buyNow() {
    if (isUserOnSearchResultsPage_1.default()) {
        try {
            buyCard();
        }
        catch (error) { }
    }
}
exports.default = buyNow;
function buyCard() {
    clickBuyNowButton();
    var timer = setInterval(function () {
        confirmConfirmationDialog_1.default(function () {
            clearInterval(timer);
        });
    }, 0);
}
function clickBuyNowButton() {
    var button = document.getElementsByClassName("buyButton")[0];
    clickElement_1.default(button);
}


/***/ }),

/***/ "./src/actions/decreaseMaxBinPrice.ts":
/*!********************************************!*\
  !*** ./src/actions/decreaseMaxBinPrice.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
function decreaseMaxBinPrice() {
    if (isUserOnSearchTransferMarketPage_1.default()) {
        var button = document.getElementsByClassName("decrement-value")[3];
        clickElement_1.default(button);
    }
}
exports.default = decreaseMaxBinPrice;


/***/ }),

/***/ "./src/actions/helpers/clickDetailsPanelButton.ts":
/*!********************************************************!*\
  !*** ./src/actions/helpers/clickDetailsPanelButton.ts ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./clickElement */ "./src/actions/helpers/clickElement.ts"));
function clickDetailsPanelButton(buttonLabel) {
    try {
        // Expand "List on Transfer Market" section.
        if (buttonLabel === "List Item") {
            var _buttons = document.getElementsByTagName("button");
            var buttons = Array.from(_buttons);
            for (var _i = 0, buttons_1 = buttons; _i < buttons_1.length; _i++) {
                var button = buttons_1[_i];
                if (button &&
                    button.innerHTML.indexOf("List on Transfer Market") > -1) {
                    clickElement_1.default(button);
                    setTimeout(function () {
                        // Get buttons in the details panel.
                        var detailsPanel = document.getElementsByClassName("DetailPanel")[0];
                        var detailsPanelButtons = detailsPanel.getElementsByTagName("button");
                        var buttonArray = Array.from(detailsPanelButtons);
                        // Find target button by searching by label.
                        var _button = buttonArray.filter(function (__button) {
                            return __button.innerHTML.indexOf(buttonLabel) > -1 &&
                                __button.style.display !== "none";
                        })[0];
                        // Click target button.
                        clickElement_1.default(_button);
                    }, 1000);
                    return;
                }
            }
        }
        // Get buttons in the details panel.
        var detailsPanel = document.getElementsByClassName("DetailPanel")[0];
        var detailsPanelButtons = detailsPanel.getElementsByTagName("button");
        var buttonArray = Array.from(detailsPanelButtons);
        // Find target button by searching by label.
        var _button = buttonArray.filter(function (foo) {
            return foo.innerHTML.indexOf(buttonLabel) > -1 &&
                foo.style.display !== "none";
        })[0];
        // Click target button.
        clickElement_1.default(_button);
    }
    catch (error) {
        throw "Unable to find that button.";
    }
}
exports.default = clickDetailsPanelButton;


/***/ }),

/***/ "./src/actions/helpers/clickElement.ts":
/*!*********************************************!*\
  !*** ./src/actions/helpers/clickElement.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Simulates a click on an element.
 */
function clickElement(element) {
    sendTouchEvent(element, 'touchstart');
    sendTouchEvent(element, 'touchend');
}
exports.default = clickElement;
/**
 * Dispatches a touch event on the element.
 * https://stackoverflow.com/a/42447620
 *
 * @param {HTMLElement} element
 * @param {string} eventType
 */
function sendTouchEvent(element, eventType) {
    /**
     * Touch constructor does take an object in Chrome, but typings aren't updated,
     * so it shows as an error when in reality it's fine.
     */
    // @ts-ignore
    var touch = new Touch({
        // Using a number like TS suggest breaks this... stupid.
        // @ts-ignore
        identifier: Math.random().toString(),
        target: element,
        clientX: Math.random(),
        clientY: Math.random(),
        radiusX: 2.5,
        radiusY: 2.5,
        rotationAngle: 10,
        force: 0.5
    });
    var touchEvent = new TouchEvent(eventType, {
        cancelable: true,
        bubbles: true,
        touches: [touch],
        targetTouches: [touch],
        changedTouches: [touch],
        shiftKey: true
    });
    element.dispatchEvent(touchEvent);
}


/***/ }),

/***/ "./src/actions/helpers/confirmConfirmationDialog.ts":
/*!**********************************************************!*\
  !*** ./src/actions/helpers/confirmConfirmationDialog.ts ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./clickElement */ "./src/actions/helpers/clickElement.ts"));
/**
 * Presses "OK" button in confirmation dialog.
 */
function confirmConfirmationDialog(success) {
    try {
        var okButton = document
            .getElementsByClassName("Dialog")[0]
            .getElementsByTagName("button")[0];
        clickElement_1.default(okButton);
        success && success();
    }
    catch (error) { }
}
exports.default = confirmConfirmationDialog;


/***/ }),

/***/ "./src/actions/helpers/getListItemButtonText.ts":
/*!******************************************************!*\
  !*** ./src/actions/helpers/getListItemButtonText.ts ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function getListItemButtonText() {
    var buttonText = "List for Transfer";
    var language = document.getElementsByTagName("html")[0].lang;
    switch (language) {
        case "fr":
            buttonText = "Placer sur liste des transferts";
            break;
        case "it":
            buttonText = "Metti sul mercato";
            break;
        case "de":
            buttonText = "Anbieten";
            break;
        case "pl":
            buttonText = "Wystaw na licytację";
            break;
        case "nl":
            buttonText = "Op transferlijst plaatsen";
            break;
        case "pt":
            buttonText = "Listar para transferência";
            break;
        case "es":
            buttonText = "Añadir a transferibles";
            break;
        case "ru":
            buttonText = "Выставить на продажу";
            break;
        case "tr":
            buttonText = "Transfer için Listele";
            break;
        case "ko":
            buttonText = "이적 목록에 올리기";
            break;
        case "da":
            buttonText = "Sæt på transferlisten";
            break;
    }
    return buttonText;
}
exports.default = getListItemButtonText;


/***/ }),

/***/ "./src/actions/helpers/getListItems.ts":
/*!*********************************************!*\
  !*** ./src/actions/helpers/getListItems.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var isUserOnSearchResultsPage_1 = __importDefault(__webpack_require__(/*! ./isUserOnSearchResultsPage */ "./src/actions/helpers/isUserOnSearchResultsPage.ts"));
var isUserOnUnassignedPage_1 = __importDefault(__webpack_require__(/*! ./isUserOnUnassignedPage */ "./src/actions/helpers/isUserOnUnassignedPage.ts"));
var isUserOnTransfersPage_1 = __importDefault(__webpack_require__(/*! ./isUserOnTransfersPage */ "./src/actions/helpers/isUserOnTransfersPage.ts"));
function getListItems() {
    var items = [];
    if (isUserOnSearchResultsPage_1.default()) {
        var itemList = document.getElementsByClassName("paginated-item-list")[0];
        items = Array.from(itemList.getElementsByClassName("listFUTItem"));
    }
    else if (isUserOnUnassignedPage_1.default() || isUserOnTransfersPage_1.default()) {
        var itemLists = Array.from(document.getElementsByClassName("itemList"));
        itemLists.forEach(function (itemList) {
            items = items.concat(Array.from(itemList.getElementsByClassName("listFUTItem")));
        }, this);
    }
    else {
        var itemList = document.getElementsByClassName("paginated-item-list")[0];
        items = Array.from(itemList.getElementsByClassName("listFUTItem"));
    }
    return items;
}
exports.default = getListItems;


/***/ }),

/***/ "./src/actions/helpers/isUserOnPage.ts":
/*!*********************************************!*\
  !*** ./src/actions/helpers/isUserOnPage.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Checks if user is on specific page.
 */
function isUserOnPage(pageTitle) {
    var title = document.getElementsByClassName('title')[0];
    return title && title.innerHTML === pageTitle;
}
exports.default = isUserOnPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnSearchResultsPage.ts":
/*!**********************************************************!*\
  !*** ./src/actions/helpers/isUserOnSearchResultsPage.ts ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isUserOnSearchResultsPage() {
    var elements = document.getElementsByClassName("SearchResults");
    return elements.length > 0;
}
exports.default = isUserOnSearchResultsPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts":
/*!*****************************************************************!*\
  !*** ./src/actions/helpers/isUserOnSearchTransferMarketPage.ts ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isUserOnSearchTransferMarketPage() {
    var elements = document.getElementsByClassName("ut-market-search-filters-view");
    var sbcElement = document.getElementsByClassName("sbc");
    return elements.length > 0 && sbcElement.length === 0;
}
exports.default = isUserOnSearchTransferMarketPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnTransferTargetsPage.ts":
/*!************************************************************!*\
  !*** ./src/actions/helpers/isUserOnTransferTargetsPage.ts ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isUserOnTransferTargetsPage() {
    var elements = document.getElementsByClassName("ut-watch-list-view");
    return elements.length > 0;
}
exports.default = isUserOnTransferTargetsPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnTransfersPage.ts":
/*!******************************************************!*\
  !*** ./src/actions/helpers/isUserOnTransfersPage.ts ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isUserOnTransfersPage() {
    var elements = document.getElementsByClassName("ut-transfer-list-view");
    return elements.length > 0;
}
exports.default = isUserOnTransfersPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnUnassignedPage.ts":
/*!*******************************************************!*\
  !*** ./src/actions/helpers/isUserOnUnassignedPage.ts ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var isUserOnPage_1 = __importDefault(__webpack_require__(/*! ./isUserOnPage */ "./src/actions/helpers/isUserOnPage.ts"));
function isUserOnUnassignedPage() {
    return (
    // English
    isUserOnPage_1.default("Unassigned") ||
        // French
        isUserOnPage_1.default("NON ATTRIBUÉS") ||
        // Italian
        isUserOnPage_1.default("NON ASSEGNATI") ||
        // German
        isUserOnPage_1.default("NICHT ZUGEWIESEN") ||
        // Polish
        isUserOnPage_1.default("Nieprzypisane") ||
        // Dutch
        isUserOnPage_1.default("NIET TOEGEWEZ.") ||
        // Portuguese
        isUserOnPage_1.default("Não Atribuídos") ||
        // Spanish
        isUserOnPage_1.default("No asignados") ||
        // Russian
        isUserOnPage_1.default("Не назначено") ||
        // Turkish
        isUserOnPage_1.default("Atanmayan") ||
        // Korean
        isUserOnPage_1.default("지정되지 않음"));
}
exports.default = isUserOnUnassignedPage;


/***/ }),

/***/ "./src/actions/increaseMaxBinPrice.ts":
/*!********************************************!*\
  !*** ./src/actions/increaseMaxBinPrice.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
function increaseMaxBinPrice() {
    if (isUserOnSearchTransferMarketPage_1.default()) {
        var button = document.getElementsByClassName("increment-value")[3];
        clickElement_1.default(button);
    }
}
exports.default = increaseMaxBinPrice;


/***/ }),

/***/ "./src/actions/increaseMinBidPrice.ts":
/*!********************************************!*\
  !*** ./src/actions/increaseMinBidPrice.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
function increaseMinBidPrice() {
    var button = document.getElementsByClassName("increment-value")[0];
    clickElement_1.default(button);
}
exports.default = increaseMinBidPrice;


/***/ }),

/***/ "./src/actions/increaseMinBinPrice.ts":
/*!********************************************!*\
  !*** ./src/actions/increaseMinBinPrice.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
function increaseMinBinPrice() {
    if (isUserOnSearchTransferMarketPage_1.default()) {
        var button = document.getElementsByClassName("increment-value")[2];
        clickElement_1.default(button);
    }
}
exports.default = increaseMinBinPrice;


/***/ }),

/***/ "./src/actions/list.ts":
/*!*****************************!*\
  !*** ./src/actions/list.ts ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var getListItemButtonText_1 = __importDefault(__webpack_require__(/*! ./helpers/getListItemButtonText */ "./src/actions/helpers/getListItemButtonText.ts"));
function list(startPrice, buyNowPrice) {
    var quickListPanel = document.getElementsByClassName("DetailPanel")[0];
    var quickListPanelActions = quickListPanel.getElementsByClassName("panelActions")[0];
    var actionRows = quickListPanelActions.getElementsByClassName("panelActionRow");
    if (startPrice) {
        var startPriceRow = actionRows[1];
        var startPriceInput = startPriceRow.getElementsByTagName("input")[0];
        startPriceInput.value = startPrice;
    }
    if (buyNowPrice) {
        var binRow = actionRows[2];
        var binInput = binRow.getElementsByTagName("input")[0];
        binInput.value = buyNowPrice.toString();
    }
    // Get all buttons in "List on Transfer Market" section.
    var _buttons = quickListPanelActions.getElementsByTagName("button");
    var buttons = Array.from(_buttons);
    // Find button with "List Item" as text and tap it.
    var listItemButton;
    var buttonText = getListItemButtonText_1.default();
    for (var _i = 0, buttons_1 = buttons; _i < buttons_1.length; _i++) {
        var button = buttons_1[_i];
        if (button && button.innerHTML === buttonText) {
            listItemButton = button;
        }
    }
    clickElement_1.default(listItemButton);
}
exports.default = list;


/***/ }),

/***/ "./src/actions/search.ts":
/*!*******************************!*\
  !*** ./src/actions/search.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var buyNow_1 = __importDefault(__webpack_require__(/*! ./buyNow */ "./src/actions/buyNow.ts"));
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var getListItems_1 = __importDefault(__webpack_require__(/*! ./helpers/getListItems */ "./src/actions/helpers/getListItems.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
var contentScript_scss_1 = __importDefault(__webpack_require__(/*! ../contentScript.scss */ "./src/contentScript.scss"));
var dangerousInterval = null;
var globalIntervalId = 0;
function search(doHandsfreeBin) {
    if (!isUserOnSearchTransferMarketPage_1.default()) {
        return;
    }
    // Clear interval when new search is happening.
    clearDangerousInterval();
    var searchButton = document.getElementsByClassName("btn-standard call-to-action")[0];
    clickElement_1.default(searchButton);
    var oldSearchCount = window.localStorage.getItem("searchCount");
    var newSearchCount = oldSearchCount ? parseInt(oldSearchCount) + 1 : 1;
    window.localStorage.setItem("searchCount", newSearchCount.toString());
    if (newSearchCount === 1) {
        chrome.storage.sync.get(["discordWebhookCardSeen"], function (data) {
            if (data.discordWebhookCardSeen) {
                // TODO: Add "started" message when we do logging
            }
        });
    }
    // incremement ID to track new interval
    globalIntervalId = globalIntervalId + 1;
    var iterationId = globalIntervalId;
    dangerousInterval = setInterval(function () {
        try {
            var hasSearchResults = getListItems_1.default().length > 0;
            var isNoResultsPage = document.getElementsByClassName("ut-no-results-view").length > 0;
            if (hasSearchResults || isNoResultsPage) {
                try {
                    var items = getListItems_1.default();
                    clickElement_1.default(items[items.length - 1].getElementsByClassName("has-tap-callback")[0]);
                }
                catch (error) { }
                if (doHandsfreeBin) {
                    setTimeout(function () {
                        handsfreeBin();
                    }, 50);
                }
                // Clear interval once search has completed.
                clearDangerousInterval();
            }
        }
        catch (e) { }
    }, 0);
    // clear dangerous timer after a few seconds
    setTimeout(function () {
        clearDangerousInterval(iterationId);
    }, 3500);
}
exports.default = search;
var handsfreeBin = function () {
    try {
        var isBuyButtonPresent = document.getElementsByClassName("buyButton").length > 0;
        if (isBuyButtonPresent) {
            buyNow_1.default();
            // increments seen count
            var oldCount = window.localStorage.getItem("seenCount");
            var newCount = oldCount ? parseInt(oldCount) + 1 : 1;
            window.localStorage.setItem("seenCount", newCount.toString());
            // notes that we just saw a card for "card purchased" count
            window.localStorage.setItem("justSawCard", "true");
            chrome.storage.sync.get(["shouldPlayResultSeenSound", "discordWebhookCardSeen"], function (data) {
                if (data.shouldPlayResultSeenSound) {
                    var cardSeenSound = document.getElementById(contentScript_scss_1.default.cardSeenSound);
                    cardSeenSound.play();
                }
                if (data.discordWebhookCardSeen) {
                    fetch_retry(data.discordWebhookCardSeen, {
                        method: "POST",
                        body: JSON.stringify({
                            content: "A card popped up",
                        }),
                        headers: {
                            "Content-Type": "application/json",
                        },
                    }, 5);
                }
            });
        }
    }
    catch (e) { }
};
/**
 * clear timer if no ID is passed or if ID matches global
 */
var clearDangerousInterval = function (intervalId) {
    if (!intervalId || intervalId === globalIntervalId) {
        clearInterval(dangerousInterval);
    }
};
var fetch_retry = function (url, options, n) {
    return fetch(url, options).catch(function (error) {
        if (n === 1)
            throw error;
        return fetch_retry(url, options, n - 1);
    });
};


/***/ }),

/***/ "./src/actions/sendToTransferList.ts":
/*!*******************************************!*\
  !*** ./src/actions/sendToTransferList.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickDetailsPanelButton_1 = __importDefault(__webpack_require__(/*! ./helpers/clickDetailsPanelButton */ "./src/actions/helpers/clickDetailsPanelButton.ts"));
function sendToTransferList() {
    var buttonText = "Send to Transfer List";
    var language = document.getElementsByTagName("html")[0].lang;
    switch (language) {
        case "fr":
            buttonText = "Env. Liste transf.";
            break;
        case "it":
            buttonText = "Invia a trasferim.";
            break;
        case "de":
            buttonText = "Auf Transferliste";
            break;
        case "pl":
            buttonText = "Wyślij na listę transferową";
            break;
        case "nl":
            buttonText = "Naar transferlijst";
            break;
        case "pt":
            buttonText = "Enviar para Transfer.";
            break;
        case "es":
            buttonText = "Enviar a transferibles";
            break;
        case "ru":
            buttonText = "Отправить в список продаж";
            break;
        case "tr":
            buttonText = "Transfer Listesi’ne Gönder";
            break;
        case "ko":
            buttonText = "이적 목록으로 보내기";
            break;
        case "da":
            buttonText = "Send til transferlisten";
            break;
    }
    try {
        clickDetailsPanelButton_1.default(buttonText);
    }
    catch (error) { }
}
exports.default = sendToTransferList;


/***/ }),

/***/ "./src/actions/storeInClub.ts":
/*!************************************!*\
  !*** ./src/actions/storeInClub.ts ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickDetailsPanelButton_1 = __importDefault(__webpack_require__(/*! ./helpers/clickDetailsPanelButton */ "./src/actions/helpers/clickDetailsPanelButton.ts"));
function storeInClub() {
    var buttonText = "Send to My Club";
    var language = document.getElementsByTagName("html")[0].lang;
    switch (language) {
        case "fr":
            buttonText = "Envoyer vers Mon club";
            break;
        case "it":
            buttonText = "Invia a Il mio club";
            break;
        case "de":
            buttonText = "Zu Mein Verein";
            break;
        case "pl":
            buttonText = "Wyślij do klubu";
            break;
        case "nl":
            buttonText = "Naar Mijn club sturen";
            break;
        case "pt":
            buttonText = "Enviar ao Meu clube";
            break;
        case "es":
            buttonText = "Enviar a Mi club";
            break;
        case "ru":
            buttonText = "Отправить в Мой клуб";
            break;
        case "tr":
            buttonText = "Kulübüme Gönder";
            break;
        case "ko":
            buttonText = "내 클럽으로 보내기";
            break;
        case "da":
            buttonText = "Send til Min klub";
            break;
    }
    try {
        clickDetailsPanelButton_1.default(buttonText);
    }
    catch (error) {
        //
    }
}
exports.default = storeInClub;


/***/ }),

/***/ "./src/bidder.ts":
/*!***********************!*\
  !*** ./src/bidder.ts ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cleanupTransferTargets = void 0;
var clickElement_1 = __importDefault(__webpack_require__(/*! ./actions/helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var isUserOnTransferTargetsPage_1 = __importDefault(__webpack_require__(/*! ./actions/helpers/isUserOnTransferTargetsPage */ "./src/actions/helpers/isUserOnTransferTargetsPage.ts"));
var contentScript_1 = __webpack_require__(/*! ./contentScript */ "./src/contentScript.tsx");
var pageFlipperTimer = null;
var bidderTimer = null;
function startBidder(maxBidAmount, duration, shouldBidMax) {
    // note that bidder is running
    localStorage.setItem("bidder", "on");
    bidderTimer = setTimeout(function () {
        stopBidder("Bot stopped because it ran for " + duration + " minutes.");
    }, duration * 60000);
    // set max bid to user's preference
    document.getElementsByClassName("numericInput")[1].value = maxBidAmount.toString();
    // click buttons to lock it in
    clickElement_1.default(document.getElementsByClassName("increment-value")[1]);
    clickElement_1.default(document.getElementsByClassName("decrement-value")[1]);
    clickElement_1.default(document.getElementsByClassName("decrement-value")[1]);
    // set max BIN to 15,000,000
    document.getElementsByClassName("numericInput")[3].value = "14999999";
    // click increment button to lock it in
    var incrementButton = document.getElementsByClassName("increment-value")[3];
    clickElement_1.default(incrementButton);
    // let's do it
    doWork(maxBidAmount, shouldBidMax);
}
exports.default = startBidder;
function doWork(maxBidAmount, shouldBidMax) {
    // decrement max BIN to get fresh results
    var decrementButton = document.getElementsByClassName("decrement-value")[3];
    clickElement_1.default(decrementButton);
    // execute a search
    var searchButton = document.getElementsByClassName("btn-standard call-to-action")[0];
    clickElement_1.default(searchButton);
    // bid on search results
    bidOnSearchResults(maxBidAmount, shouldBidMax);
}
var bidOnSearchResults = function (maxBidAmount, shouldBidMax) {
    // check if bot has been stopped
    if (localStorage.getItem("bidder") === "off") {
        clearTimeout(pageFlipperTimer);
        pageFlipperTimer = null;
        return;
    }
    // get items (allow time for search to finish)
    setTimeout(function () {
        var itemList = document.getElementsByClassName("paginated-item-list")[0];
        var items = Array.from(itemList.getElementsByClassName("listFUTItem"));
        var itemsToBidOnCount = 0;
        // if there are no search results, we need to go back and re-search
        if (items.length === 0) {
            setTimeout(function () {
                // go back to search page
                clickElement_1.default(document.getElementsByClassName("ut-navigation-button-control")[0]);
                // go again
                doWork(maxBidAmount, shouldBidMax);
            }, 250);
        }
        var _loop_1 = function (i) {
            var val = i; // stores value so proper item is selected
            // - skip processing the item if user already has highest bid
            // - don't skip if it's the last one so we can go to next page
            if (items[val].classList.contains("highest-bid") &&
                i !== items.length - 1) {
                return "continue";
            }
            else {
                itemsToBidOnCount++;
            }
            setTimeout(function () {
                var _a, _b;
                // check if bot has been stopped
                if (localStorage.getItem("bidder") === "off") {
                    clearTimeout(pageFlipperTimer);
                    pageFlipperTimer = null;
                    return;
                }
                if ((_b = (_a = document.getElementsByClassName("dialog-title")) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.innerText.startsWith("LIMIT")) {
                    stopBidder("Bot stopped because transfer targets list is full.");
                    return;
                }
                // select item
                clickElement_1.default(items[val].getElementsByClassName("has-tap-callback")[0]);
                // bid on item
                setTimeout(function () {
                    var _a, _b;
                    if (!items[val].classList.contains("highest-bid")) {
                        // get current bid price
                        var container = document.getElementsByClassName("currentBid")[0];
                        var currentBid = container.getElementsByClassName("currency-coins")[0].innerText;
                        var currentBidNumber = parseInt(currentBid.replace(/[., \u00a0\u202F]*/g, ""));
                        // if current bid is less than max bid amount, then bid
                        if (currentBidNumber < maxBidAmount) {
                            // if "always bid max" is enabled, replace bid amount value
                            if (shouldBidMax) {
                                document.getElementsByClassName("numericInput")[0].value = maxBidAmount.toString();
                            }
                            clickElement_1.default(document.getElementsByClassName("bidButton")[0]);
                        }
                    }
                    if ((_b = (_a = document.getElementsByClassName("dialog-title")) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.innerText.startsWith("LIMIT")) {
                        stopBidder("Bot stopped because transfer targets list is full.");
                        return;
                    }
                    // check for next page after processing last item
                    if (i === items.length - 1) {
                        setTimeout(function () {
                            var nextPageButton = document.getElementsByClassName("pagination next")[0];
                            if (nextPageButton.style.display === "none") {
                                // go back to search page
                                clickElement_1.default(document.getElementsByClassName("ut-navigation-button-control")[0]);
                                // go again
                                doWork(maxBidAmount, shouldBidMax);
                            }
                            else {
                                clickElement_1.default(nextPageButton);
                                bidOnSearchResults(maxBidAmount, shouldBidMax);
                            }
                        }, 250);
                    }
                }, 100 + randomize());
            }, 1500 * itemsToBidOnCount);
        };
        // iterate through items and do work
        for (var i = 0; i < items.length; i++) {
            _loop_1(i);
        }
    }, 2000 + randomize(1000));
};
var stopBidder = function (reason) {
    // check if bot has been stopped
    if (localStorage.getItem("bidder") === "off") {
        return;
    }
    clearTimeout(pageFlipperTimer);
    pageFlipperTimer = null;
    clearTimeout(bidderTimer);
    bidderTimer = null;
    contentScript_1.stopAutobuyer(reason);
};
exports.cleanupTransferTargets = function () {
    if (!isUserOnTransferTargetsPage_1.default()) {
        return;
    }
    // gets all item groups on transfer targets page
    var itemLists = Array.from(document.getElementsByClassName("itemList"));
    // gets items from the first section
    var activeItems = Array.from(itemLists[0].getElementsByClassName("listFUTItem"));
    var itemsToUnwatchCount = 0;
    var _loop_2 = function (i) {
        var val = i; // stores value so proper item is selected
        // - skip processing the item if user isn't outbid
        // - don't skip if it's the last one so we can go to next page
        if (!activeItems[val].classList.contains("outbid") &&
            i !== activeItems.length - 1) {
            return "continue";
        }
        else {
            itemsToUnwatchCount++;
        }
        setTimeout(function () {
            // select item
            clickElement_1.default(activeItems[val].getElementsByClassName("has-tap-callback")[0]);
            // unwatch item
            setTimeout(function () {
                if (activeItems[val].classList.contains("outbid")) {
                    clickElement_1.default(document.getElementsByClassName("watch")[0]);
                }
                // if last time, then try to clear expired items
                if (i === activeItems.length - 1) {
                    var clearExpiredButton = document.getElementsByClassName("btn-standard section-header-btn call-to-action")[3];
                    if (clearExpiredButton) {
                        clickElement_1.default(clearExpiredButton);
                        setTimeout(function () {
                            alert("Finished cleaning your Transfer Targets list!");
                        }, 1000);
                    }
                    else {
                        alert("Finished cleaning your Transfer Targets list!");
                    }
                }
            }, 100 + randomize());
        }, 2000 * itemsToUnwatchCount);
    };
    // iterate through items and do work
    for (var i = 0; i < activeItems.length; i++) {
        _loop_2(i);
    }
};
var randomize = function (maxOverride) {
    var min = 0;
    var max = maxOverride || 100;
    return Math.floor(Math.random() * (max - min + 1) + min);
};


/***/ }),

/***/ "./src/contentScript.scss":
/*!********************************!*\
  !*** ./src/contentScript.scss ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../node_modules/css-modules-typescript-loader!../node_modules/css-loader/dist/cjs.js??ref--5-2!../node_modules/sass-loader/lib/loader.js!./contentScript.scss */ "./node_modules/css-modules-typescript-loader/index.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/sass-loader/lib/loader.js!./src/contentScript.scss");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./src/contentScript.tsx":
/*!*******************************!*\
  !*** ./src/contentScript.tsx ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.stopAutobuyer = void 0;
var back_1 = __importDefault(__webpack_require__(/*! ./actions/back */ "./src/actions/back.ts"));
var list_1 = __importDefault(__webpack_require__(/*! ./actions/list */ "./src/actions/list.ts"));
var search_1 = __importDefault(__webpack_require__(/*! ./actions/search */ "./src/actions/search.ts"));
var sendToTransferList_1 = __importDefault(__webpack_require__(/*! ./actions/sendToTransferList */ "./src/actions/sendToTransferList.ts"));
var increaseMinBidPrice_1 = __importDefault(__webpack_require__(/*! ./actions/increaseMinBidPrice */ "./src/actions/increaseMinBidPrice.ts"));
var storeInClub_1 = __importDefault(__webpack_require__(/*! ./actions/storeInClub */ "./src/actions/storeInClub.ts"));
var isUserOnSearchResultsPage_1 = __importDefault(__webpack_require__(/*! ./actions/helpers/isUserOnSearchResultsPage */ "./src/actions/helpers/isUserOnSearchResultsPage.ts"));
var increaseMinBinPrice_1 = __importDefault(__webpack_require__(/*! ./actions/increaseMinBinPrice */ "./src/actions/increaseMinBinPrice.ts"));
var increaseMaxBinPrice_1 = __importDefault(__webpack_require__(/*! ./actions/increaseMaxBinPrice */ "./src/actions/increaseMaxBinPrice.ts"));
var decreaseMaxBinPrice_1 = __importDefault(__webpack_require__(/*! ./actions/decreaseMaxBinPrice */ "./src/actions/decreaseMaxBinPrice.ts"));
var contentScript_scss_1 = __importDefault(__webpack_require__(/*! ./contentScript.scss */ "./src/contentScript.scss"));
var bidder_1 = __importStar(__webpack_require__(/*! ./bidder */ "./src/bidder.ts"));
var isUserOnTransferTargetsPage_1 = __importDefault(__webpack_require__(/*! ./actions/helpers/isUserOnTransferTargetsPage */ "./src/actions/helpers/isUserOnTransferTargetsPage.ts"));
var onTimer = null;
var offTimer = null;
var isOn = false;
var bidderTimer = null;
(function () {
    var id = chrome.runtime.id;
    if (id !== "ejhpmpgfaoiecijmggjldlmjligknbnb") {
        chrome.runtime.sendMessage({
            log: true,
        });
    }
    // message listener tell user to refresh after redeeming autobuyer access
    chrome.runtime.onMessage.addListener(function (request) {
        if (request.autobuyerAccessRedeemed) {
            setTimeout(function () {
                alert("Please refresh the page so shortfuts auto can be initialized!");
            }, 1500);
        }
    });
    // message listener to get current coin balance
    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.getCurrentCoinBalance) {
            var coinBalance = document.getElementsByClassName("view-navbar-currency-coins")[0].innerText;
            var normalizedCoinBalance = coinBalance.replace(/[., \u00a0\u202F]*/g, "");
            sendResponse({
                normalizedCoinBalance: normalizedCoinBalance,
            });
        }
    });
    var audio = document.createElement("audio");
    audio.id = contentScript_scss_1.default.audio;
    audio.autoplay = false;
    audio.src = "https://www.soundjay.com/buttons/sounds/button-12.mp3";
    document.documentElement.appendChild(audio);
    var loopDoneSound = document.createElement("audio");
    loopDoneSound.id = contentScript_scss_1.default.loopDoneSound;
    loopDoneSound.autoplay = false;
    loopDoneSound.src = "https://www.soundjay.com/misc/bell-ring-01.mp3";
    document.documentElement.appendChild(loopDoneSound);
    var cardSeenSound = document.createElement("audio");
    cardSeenSound.id = contentScript_scss_1.default.cardSeenSound;
    cardSeenSound.autoplay = false;
    cardSeenSound.src = "https://www.soundjay.com/buttons/sounds/button-09a.mp3";
    document.documentElement.appendChild(cardSeenSound);
    var cardPurchasedSound = document.createElement("audio");
    cardPurchasedSound.id = contentScript_scss_1.default.cardPurchasedSound;
    cardPurchasedSound.autoplay = false;
    cardPurchasedSound.src =
        "https://www.soundjay.com/mechanical/sounds/gun-gunshot-01.mp3";
    document.documentElement.appendChild(cardPurchasedSound);
    // resets badge on refresh (since it's obviously stopped)
    chrome.runtime.sendMessage({ stopAutobuyer: true });
    window.localStorage.setItem("seenCount", "0");
    window.localStorage.setItem("searchCount", "0");
    window.localStorage.setItem("purchasedCount", "0");
    console.log("Setting up event listener...");
    chrome.runtime.onMessage.addListener(function (request) {
        if (request.startAutobuyer) {
            // start the autobuyer if the user has redeemed
            chrome.runtime.sendMessage({ checkAccess: true }, function (response) {
                if (!response.hasAccess) {
                    alert("Please open the shortfuts auto Chrome extension and redeem your code that was sent to your email address. Please refresh the web app if you've already redeemed your code.");
                    return;
                }
                window.localStorage.setItem("seenCount", "0");
                window.localStorage.setItem("searchCount", "0");
                window.localStorage.setItem("purchasedCount", "0");
                var playerNameInput = document
                    .getElementsByClassName("ut-player-search-control")[0]
                    .getElementsByTagName("input")[0];
                if (playerNameInput && playerNameInput.value === "") {
                    var retVal = confirm("Player name input is empty. Are you sure you want to start the bot?");
                    if (!retVal) {
                        exports.stopAutobuyer("Bot didn't get started. That was a close one!", true);
                        return;
                    }
                }
                var resetPoint = request.resetPoint, action = request.action, iterationTime = request.iterationTime, iterationTimeMax = request.iterationTimeMax, listStartPrice = request.listStartPrice, listBinPrice = request.listBinPrice, isTestRun = request.isTestRun, cycles = request.cycles, onInterval = request.onInterval, offInterval = request.offInterval, maxBuyNowPrice = request.maxBuyNowPrice, minimumCoinBalance = request.minimumCoinBalance, mode = request.mode, maxBidAmount = request.maxBidAmount, bidDuration = request.bidDuration, shouldBidMax = request.shouldBidMax;
                if (mode === "bid") {
                    bidderTimer = setTimeout(function () { return bidder_1.default(maxBidAmount, bidDuration, shouldBidMax); }, 0);
                }
                else {
                    // Checks to make sure max BIN is set
                    var maxBinInput = document.getElementsByClassName("numericInput")[3];
                    if (maxBinInput.value === "") {
                        var retVal = confirm("The max buy now price is empty. Are you sure you want to start the bot?");
                        if (!retVal) {
                            exports.stopAutobuyer("Bot didn't get started. That was a close one!", true);
                            return;
                        }
                    }
                    // Get initial min BIN set by user
                    var initialMinBin = document.getElementsByClassName("numericInput")[2].value;
                    var initialMinBinNumber = parseInt(initialMinBin.replace(/[., \u00a0\u202F]*/g, "")) || 0;
                    // Determine reset price
                    var maxPurchasePrice = initialMinBinNumber || resetPoint;
                    var resetPrice = getMaxBidPrice(maxPurchasePrice);
                    // Get initial max BIN set by user
                    var initialMaxBin = document.getElementsByClassName("numericInput")[3].value;
                    var initialMaxBinNumber = parseInt(initialMaxBin.replace(/[., \u00a0\u202F]*/g, "")) || 0;
                    if (initialMaxBinNumber <= resetPrice) {
                        exports.stopAutobuyer('Your "Reset price" must be less than the max BIN price of your sniping filter.', true);
                        return;
                    }
                    createCycle({
                        currCycle: 0,
                        totalCycles: cycles,
                        onInterval: onInterval,
                        offInterval: offInterval,
                        isTestRun: isTestRun,
                        action: action,
                        listStartPrice: listStartPrice,
                        listBinPrice: listBinPrice,
                        iterationTime: iterationTime,
                        iterationTimeMax: iterationTimeMax,
                        resetPrice: resetPrice,
                        userSetMinBin: initialMinBinNumber > 0,
                        maxBuyNowPrice: maxBuyNowPrice,
                        initialMaxBin: initialMaxBinNumber,
                        minimumCoinBalance: minimumCoinBalance,
                    });
                }
            });
        }
        else if (request.stopAutobuyerFromPopup) {
            exports.stopAutobuyer("Bot stopped because you stopped it.");
        }
    });
    // Event listener to stop autobuyer on demand
    window.addEventListener("keydown", function (ev) {
        // If user is typing in an input, ignore hotkeys.
        if (document.activeElement.tagName.toLowerCase() === "input") {
            return;
        }
        if (ev.keyCode === 32 && ev.shiftKey) {
            if (isOn || onTimer || offTimer || bidderTimer) {
                exports.stopAutobuyer("Bot stopped because you stopped it.");
            }
            else {
                chrome.storage.sync.get([
                    "resetPoint",
                    "duration",
                    "action",
                    "iterationTime",
                    "iterationTimeMax",
                    "listStartPrice",
                    "listBinPrice",
                    "cycles",
                    "onInterval",
                    "offInterval",
                    "maxBuyNowPrice",
                    "minimumCoinBalance",
                    "mode",
                    "maxBidAmount",
                    "bidDuration",
                    "shouldBidMax",
                ], function (data) {
                    var resetPoint = data.resetPoint, duration = data.duration, action = data.action, iterationTime = data.iterationTime, iterationTimeMax = data.iterationTimeMax, listStartPrice = data.listStartPrice, listBinPrice = data.listBinPrice, cycles = data.cycles, onInterval = data.onInterval, offInterval = data.offInterval, maxBuyNowPrice = data.maxBuyNowPrice, minimumCoinBalance = data.minimumCoinBalance, mode = data.mode, maxBidAmount = data.maxBidAmount, bidDuration = data.bidDuration, shouldBidMax = data.shouldBidMax;
                    chrome.runtime.sendMessage({
                        startAutobuyer: true,
                        resetPoint: parseInt(resetPoint),
                        duration: duration,
                        action: action,
                        iterationTime: iterationTime,
                        iterationTimeMax: iterationTimeMax,
                        listStartPrice: listStartPrice,
                        listBinPrice: listBinPrice,
                        isTestRun: false,
                        cycles: parseInt(cycles),
                        onInterval: parseInt(onInterval),
                        offInterval: parseInt(offInterval),
                        maxBuyNowPrice: parseInt(maxBuyNowPrice),
                        minimumCoinBalance: minimumCoinBalance,
                        mode: mode || "snipe",
                        maxBidAmount: maxBidAmount || 150,
                        bidDuration: bidDuration || 30,
                        shouldBidMax: shouldBidMax,
                    });
                });
            }
        }
    });
    var cleanupButton;
    var div;
    setInterval(function () {
        if (!isUserOnTransferTargetsPage_1.default()) {
            if (cleanupButton) {
                var headerContainer_1 = document.getElementsByClassName("ut-navigation-bar-view navbar-style-landscape")[0];
                headerContainer_1.removeChild(cleanupButton);
                headerContainer_1.removeChild(div);
                cleanupButton = null;
                div = null;
            }
            return;
        }
        if (document.getElementById(contentScript_scss_1.default.cleanupButton)) {
            return;
        }
        cleanupButton = document.createElement("button");
        cleanupButton.id = contentScript_scss_1.default.cleanupButton;
        cleanupButton.innerText = "CLEANUP TRANSER TARGETS";
        cleanupButton.style.padding = "12px";
        cleanupButton.style.background = "whitesmoke";
        cleanupButton.style.fontFamily = "UltimateTeamCondensed,sans-serif";
        cleanupButton.onclick = bidder_1.cleanupTransferTargets;
        cleanupButton.title =
            "Items you're outbid on and items from expired auctions will be removed.";
        var headerContainer = document.getElementsByClassName("ut-navigation-bar-view navbar-style-landscape")[0];
        var headerNode = headerContainer.getElementsByTagName("h1")[0];
        headerNode.style.maxWidth = "fit-content";
        headerNode.parentNode.insertBefore(cleanupButton, headerNode.nextSibling);
        div = document.createElement("div");
        div.style.flex = "1";
        cleanupButton.parentNode.insertBefore(div, cleanupButton.nextSibling);
    }, 1000);
})();
exports.stopAutobuyer = function (reason, skipCheck) {
    if (skipCheck === void 0) { skipCheck = false; }
    if (isOn || onTimer || offTimer || bidderTimer || skipCheck) {
        isOn = false;
        clearTimeout(onTimer);
        onTimer = null;
        clearTimeout(offTimer);
        offTimer = null;
        clearTimeout(bidderTimer);
        bidderTimer = null;
        localStorage.setItem("bidder", "off");
        chrome.runtime.sendMessage({ stopAutobuyer: true });
        var searchCount = window.localStorage.getItem("searchCount");
        var seenCount = window.localStorage.getItem("seenCount");
        var purchasedCount = window.localStorage.getItem("purchasedCount");
        var _string = parseInt(searchCount) > 0
            ? "(" + searchCount + " searches, " + seenCount + " cards seen, " + purchasedCount + " cards bought)"
            : "";
        alert(reason + " " + _string);
    }
};
var randomize = function () {
    var min = 0;
    var max = 50;
    return Math.floor(Math.random() * (max - min + 1) + min);
};
var getMaxBidPrice = function (maxPurchasePrice) {
    if (maxPurchasePrice <= 1000) {
        return maxPurchasePrice - 50;
    }
    else if (maxPurchasePrice <= 10000) {
        return maxPurchasePrice - 100;
    }
    else if (maxPurchasePrice <= 100000) {
        return maxPurchasePrice - 500;
    }
    else {
        return maxPurchasePrice - 1000;
    }
};
var createCycle = function (params) {
    var currCycle = params.currCycle, totalCycles = params.totalCycles, onInterval = params.onInterval, offInterval = params.offInterval, isTestRun = params.isTestRun, action = params.action, listStartPrice = params.listStartPrice, listBinPrice = params.listBinPrice, iterationTime = params.iterationTime, iterationTimeMax = params.iterationTimeMax, resetPrice = params.resetPrice, userSetMinBin = params.userSetMinBin, maxBuyNowPrice = params.maxBuyNowPrice, initialMaxBin = params.initialMaxBin, minimumCoinBalance = params.minimumCoinBalance;
    var onIntervalMinutes = onInterval * 60000;
    var offIntervalMinutes = offInterval * 60000;
    isOn = true;
    // set initial coin balance
    var coinBalance = document.getElementsByClassName("view-navbar-currency-coins")[0].innerText;
    var normalizedCoinBalance = coinBalance.replace(/[., \u00a0\u202F]*/g, "");
    window.localStorage.setItem("previousCoinBalance", normalizedCoinBalance);
    moneyFunction(params);
    var randomModifier = randomize();
    // Start a timer that stops "on" loop after specified time
    onTimer = setTimeout(function () {
        isOn = false;
        chrome.storage.sync.get("shouldPlayLoopDoneSound", function (data) {
            if (data.shouldPlayLoopDoneSound) {
                var loopDoneSound = document.getElementById(contentScript_scss_1.default.loopDoneSound);
                loopDoneSound.play();
            }
            if (currCycle === totalCycles - 1) {
                exports.stopAutobuyer("Bot stopped because it completed the number of requested cycles.");
            }
        });
    }, onIntervalMinutes + randomModifier);
    // Start a timer that restarts "on" loop after specificied time
    offTimer = setTimeout(function () {
        if (currCycle < totalCycles - 1) {
            createCycle({
                currCycle: currCycle + 1,
                totalCycles: totalCycles,
                onInterval: onInterval,
                offInterval: offInterval,
                isTestRun: isTestRun,
                action: action,
                listStartPrice: listStartPrice,
                listBinPrice: listBinPrice,
                iterationTime: iterationTime,
                iterationTimeMax: iterationTimeMax,
                resetPrice: resetPrice,
                userSetMinBin: userSetMinBin,
                maxBuyNowPrice: maxBuyNowPrice,
                initialMaxBin: initialMaxBin,
                minimumCoinBalance: minimumCoinBalance,
            });
        }
    }, onIntervalMinutes + randomModifier + offIntervalMinutes);
};
var moneyFunction = function (params) {
    var isTestRun = params.isTestRun, action = params.action, listStartPrice = params.listStartPrice, listBinPrice = params.listBinPrice, iterationTime = params.iterationTime, iterationTimeMax = params.iterationTimeMax, resetPrice = params.resetPrice, userSetMinBin = params.userSetMinBin, maxBuyNowPrice = params.maxBuyNowPrice, initialMaxBin = params.initialMaxBin, minimumCoinBalance = params.minimumCoinBalance;
    var iterationTimeReal = getInterval(iterationTime, iterationTimeMax);
    // check for captcha
    var isAlertPresent = document.getElementsByClassName("ui-dialog-type-alert").length > 0;
    if (isAlertPresent) {
        chrome.storage.sync.get("shouldPlayCaptchaSound", function (data) {
            if (data.shouldPlayCaptchaSound) {
                var audio = document.getElementById(contentScript_scss_1.default.audio);
                audio.play();
            }
            chrome.runtime.sendMessage({
                alert: true,
            });
            exports.stopAutobuyer("Bot stopped because human verification is required by EA.");
        });
        return;
    }
    // check for coin balance
    var coinBalance = document.getElementsByClassName("view-navbar-currency-coins")[0].innerText;
    var normalizedCoinBalance = coinBalance.replace(/[., ]*/g, "");
    // get previous coin balance from storage
    var previousCoinBalance = window.localStorage.getItem("previousCoinBalance");
    if (normalizedCoinBalance < minimumCoinBalance) {
        exports.stopAutobuyer("Bot stopped because your coin balance has fallen beneath the minimum coin balance threshold you set.");
        return;
    }
    else if (previousCoinBalance !== normalizedCoinBalance) {
        var justSawCard = window.localStorage.getItem("justSawCard");
        /**
         * if the card balance is different than before we searched, and we just
         * saw a card, we can reasonably assume a card was purchased
         */
        if (justSawCard === "true") {
            var oldCount = window.localStorage.getItem("purchasedCount");
            var newCount = oldCount ? parseInt(oldCount) + 1 : 1;
            window.localStorage.setItem("purchasedCount", newCount.toString());
            chrome.storage.sync.get(["shouldPlayCardPurchasedSound", "discordWebhookCardPurchased"], function (data) {
                if (data.shouldPlayCardPurchasedSound) {
                    var cardPurchasedSound = document.getElementById(contentScript_scss_1.default.cardPurchasedSound);
                    cardPurchasedSound.play();
                }
                if (data.discordWebhookCardPurchased) {
                    fetch_retry(data.discordWebhookCardPurchased, {
                        method: "POST",
                        body: JSON.stringify({
                            content: "A card was (probably) bought",
                        }),
                        headers: {
                            "Content-Type": "application/json",
                        },
                    }, 5);
                }
            });
        }
    }
    // resets this check before we search again
    window.localStorage.setItem("justSawCard", "false");
    search_1.default(!isTestRun);
    setTimeout(function () {
        setTimeout(function () {
            try {
                if (action === "list") {
                    list_1.default(listStartPrice, listBinPrice);
                }
                else if (action === "transfer") {
                    sendToTransferList_1.default();
                }
                else if (action === "club") {
                    storeInClub_1.default();
                }
                else if (action === "none" || !action) {
                    // do nothing
                }
            }
            catch (e) { }
            setTimeout(function () {
                if (isUserOnSearchResultsPage_1.default()) {
                    back_1.default();
                }
            }, 200);
        }, 300);
        setTimeout(function () {
            if (userSetMinBin) {
                var minBidInput = document.getElementsByClassName("numericInput")[0];
                var currentMinBid = parseInt(minBidInput.value.replace(/[., \u00a0\u202F]*/g, "")) || 0;
                // If current min bid is greater than resetPrice, reset.
                if (currentMinBid >= resetPrice) {
                    minBidInput.value = "";
                    changeMaxBin(initialMaxBin, maxBuyNowPrice);
                }
                increaseMinBidPrice_1.default();
            }
            else {
                var minBinInput = document.getElementsByClassName("numericInput")[2];
                var currentMinBin = parseInt(minBinInput.value.replace(/[., \u00a0\u202F]*/g, "")) || 0;
                // If current min BIN is greater than resetPrice, reset.
                if (currentMinBin >= resetPrice) {
                    minBinInput.value = "";
                    changeMaxBin(initialMaxBin, maxBuyNowPrice);
                }
                increaseMinBinPrice_1.default();
            }
            if (isOn) {
                moneyFunction(params);
            }
        }, 900);
    }, iterationTimeReal);
};
/**
 * Changes "max BIN" price in search filter
 *
 * @param initialMaxBin Max BIN set in the original filter
 * @param maxBuyNowPrice The price set by the user in the pop-up
 */
var changeMaxBin = function (initialMaxBin, maxBuyNowPrice) {
    if (maxBuyNowPrice <= initialMaxBin) {
        return;
    }
    var maxBinInput = document.getElementsByClassName("numericInput")[3];
    var currentMaxBin = parseInt(maxBinInput.value.replace(/[., \u00a0\u202F]*/g, "")) || 0;
    if (currentMaxBin === 0) {
        return;
    }
    if (currentMaxBin >= maxBuyNowPrice) {
        maxBinInput.value = initialMaxBin.toString();
        increaseMaxBinPrice_1.default();
        decreaseMaxBinPrice_1.default();
    }
    else {
        increaseMaxBinPrice_1.default();
    }
};
function getInterval(iterationTime, iterationTimeMax) {
    var min = parseInt(iterationTime);
    var max = parseInt(iterationTimeMax);
    return Math.floor(Math.random() * (max - min + 1) + min);
}
var fetch_retry = function (url, options, n) {
    return fetch(url, options).catch(function (error) {
        if (n === 1)
            throw error;
        return fetch_retry(url, options, n - 1);
    });
};


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvY29udGVudFNjcmlwdC5zY3NzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvbGliL2FkZFN0eWxlcy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2xpYi91cmxzLmpzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2JhY2sudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvYnV5Tm93LnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2RlY3JlYXNlTWF4QmluUHJpY2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9jbGlja0RldGFpbHNQYW5lbEJ1dHRvbi50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYWN0aW9ucy9oZWxwZXJzL2NsaWNrRWxlbWVudC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYWN0aW9ucy9oZWxwZXJzL2NvbmZpcm1Db25maXJtYXRpb25EaWFsb2cudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9nZXRMaXN0SXRlbUJ1dHRvblRleHQudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9nZXRMaXN0SXRlbXMudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblBhZ2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlLnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2hlbHBlcnMvaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblRyYW5zZmVyVGFyZ2V0c1BhZ2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblRyYW5zZmVyc1BhZ2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblVuYXNzaWduZWRQYWdlLnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2luY3JlYXNlTWF4QmluUHJpY2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaW5jcmVhc2VNaW5CaWRQcmljZS50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYWN0aW9ucy9pbmNyZWFzZU1pbkJpblByaWNlLnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2xpc3QudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvc2VhcmNoLnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL3NlbmRUb1RyYW5zZmVyTGlzdC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYWN0aW9ucy9zdG9yZUluQ2x1Yi50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYmlkZGVyLnRzIiwid2VicGFjazovLy8uL3NyYy9jb250ZW50U2NyaXB0LnNjc3M/NjUxNSIsIndlYnBhY2s6Ly8vLi9zcmMvY29udGVudFNjcmlwdC50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7OztBQ2xGYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7O0FBRWhCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHVDQUF1QyxnQkFBZ0I7QUFDdkQsT0FBTztBQUNQO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsSUFBSTs7O0FBR0o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUEsbUJBQW1CLGlCQUFpQjtBQUNwQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxlQUFlLG9CQUFvQjtBQUNuQyw0QkFBNEI7QUFDNUI7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0EsQ0FBQzs7O0FBR0Q7QUFDQTtBQUNBO0FBQ0EscURBQXFELGNBQWM7QUFDbkU7QUFDQSxDOzs7Ozs7Ozs7OztBQ3BGQSwyQkFBMkIsbUJBQU8sQ0FBQyxxR0FBZ0Q7QUFDbkY7QUFDQSxjQUFjLFFBQVMsOEdBQThHLGtCQUFrQixFQUFFLDhCQUE4QixrQkFBa0IsRUFBRTs7QUFFM007QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7OztBQ1hBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBOEM7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7O0FBRUEsY0FBYyxtQkFBTyxDQUFDLHVEQUFROztBQUU5QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUEsaUJBQWlCLG1CQUFtQjtBQUNwQztBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxpQkFBaUIsc0JBQXNCO0FBQ3ZDOztBQUVBO0FBQ0EsbUJBQW1CLDJCQUEyQjs7QUFFOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGdCQUFnQixtQkFBbUI7QUFDbkM7QUFDQTs7QUFFQTtBQUNBOztBQUVBLGlCQUFpQiwyQkFBMkI7QUFDNUM7QUFDQTs7QUFFQSxRQUFRLHVCQUF1QjtBQUMvQjtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBLGlCQUFpQix1QkFBdUI7QUFDeEM7QUFDQTs7QUFFQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSxnQkFBZ0IsaUJBQWlCO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjOztBQUVkLGtEQUFrRCxzQkFBc0I7QUFDeEU7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBLEVBQUU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSx1REFBdUQ7QUFDdkQ7O0FBRUEsNkJBQTZCLG1CQUFtQjs7QUFFaEQ7O0FBRUE7O0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3RYQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MsV0FBVyxFQUFFO0FBQ3JELHdDQUF3QyxXQUFXLEVBQUU7O0FBRXJEO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0Esc0NBQXNDO0FBQ3RDLEdBQUc7QUFDSDtBQUNBLDhEQUE4RDtBQUM5RDs7QUFFQTtBQUNBO0FBQ0EsRUFBRTs7QUFFRjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hGQSxpSUFBa0Q7QUFDbEQsaUlBQWtEO0FBQ2xELHdLQUE0RTtBQUM1RSw2TEFBMEY7QUFDMUYsNEpBQW9FO0FBQ3BFLDhLQUFnRjtBQUNoRiwrSkFBc0U7QUFFdEUsU0FBd0IsTUFBTTtJQUMxQiw0Q0FBNEM7SUFDNUMsSUFBTSxlQUFlLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUNuRCx3QkFBd0IsQ0FDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVMLElBQUksZUFBZSxJQUFJLGVBQWUsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtRQUN0RSxzQkFBWSxDQUFDLGVBQWUsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2hFLE9BQU87S0FDVjtJQUVELHlDQUF5QztJQUN6QyxJQUNJLDBDQUFnQyxFQUFFO1FBQ2xDLG1DQUF5QixFQUFFO1FBQzNCLGdDQUFzQixFQUFFO1FBQ3hCLCtCQUFxQixFQUFFO1FBQ3ZCLHFDQUEyQixFQUFFLEVBQy9CO1FBQ0UsSUFBSSxtQ0FBeUIsRUFBRSxFQUFFO1lBQzdCLElBQU0sZ0JBQWdCLEdBQUcsc0JBQVksRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFFbkQscURBQXFEO1lBQ3JELElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDbkIsc0JBQVksQ0FDUixRQUFRLENBQUMsc0JBQXNCLENBQzNCLDhCQUE4QixDQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUNQLENBQUM7Z0JBQ0YsT0FBTzthQUNWO1lBRUQsd0ZBQXdGO1lBQ3hGLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLGdCQUFnQixFQUFFLGFBQWEsQ0FBQyxFQUFFLGNBQUk7Z0JBQ25ELGtCQUFjLEdBQWtCLElBQUksZUFBdEIsRUFBRSxXQUFXLEdBQUssSUFBSSxZQUFULENBQVU7Z0JBRTdDLElBQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDdkIsSUFBTSxlQUFlLEdBQUcsR0FBRyxHQUFHLENBQUMsY0FBYyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUVwRCxJQUFJLGVBQWUsR0FBRyxJQUFJLElBQUksV0FBVyxFQUFFO29CQUN2QyxPQUFPO2lCQUNWO3FCQUFNO29CQUNILHNCQUFZLENBQ1IsUUFBUSxDQUFDLHNCQUFzQixDQUMzQiw4QkFBOEIsQ0FDakMsQ0FBQyxDQUFDLENBQUMsQ0FDUCxDQUFDO2lCQUNMO1lBQ0wsQ0FBQyxDQUFDLENBQUM7U0FDTjthQUFNO1lBQ0gsc0JBQVksQ0FDUixRQUFRLENBQUMsc0JBQXNCLENBQzNCLDhCQUE4QixDQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUNQLENBQUM7U0FDTDtLQUNKO0FBQ0wsQ0FBQztBQXpERCx5QkF5REM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pFRCx3S0FBNEU7QUFDNUUsd0tBQTRFO0FBQzVFLGlJQUFrRDtBQUVsRCxTQUF3QixNQUFNO0lBQzFCLElBQUksbUNBQXlCLEVBQUUsRUFBRTtRQUM3QixJQUFJO1lBQ0EsT0FBTyxFQUFFLENBQUM7U0FDYjtRQUFDLE9BQU8sS0FBSyxFQUFFLEdBQUU7S0FDckI7QUFDTCxDQUFDO0FBTkQseUJBTUM7QUFFRCxTQUFTLE9BQU87SUFDWixpQkFBaUIsRUFBRSxDQUFDO0lBRXBCLElBQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQztRQUN0QixtQ0FBeUIsQ0FBQztZQUN0QixhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDO0FBRUQsU0FBUyxpQkFBaUI7SUFDdEIsSUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQy9ELHNCQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDekIsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekJELGlJQUFrRDtBQUNsRCw2TEFBMEY7QUFFMUYsU0FBd0IsbUJBQW1CO0lBQ3ZDLElBQUksMENBQWdDLEVBQUUsRUFBRTtRQUNwQyxJQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyRSxzQkFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0tBQ3hCO0FBQ0wsQ0FBQztBQUxELHNDQUtDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNSRCx5SEFBMEM7QUFFMUMsU0FBd0IsdUJBQXVCLENBQUMsV0FBbUI7SUFDL0QsSUFBSTtRQUNBLDRDQUE0QztRQUM1QyxJQUFJLFdBQVcsS0FBSyxXQUFXLEVBQUU7WUFDN0IsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3pELElBQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDckMsS0FBcUIsVUFBTyxFQUFQLG1CQUFPLEVBQVAscUJBQU8sRUFBUCxJQUFPLEVBQUU7Z0JBQXpCLElBQU0sTUFBTTtnQkFDYixJQUNJLE1BQU07b0JBQ04sTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMseUJBQXlCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDMUQ7b0JBQ0Usc0JBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFckIsVUFBVSxDQUFDO3dCQUNQLG9DQUFvQzt3QkFDcEMsSUFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUNoRCxhQUFhLENBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ0wsSUFBTSxtQkFBbUIsR0FBRyxZQUFZLENBQUMsb0JBQW9CLENBQ3pELFFBQVEsQ0FDWCxDQUFDO3dCQUNGLElBQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQzt3QkFFcEQsNENBQTRDO3dCQUM1QyxJQUFNLE9BQU8sR0FBRyxXQUFXLENBQUMsTUFBTSxDQUM5QixrQkFBUTs0QkFDSixlQUFRLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7Z0NBQzVDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLE1BQU07d0JBRGpDLENBQ2lDLENBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRUwsdUJBQXVCO3dCQUN2QixzQkFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUMxQixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBRVQsT0FBTztpQkFDVjthQUNKO1NBQ0o7UUFFRCxvQ0FBb0M7UUFDcEMsSUFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZFLElBQU0sbUJBQW1CLEdBQUcsWUFBWSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3hFLElBQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUVwRCw0Q0FBNEM7UUFDNUMsSUFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FDOUIsYUFBRztZQUNDLFVBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDdkMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEtBQUssTUFBTTtRQUQ1QixDQUM0QixDQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRUwsdUJBQXVCO1FBQ3ZCLHNCQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDekI7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNaLE1BQU0sNkJBQTZCLENBQUM7S0FDdkM7QUFDTCxDQUFDO0FBeERELDBDQXdEQzs7Ozs7Ozs7Ozs7Ozs7O0FDMUREOztHQUVHO0FBQ0gsU0FBd0IsWUFBWSxDQUFDLE9BQU87SUFDeEMsY0FBYyxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsQ0FBQztJQUN0QyxjQUFjLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3hDLENBQUM7QUFIRCwrQkFHQztBQUVEOzs7Ozs7R0FNRztBQUNILFNBQVMsY0FBYyxDQUFDLE9BQU8sRUFBRSxTQUFTO0lBQ3RDOzs7T0FHRztJQUNILGFBQWE7SUFDYixJQUFNLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQztRQUNwQix3REFBd0Q7UUFDeEQsYUFBYTtRQUNiLFVBQVUsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFO1FBQ3BDLE1BQU0sRUFBRSxPQUFPO1FBQ2YsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDdEIsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDdEIsT0FBTyxFQUFFLEdBQUc7UUFDWixPQUFPLEVBQUUsR0FBRztRQUNaLGFBQWEsRUFBRSxFQUFFO1FBQ2pCLEtBQUssRUFBRSxHQUFHO0tBQ2IsQ0FBQyxDQUFDO0lBRUgsSUFBTSxVQUFVLEdBQUcsSUFBSSxVQUFVLENBQUMsU0FBUyxFQUFFO1FBQ3pDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCLE9BQU8sRUFBRSxJQUFJO1FBQ2IsT0FBTyxFQUFFLENBQUMsS0FBSyxDQUFDO1FBQ2hCLGFBQWEsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUN0QixjQUFjLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFDdkIsUUFBUSxFQUFFLElBQUk7S0FDakIsQ0FBQyxDQUFDO0lBRUgsT0FBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1Q0QseUhBQTBDO0FBRTFDOztHQUVHO0FBQ0gsU0FBd0IseUJBQXlCLENBQUMsT0FBb0I7SUFDbEUsSUFBSTtRQUNBLElBQU0sUUFBUSxHQUFHLFFBQVE7YUFDcEIsc0JBQXNCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ25DLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLHNCQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdkIsT0FBTyxJQUFJLE9BQU8sRUFBRSxDQUFDO0tBQ3hCO0lBQUMsT0FBTyxLQUFLLEVBQUUsR0FBRTtBQUN0QixDQUFDO0FBUkQsNENBUUM7Ozs7Ozs7Ozs7Ozs7OztBQ2JELFNBQXdCLHFCQUFxQjtJQUMzQyxJQUFJLFVBQVUsR0FBRyxtQkFBbUIsQ0FBQztJQUNyQyxJQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBRS9ELFFBQVEsUUFBUSxFQUFFO1FBQ2hCLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxpQ0FBaUMsQ0FBQztZQUMvQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLG1CQUFtQixDQUFDO1lBQ2pDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsVUFBVSxDQUFDO1lBQ3hCLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcscUJBQXFCLENBQUM7WUFDbkMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRywyQkFBMkIsQ0FBQztZQUN6QyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLDJCQUEyQixDQUFDO1lBQ3pDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsd0JBQXdCLENBQUM7WUFDdEMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxzQkFBc0IsQ0FBQztZQUNwQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHVCQUF1QixDQUFDO1lBQ3JDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsWUFBWSxDQUFDO1lBQzFCLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsdUJBQXVCLENBQUM7WUFDckMsTUFBTTtLQUNUO0lBRUQsT0FBTyxVQUFVLENBQUM7QUFDcEIsQ0FBQztBQXpDRCx3Q0F5Q0M7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pDRCxnS0FBb0U7QUFDcEUsdUpBQThEO0FBQzlELG9KQUE0RDtBQUU1RCxTQUF3QixZQUFZO0lBQ2hDLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztJQUVmLElBQUksbUNBQXlCLEVBQUUsRUFBRTtRQUM3QixJQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQzVDLHFCQUFxQixDQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7S0FDdEU7U0FBTSxJQUFJLGdDQUFzQixFQUFFLElBQUksK0JBQXFCLEVBQUUsRUFBRTtRQUM1RCxJQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUN4QixRQUFRLENBQUMsc0JBQXNCLENBQUMsVUFBVSxDQUFDLENBQzlDLENBQUM7UUFDRixTQUFTLENBQUMsT0FBTyxDQUFDLFVBQVMsUUFBUTtZQUMvQixLQUFLLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FDaEIsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FDN0QsQ0FBQztRQUNOLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztLQUNaO1NBQU07UUFDSCxJQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQzVDLHFCQUFxQixDQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7S0FDdEU7SUFFRCxPQUFPLEtBQUssQ0FBQztBQUNqQixDQUFDO0FBekJELCtCQXlCQzs7Ozs7Ozs7Ozs7Ozs7O0FDN0JEOztHQUVHO0FBQ0gsU0FBd0IsWUFBWSxDQUFDLFNBQWlCO0lBQ2xELElBQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMxRCxPQUFPLEtBQUssSUFBSSxLQUFLLENBQUMsU0FBUyxLQUFLLFNBQVMsQ0FBQztBQUNsRCxDQUFDO0FBSEQsK0JBR0M7Ozs7Ozs7Ozs7Ozs7OztBQ05ELFNBQXdCLHlCQUF5QjtJQUM3QyxJQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDbEUsT0FBTyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUMvQixDQUFDO0FBSEQsNENBR0M7Ozs7Ozs7Ozs7Ozs7OztBQ0hELFNBQXdCLGdDQUFnQztJQUNwRCxJQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQzVDLCtCQUErQixDQUNsQyxDQUFDO0lBRUYsSUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO0lBRTFELE9BQU8sUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUM7QUFDMUQsQ0FBQztBQVJELG1EQVFDOzs7Ozs7Ozs7Ozs7Ozs7QUNSRCxTQUF3QiwyQkFBMkI7SUFDL0MsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDdkUsT0FBTyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUMvQixDQUFDO0FBSEQsOENBR0M7Ozs7Ozs7Ozs7Ozs7OztBQ0hELFNBQXdCLHFCQUFxQjtJQUN6QyxJQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUMxRSxPQUFPLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0FBQy9CLENBQUM7QUFIRCx3Q0FHQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSEQseUhBQTBDO0FBRTFDLFNBQXdCLHNCQUFzQjtJQUMxQyxPQUFPO0lBQ0gsVUFBVTtJQUNWLHNCQUFZLENBQUMsWUFBWSxDQUFDO1FBQzFCLFNBQVM7UUFDVCxzQkFBWSxDQUFDLGVBQWUsQ0FBQztRQUM3QixVQUFVO1FBQ1Ysc0JBQVksQ0FBQyxlQUFlLENBQUM7UUFDN0IsU0FBUztRQUNULHNCQUFZLENBQUMsa0JBQWtCLENBQUM7UUFDaEMsU0FBUztRQUNULHNCQUFZLENBQUMsZUFBZSxDQUFDO1FBQzdCLFFBQVE7UUFDUixzQkFBWSxDQUFDLGdCQUFnQixDQUFDO1FBQzlCLGFBQWE7UUFDYixzQkFBWSxDQUFDLGdCQUFnQixDQUFDO1FBQzlCLFVBQVU7UUFDVixzQkFBWSxDQUFDLGNBQWMsQ0FBQztRQUM1QixVQUFVO1FBQ1Ysc0JBQVksQ0FBQyxjQUFjLENBQUM7UUFDNUIsVUFBVTtRQUNWLHNCQUFZLENBQUMsV0FBVyxDQUFDO1FBQ3pCLFNBQVM7UUFDVCxzQkFBWSxDQUFDLFNBQVMsQ0FBQyxDQUMxQixDQUFDO0FBQ04sQ0FBQztBQXpCRCx5Q0F5QkM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNCRCxpSUFBa0Q7QUFDbEQsNkxBQTBGO0FBRTFGLFNBQXdCLG1CQUFtQjtJQUN2QyxJQUFJLDBDQUFnQyxFQUFFLEVBQUU7UUFDcEMsSUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDckUsc0JBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUN4QjtBQUNMLENBQUM7QUFMRCxzQ0FLQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUkQsaUlBQWtEO0FBRWxELFNBQXdCLG1CQUFtQjtJQUN2QyxJQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNyRSxzQkFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3pCLENBQUM7QUFIRCxzQ0FHQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTEQsaUlBQWtEO0FBQ2xELDZMQUEwRjtBQUUxRixTQUF3QixtQkFBbUI7SUFDdkMsSUFBSSwwQ0FBZ0MsRUFBRSxFQUFFO1FBQ3BDLElBQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JFLHNCQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDeEI7QUFDTCxDQUFDO0FBTEQsc0NBS0M7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1JELGlJQUFrRDtBQUNsRCw0SkFBb0U7QUFFcEUsU0FBd0IsSUFBSSxDQUFDLFVBQWtCLEVBQUUsV0FBbUI7SUFDaEUsSUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRXpFLElBQU0scUJBQXFCLEdBQUcsY0FBYyxDQUFDLHNCQUFzQixDQUMvRCxjQUFjLENBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFTCxJQUFNLFVBQVUsR0FBRyxxQkFBcUIsQ0FBQyxzQkFBc0IsQ0FDM0QsZ0JBQWdCLENBQ25CLENBQUM7SUFFRixJQUFJLFVBQVUsRUFBRTtRQUNaLElBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNwQyxJQUFNLGVBQWUsR0FBRyxhQUFhLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkUsZUFBZSxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUM7S0FDdEM7SUFFRCxJQUFJLFdBQVcsRUFBRTtRQUNiLElBQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QixJQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDekQsUUFBUSxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7S0FDM0M7SUFFRCx3REFBd0Q7SUFDeEQsSUFBTSxRQUFRLEdBQUcscUJBQXFCLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDdEUsSUFBTSxPQUFPLEdBQWtCLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7SUFFcEQsbURBQW1EO0lBQ25ELElBQUksY0FBYyxDQUFDO0lBQ25CLElBQU0sVUFBVSxHQUFHLCtCQUFxQixFQUFFLENBQUM7SUFDM0MsS0FBcUIsVUFBTyxFQUFQLG1CQUFPLEVBQVAscUJBQU8sRUFBUCxJQUFPLEVBQUU7UUFBekIsSUFBTSxNQUFNO1FBQ2IsSUFBSSxNQUFNLElBQUksTUFBTSxDQUFDLFNBQVMsS0FBSyxVQUFVLEVBQUU7WUFDM0MsY0FBYyxHQUFHLE1BQU0sQ0FBQztTQUMzQjtLQUNKO0lBRUQsc0JBQVksQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUNqQyxDQUFDO0FBckNELHVCQXFDQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeENELCtGQUE4QjtBQUM5QixpSUFBa0Q7QUFDbEQsaUlBQWtEO0FBQ2xELDZMQUEwRjtBQUMxRix5SEFBMkM7QUFFM0MsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLENBQUM7QUFDN0IsSUFBSSxnQkFBZ0IsR0FBRyxDQUFDLENBQUM7QUFFekIsU0FBd0IsTUFBTSxDQUFDLGNBQXVCO0lBQ3BELElBQUksQ0FBQywwQ0FBZ0MsRUFBRSxFQUFFO1FBQ3ZDLE9BQU87S0FDUjtJQUVELCtDQUErQztJQUMvQyxzQkFBc0IsRUFBRSxDQUFDO0lBRXpCLElBQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDbEQsNkJBQTZCLENBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFTCxzQkFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBRTNCLElBQU0sY0FBYyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ2xFLElBQU0sY0FBYyxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3pFLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxjQUFjLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUV0RSxJQUFJLGNBQWMsS0FBSyxDQUFDLEVBQUU7UUFDeEIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsd0JBQXdCLENBQUMsRUFBRSxVQUFDLElBQUk7WUFDdkQsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7Z0JBQy9CLGlEQUFpRDthQUNsRDtRQUNILENBQUMsQ0FBQyxDQUFDO0tBQ0o7SUFFRCx1Q0FBdUM7SUFDdkMsZ0JBQWdCLEdBQUcsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO0lBQ3hDLElBQU0sV0FBVyxHQUFHLGdCQUFnQixDQUFDO0lBRXJDLGlCQUFpQixHQUFHLFdBQVcsQ0FBQztRQUM5QixJQUFJO1lBQ0YsSUFBTSxnQkFBZ0IsR0FBRyxzQkFBWSxFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUNuRCxJQUFNLGVBQWUsR0FDbkIsUUFBUSxDQUFDLHNCQUFzQixDQUFDLG9CQUFvQixDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUVuRSxJQUFJLGdCQUFnQixJQUFJLGVBQWUsRUFBRTtnQkFDdkMsSUFBSTtvQkFDRixJQUFNLEtBQUssR0FBRyxzQkFBWSxFQUFFLENBQUM7b0JBQzdCLHNCQUFZLENBQ1YsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQzVDLGtCQUFrQixDQUNuQixDQUFDLENBQUMsQ0FBQyxDQUNMLENBQUM7aUJBQ0g7Z0JBQUMsT0FBTyxLQUFLLEVBQUUsR0FBRTtnQkFFbEIsSUFBSSxjQUFjLEVBQUU7b0JBQ2xCLFVBQVUsQ0FBQzt3QkFDVCxZQUFZLEVBQUUsQ0FBQztvQkFDakIsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2lCQUNSO2dCQUVELDRDQUE0QztnQkFDNUMsc0JBQXNCLEVBQUUsQ0FBQzthQUMxQjtTQUNGO1FBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRTtJQUNoQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFFTiw0Q0FBNEM7SUFDNUMsVUFBVSxDQUFDO1FBQ1Qsc0JBQXNCLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDdEMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ1gsQ0FBQztBQTlERCx5QkE4REM7QUFFRCxJQUFNLFlBQVksR0FBRztJQUNuQixJQUFJO1FBQ0YsSUFBTSxrQkFBa0IsR0FDdEIsUUFBUSxDQUFDLHNCQUFzQixDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFFMUQsSUFBSSxrQkFBa0IsRUFBRTtZQUN0QixnQkFBTSxFQUFFLENBQUM7WUFFVCx3QkFBd0I7WUFDeEIsSUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDMUQsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkQsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1lBRTlELDJEQUEyRDtZQUMzRCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFbkQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNyQixDQUFDLDJCQUEyQixFQUFFLHdCQUF3QixDQUFDLEVBQ3ZELFVBQUMsSUFBSTtnQkFDSCxJQUFJLElBQUksQ0FBQyx5QkFBeUIsRUFBRTtvQkFDbEMsSUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FDM0MsNEJBQU0sQ0FBQyxhQUFhLENBQ0QsQ0FBQztvQkFDdEIsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDO2lCQUN0QjtnQkFFRCxJQUFJLElBQUksQ0FBQyxzQkFBc0IsRUFBRTtvQkFDL0IsV0FBVyxDQUNULElBQUksQ0FBQyxzQkFBc0IsRUFDM0I7d0JBQ0UsTUFBTSxFQUFFLE1BQU07d0JBQ2QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLE9BQU8sRUFBRSxrQkFBa0I7eUJBQzVCLENBQUM7d0JBQ0YsT0FBTyxFQUFFOzRCQUNQLGNBQWMsRUFBRSxrQkFBa0I7eUJBQ25DO3FCQUNGLEVBQ0QsQ0FBQyxDQUNGLENBQUM7aUJBQ0g7WUFDSCxDQUFDLENBQ0YsQ0FBQztTQUNIO0tBQ0Y7SUFBQyxPQUFPLENBQUMsRUFBRSxHQUFFO0FBQ2hCLENBQUMsQ0FBQztBQUVGOztHQUVHO0FBQ0gsSUFBTSxzQkFBc0IsR0FBRyxVQUFDLFVBQW1CO0lBQ2pELElBQUksQ0FBQyxVQUFVLElBQUksVUFBVSxLQUFLLGdCQUFnQixFQUFFO1FBQ2xELGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0tBQ2xDO0FBQ0gsQ0FBQyxDQUFDO0FBRUYsSUFBTSxXQUFXLEdBQUcsVUFBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUM7SUFDbEMsWUFBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxLQUFLO1FBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUM7WUFBRSxNQUFNLEtBQUssQ0FBQztRQUN6QixPQUFPLFdBQVcsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUMxQyxDQUFDLENBQUM7QUFIRixDQUdFLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JJTCxrS0FBd0U7QUFFeEUsU0FBd0Isa0JBQWtCO0lBQ3hDLElBQUksVUFBVSxHQUFHLHVCQUF1QixDQUFDO0lBQ3pDLElBQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFFL0QsUUFBUSxRQUFRLEVBQUU7UUFDaEIsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLG9CQUFvQixDQUFDO1lBQ2xDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsb0JBQW9CLENBQUM7WUFDbEMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxtQkFBbUIsQ0FBQztZQUNqQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLDZCQUE2QixDQUFDO1lBQzNDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsb0JBQW9CLENBQUM7WUFDbEMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyx1QkFBdUIsQ0FBQztZQUNyQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHdCQUF3QixDQUFDO1lBQ3RDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsMkJBQTJCLENBQUM7WUFDekMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyw0QkFBNEIsQ0FBQztZQUMxQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLGFBQWEsQ0FBQztZQUMzQixNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHlCQUF5QixDQUFDO1lBQ3ZDLE1BQU07S0FDVDtJQUVELElBQUk7UUFDRixpQ0FBdUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztLQUNyQztJQUFDLE9BQU8sS0FBSyxFQUFFLEdBQUU7QUFDcEIsQ0FBQztBQTNDRCxxQ0EyQ0M7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdDRCxrS0FBd0U7QUFFeEUsU0FBd0IsV0FBVztJQUNqQyxJQUFJLFVBQVUsR0FBRyxpQkFBaUIsQ0FBQztJQUNuQyxJQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBRS9ELFFBQVEsUUFBUSxFQUFFO1FBQ2hCLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyx1QkFBdUIsQ0FBQztZQUNyQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHFCQUFxQixDQUFDO1lBQ25DLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsZ0JBQWdCLENBQUM7WUFDOUIsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxpQkFBaUIsQ0FBQztZQUMvQixNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHVCQUF1QixDQUFDO1lBQ3JDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcscUJBQXFCLENBQUM7WUFDbkMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQztZQUNoQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHNCQUFzQixDQUFDO1lBQ3BDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsaUJBQWlCLENBQUM7WUFDL0IsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxZQUFZLENBQUM7WUFDMUIsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxtQkFBbUIsQ0FBQztZQUNqQyxNQUFNO0tBQ1Q7SUFFRCxJQUFJO1FBQ0YsaUNBQXVCLENBQUMsVUFBVSxDQUFDLENBQUM7S0FDckM7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNkLEVBQUU7S0FDSDtBQUNILENBQUM7QUE3Q0QsOEJBNkNDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0NELHlJQUEwRDtBQUMxRCxzTEFBd0Y7QUFDeEYsNEZBQWdEO0FBRWhELElBQUksZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO0FBQzVCLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQztBQUV2QixTQUF3QixXQUFXLENBQ2pDLFlBQW9CLEVBQ3BCLFFBQWdCLEVBQ2hCLFlBQXFCO0lBRXJCLDhCQUE4QjtJQUM5QixZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUVyQyxXQUFXLEdBQUcsVUFBVSxDQUFDO1FBQ3ZCLFVBQVUsQ0FBQyxvQ0FBa0MsUUFBUSxjQUFXLENBQUMsQ0FBQztJQUNwRSxDQUFDLEVBQUUsUUFBUSxHQUFHLEtBQUssQ0FBQyxDQUFDO0lBRXJCLG1DQUFtQztJQUNsQyxRQUFRLENBQUMsc0JBQXNCLENBQzlCLGNBQWMsQ0FDZixDQUFDLENBQUMsQ0FBc0IsQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBRTFELDhCQUE4QjtJQUM5QixzQkFBWSxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDcEUsc0JBQVksQ0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLHNCQUFZLENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVwRSw0QkFBNEI7SUFDM0IsUUFBUSxDQUFDLHNCQUFzQixDQUM5QixjQUFjLENBQ2YsQ0FBQyxDQUFDLENBQXNCLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQztJQUU3Qyx1Q0FBdUM7SUFDdkMsSUFBTSxlQUFlLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDOUUsc0JBQVksQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUU5QixjQUFjO0lBQ2QsTUFBTSxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztBQUNyQyxDQUFDO0FBakNELDhCQWlDQztBQUVELFNBQVMsTUFBTSxDQUFDLFlBQW9CLEVBQUUsWUFBcUI7SUFDekQseUNBQXlDO0lBQ3pDLElBQU0sZUFBZSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzlFLHNCQUFZLENBQUMsZUFBZSxDQUFDLENBQUM7SUFFOUIsbUJBQW1CO0lBQ25CLElBQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDbEQsNkJBQTZCLENBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDTCxzQkFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBRTNCLHdCQUF3QjtJQUN4QixrQkFBa0IsQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDakQsQ0FBQztBQUVELElBQU0sa0JBQWtCLEdBQUcsVUFBQyxZQUFvQixFQUFFLFlBQXFCO0lBQ3JFLGdDQUFnQztJQUNoQyxJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssS0FBSyxFQUFFO1FBQzVDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQy9CLGdCQUFnQixHQUFHLElBQUksQ0FBQztRQUN4QixPQUFPO0tBQ1I7SUFFRCw4Q0FBOEM7SUFDOUMsVUFBVSxDQUFDO1FBQ1QsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0UsSUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztRQUV6RSxJQUFJLGlCQUFpQixHQUFHLENBQUMsQ0FBQztRQUUxQixtRUFBbUU7UUFDbkUsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN0QixVQUFVLENBQUM7Z0JBQ1QseUJBQXlCO2dCQUN6QixzQkFBWSxDQUNWLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUNuRSxDQUFDO2dCQUVGLFdBQVc7Z0JBQ1gsTUFBTSxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztZQUNyQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDVDtnQ0FHUSxDQUFDO1lBQ1IsSUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsMENBQTBDO1lBRXpELDZEQUE2RDtZQUM3RCw4REFBOEQ7WUFDOUQsSUFDRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7Z0JBQzVDLENBQUMsS0FBSyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFDdEI7O2FBRUQ7aUJBQU07Z0JBQ0wsaUJBQWlCLEVBQUUsQ0FBQzthQUNyQjtZQUVELFVBQVUsQ0FBQzs7Z0JBQ1QsZ0NBQWdDO2dCQUNoQyxJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssS0FBSyxFQUFFO29CQUM1QyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztvQkFDL0IsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO29CQUN4QixPQUFPO2lCQUNSO2dCQUVELFVBQ0csY0FBUSxDQUFDLHNCQUFzQixDQUM5QixjQUFjLENBQ2YsMENBQUcsQ0FBQyxDQUFxQiwwQ0FBRSxTQUFTLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FDeEQ7b0JBQ0EsVUFBVSxDQUFDLG9EQUFvRCxDQUFDLENBQUM7b0JBQ2pFLE9BQU87aUJBQ1I7Z0JBRUQsY0FBYztnQkFDZCxzQkFBWSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXZFLGNBQWM7Z0JBQ2QsVUFBVSxDQUFDOztvQkFDVCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUU7d0JBQ2pELHdCQUF3Qjt3QkFDeEIsSUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNuRSxJQUFNLFVBQVUsR0FBSSxTQUFTLENBQUMsc0JBQXNCLENBQ2xELGdCQUFnQixDQUNqQixDQUFDLENBQUMsQ0FBcUIsQ0FBQyxTQUFTLENBQUM7d0JBQ25DLElBQU0sZ0JBQWdCLEdBQUcsUUFBUSxDQUMvQixVQUFVLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLEVBQUUsQ0FBQyxDQUM5QyxDQUFDO3dCQUVGLHVEQUF1RDt3QkFDdkQsSUFBSSxnQkFBZ0IsR0FBRyxZQUFZLEVBQUU7NEJBQ25DLDJEQUEyRDs0QkFDM0QsSUFBSSxZQUFZLEVBQUU7Z0NBQ2YsUUFBUSxDQUFDLHNCQUFzQixDQUM5QixjQUFjLENBQ2YsQ0FBQyxDQUFDLENBQXNCLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxRQUFRLEVBQUUsQ0FBQzs2QkFDM0Q7NEJBRUQsc0JBQVksQ0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDL0Q7cUJBQ0Y7b0JBRUQsVUFDRyxjQUFRLENBQUMsc0JBQXNCLENBQzlCLGNBQWMsQ0FDZiwwQ0FBRyxDQUFDLENBQXFCLDBDQUFFLFNBQVMsQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUN4RDt3QkFDQSxVQUFVLENBQUMsb0RBQW9ELENBQUMsQ0FBQzt3QkFDakUsT0FBTztxQkFDUjtvQkFFRCxpREFBaUQ7b0JBQ2pELElBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO3dCQUMxQixVQUFVLENBQUM7NEJBQ1QsSUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUNwRCxpQkFBaUIsQ0FDbEIsQ0FBQyxDQUFDLENBQXNCLENBQUM7NEJBRTFCLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxPQUFPLEtBQUssTUFBTSxFQUFFO2dDQUMzQyx5QkFBeUI7Z0NBQ3pCLHNCQUFZLENBQ1YsUUFBUSxDQUFDLHNCQUFzQixDQUM3Qiw4QkFBOEIsQ0FDL0IsQ0FBQyxDQUFDLENBQUMsQ0FDTCxDQUFDO2dDQUVGLFdBQVc7Z0NBQ1gsTUFBTSxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQzs2QkFDcEM7aUNBQU07Z0NBQ0wsc0JBQVksQ0FBQyxjQUFjLENBQUMsQ0FBQztnQ0FDN0Isa0JBQWtCLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDOzZCQUNoRDt3QkFDSCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7cUJBQ1Q7Z0JBQ0gsQ0FBQyxFQUFFLEdBQUcsR0FBRyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1lBQ3hCLENBQUMsRUFBRSxJQUFJLEdBQUcsaUJBQWlCLENBQUMsQ0FBQzs7UUE3Ri9CLG9DQUFvQztRQUNwQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7b0JBQTVCLENBQUM7U0E2RlQ7SUFDSCxDQUFDLEVBQUUsSUFBSSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQztBQUVGLElBQU0sVUFBVSxHQUFHLFVBQUMsTUFBYztJQUNoQyxnQ0FBZ0M7SUFDaEMsSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLEtBQUssRUFBRTtRQUM1QyxPQUFPO0tBQ1I7SUFFRCxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUMvQixnQkFBZ0IsR0FBRyxJQUFJLENBQUM7SUFFeEIsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzFCLFdBQVcsR0FBRyxJQUFJLENBQUM7SUFFbkIsNkJBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUM7QUFFVyw4QkFBc0IsR0FBRztJQUNwQyxJQUFJLENBQUMscUNBQTJCLEVBQUUsRUFBRTtRQUNsQyxPQUFPO0tBQ1I7SUFFRCxnREFBZ0Q7SUFDaEQsSUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUUxRSxvQ0FBb0M7SUFDcEMsSUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FDNUIsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxDQUNuRCxDQUFDO0lBRUYsSUFBSSxtQkFBbUIsR0FBRyxDQUFDLENBQUM7NEJBR25CLENBQUM7UUFDUixJQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQywwQ0FBMEM7UUFFekQsa0RBQWtEO1FBQ2xELDhEQUE4RDtRQUM5RCxJQUNFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDO1lBQzlDLENBQUMsS0FBSyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsRUFDNUI7O1NBRUQ7YUFBTTtZQUNMLG1CQUFtQixFQUFFLENBQUM7U0FDdkI7UUFFRCxVQUFVLENBQUM7WUFDVCxjQUFjO1lBQ2Qsc0JBQVksQ0FDVixXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsc0JBQXNCLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FDL0QsQ0FBQztZQUVGLGVBQWU7WUFDZixVQUFVLENBQUM7Z0JBQ1QsSUFBSSxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDakQsc0JBQVksQ0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDM0Q7Z0JBRUQsZ0RBQWdEO2dCQUNoRCxJQUFJLENBQUMsS0FBSyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDaEMsSUFBTSxrQkFBa0IsR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQ3hELGdEQUFnRCxDQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVMLElBQUksa0JBQWtCLEVBQUU7d0JBQ3RCLHNCQUFZLENBQUMsa0JBQWtCLENBQUMsQ0FBQzt3QkFFakMsVUFBVSxDQUFDOzRCQUNULEtBQUssQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO3dCQUN6RCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7cUJBQ1Y7eUJBQU07d0JBQ0wsS0FBSyxDQUFDLCtDQUErQyxDQUFDLENBQUM7cUJBQ3hEO2lCQUNGO1lBQ0gsQ0FBQyxFQUFFLEdBQUcsR0FBRyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ3hCLENBQUMsRUFBRSxJQUFJLEdBQUcsbUJBQW1CLENBQUMsQ0FBQzs7SUE1Q2pDLG9DQUFvQztJQUNwQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7Z0JBQWxDLENBQUM7S0E0Q1Q7QUFDSCxDQUFDLENBQUM7QUFFRixJQUFNLFNBQVMsR0FBRyxVQUFDLFdBQW9CO0lBQ3JDLElBQU0sR0FBRyxHQUFHLENBQUMsQ0FBQztJQUNkLElBQU0sR0FBRyxHQUFHLFdBQVcsSUFBSSxHQUFHLENBQUM7SUFFL0IsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7QUFDM0QsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDelFGLGNBQWMsbUJBQU8sQ0FBQyxzVUFBMEs7O0FBRWhNLDRDQUE0QyxRQUFTOztBQUVyRDtBQUNBOzs7O0FBSUEsZUFBZTs7QUFFZjtBQUNBOztBQUVBLGFBQWEsbUJBQU8sQ0FBQyxtR0FBZ0Q7O0FBRXJFOztBQUVBLEdBQUcsS0FBVSxFQUFFLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQmYsaUdBQW9DO0FBQ3BDLGlHQUFrQztBQUNsQyx1R0FBc0M7QUFDdEMsMklBQThEO0FBQzlELDhJQUFnRTtBQUNoRSxzSEFBZ0Q7QUFDaEQsZ0xBQW9GO0FBQ3BGLDhJQUFnRTtBQUNoRSw4SUFBZ0U7QUFDaEUsOElBQWdFO0FBQ2hFLHdIQUEwQztBQUMxQyxvRkFBK0Q7QUFDL0Qsc0xBQXdGO0FBRXhGLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQztBQUNuQixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7QUFDcEIsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDO0FBQ2pCLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQztBQUV2QixDQUFDO0lBQ0MsSUFBTSxFQUFFLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDN0IsSUFBSSxFQUFFLEtBQUssa0NBQWtDLEVBQUU7UUFDN0MsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7WUFDekIsR0FBRyxFQUFFLElBQUk7U0FDVixDQUFDLENBQUM7S0FDSjtJQUVELHlFQUF5RTtJQUN6RSxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsVUFBQyxPQUFPO1FBQzNDLElBQUksT0FBTyxDQUFDLHVCQUF1QixFQUFFO1lBQ25DLFVBQVUsQ0FBQztnQkFDVCxLQUFLLENBQUMsK0RBQStELENBQUMsQ0FBQztZQUN6RSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDVjtJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUgsK0NBQStDO0lBQy9DLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsWUFBWTtRQUNqRSxJQUFJLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRTtZQUNqQyxJQUFNLFdBQVcsR0FBSSxRQUFRLENBQUMsc0JBQXNCLENBQ2xELDRCQUE0QixDQUM3QixDQUFDLENBQUMsQ0FBaUIsQ0FBQyxTQUFTLENBQUM7WUFDL0IsSUFBTSxxQkFBcUIsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUMvQyxxQkFBcUIsRUFDckIsRUFBRSxDQUNILENBQUM7WUFFRixZQUFZLENBQUM7Z0JBQ1gscUJBQXFCLEVBQUUscUJBQXFCO2FBQzdDLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSCxJQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzlDLEtBQUssQ0FBQyxFQUFFLEdBQUcsNEJBQU0sQ0FBQyxLQUFLLENBQUM7SUFDeEIsS0FBSyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDdkIsS0FBSyxDQUFDLEdBQUcsR0FBRyx1REFBdUQsQ0FBQztJQUNwRSxRQUFRLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUU1QyxJQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3RELGFBQWEsQ0FBQyxFQUFFLEdBQUcsNEJBQU0sQ0FBQyxhQUFhLENBQUM7SUFDeEMsYUFBYSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDL0IsYUFBYSxDQUFDLEdBQUcsR0FBRyxnREFBZ0QsQ0FBQztJQUNyRSxRQUFRLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUVwRCxJQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3RELGFBQWEsQ0FBQyxFQUFFLEdBQUcsNEJBQU0sQ0FBQyxhQUFhLENBQUM7SUFDeEMsYUFBYSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDL0IsYUFBYSxDQUFDLEdBQUcsR0FBRyx3REFBd0QsQ0FBQztJQUM3RSxRQUFRLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUVwRCxJQUFNLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDM0Qsa0JBQWtCLENBQUMsRUFBRSxHQUFHLDRCQUFNLENBQUMsa0JBQWtCLENBQUM7SUFDbEQsa0JBQWtCLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUNwQyxrQkFBa0IsQ0FBQyxHQUFHO1FBQ3BCLCtEQUErRCxDQUFDO0lBQ2xFLFFBQVEsQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFFekQseURBQXlEO0lBQ3pELE1BQU0sQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7SUFDcEQsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQzlDLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNoRCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUVuRCxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFFNUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLFVBQUMsT0FBTztRQUMzQyxJQUFJLE9BQU8sQ0FBQyxjQUFjLEVBQUU7WUFDMUIsK0NBQStDO1lBQy9DLE1BQU0sQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxFQUFFLFVBQUMsUUFBUTtnQkFDekQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUU7b0JBQ3ZCLEtBQUssQ0FDSCw0S0FBNEssQ0FDN0ssQ0FBQztvQkFDRixPQUFPO2lCQUNSO2dCQUVELE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDOUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUNoRCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFFbkQsSUFBTSxlQUFlLEdBQUcsUUFBUTtxQkFDN0Isc0JBQXNCLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3JELG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyxJQUFJLGVBQWUsSUFBSSxlQUFlLENBQUMsS0FBSyxLQUFLLEVBQUUsRUFBRTtvQkFDbkQsSUFBTSxNQUFNLEdBQUcsT0FBTyxDQUNwQixxRUFBcUUsQ0FDdEUsQ0FBQztvQkFFRixJQUFJLENBQUMsTUFBTSxFQUFFO3dCQUNYLHFCQUFhLENBQ1gsK0NBQStDLEVBQy9DLElBQUksQ0FDTCxDQUFDO3dCQUNGLE9BQU87cUJBQ1I7aUJBQ0Y7Z0JBR0MsY0FBVSxHQWdCUixPQUFPLFdBaEJDLEVBQ1YsTUFBTSxHQWVKLE9BQU8sT0FmSCxFQUNOLGFBQWEsR0FjWCxPQUFPLGNBZEksRUFDYixnQkFBZ0IsR0FhZCxPQUFPLGlCQWJPLEVBQ2hCLGNBQWMsR0FZWixPQUFPLGVBWkssRUFDZCxZQUFZLEdBV1YsT0FBTyxhQVhHLEVBQ1osU0FBUyxHQVVQLE9BQU8sVUFWQSxFQUNULE1BQU0sR0FTSixPQUFPLE9BVEgsRUFDTixVQUFVLEdBUVIsT0FBTyxXQVJDLEVBQ1YsV0FBVyxHQU9ULE9BQU8sWUFQRSxFQUNYLGNBQWMsR0FNWixPQUFPLGVBTkssRUFDZCxrQkFBa0IsR0FLaEIsT0FBTyxtQkFMUyxFQUNsQixJQUFJLEdBSUYsT0FBTyxLQUpMLEVBQ0osWUFBWSxHQUdWLE9BQU8sYUFIRyxFQUNaLFdBQVcsR0FFVCxPQUFPLFlBRkUsRUFDWCxZQUFZLEdBQ1YsT0FBTyxhQURHLENBQ0Y7Z0JBQ1osSUFBSSxJQUFJLEtBQUssS0FBSyxFQUFFO29CQUNsQixXQUFXLEdBQUcsVUFBVSxDQUN0QixjQUFNLHVCQUFXLENBQUMsWUFBWSxFQUFFLFdBQVcsRUFBRSxZQUFZLENBQUMsRUFBcEQsQ0FBb0QsRUFDMUQsQ0FBQyxDQUNGLENBQUM7aUJBQ0g7cUJBQU07b0JBQ0wscUNBQXFDO29CQUNyQyxJQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQ2pELGNBQWMsQ0FDZixDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNMLElBQUssV0FBZ0MsQ0FBQyxLQUFLLEtBQUssRUFBRSxFQUFFO3dCQUNsRCxJQUFNLE1BQU0sR0FBRyxPQUFPLENBQ3BCLHlFQUF5RSxDQUMxRSxDQUFDO3dCQUVGLElBQUksQ0FBQyxNQUFNLEVBQUU7NEJBQ1gscUJBQWEsQ0FDWCwrQ0FBK0MsRUFDL0MsSUFBSSxDQUNMLENBQUM7NEJBQ0YsT0FBTzt5QkFDUjtxQkFDRjtvQkFFRCxrQ0FBa0M7b0JBQ2xDLElBQU0sYUFBYSxHQUFJLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDcEQsY0FBYyxDQUNmLENBQUMsQ0FBQyxDQUFzQixDQUFDLEtBQUssQ0FBQztvQkFDaEMsSUFBTSxtQkFBbUIsR0FDdkIsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRWxFLHdCQUF3QjtvQkFDeEIsSUFBTSxnQkFBZ0IsR0FBRyxtQkFBbUIsSUFBSSxVQUFVLENBQUM7b0JBQzNELElBQU0sVUFBVSxHQUFHLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO29CQUVwRCxrQ0FBa0M7b0JBQ2xDLElBQU0sYUFBYSxHQUFJLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDcEQsY0FBYyxDQUNmLENBQUMsQ0FBQyxDQUFzQixDQUFDLEtBQUssQ0FBQztvQkFDaEMsSUFBTSxtQkFBbUIsR0FDdkIsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRWxFLElBQUksbUJBQW1CLElBQUksVUFBVSxFQUFFO3dCQUNyQyxxQkFBYSxDQUNYLGdGQUFnRixFQUNoRixJQUFJLENBQ0wsQ0FBQzt3QkFDRixPQUFPO3FCQUNSO29CQUVELFdBQVcsQ0FBQzt3QkFDVixTQUFTLEVBQUUsQ0FBQzt3QkFDWixXQUFXLEVBQUUsTUFBTTt3QkFDbkIsVUFBVTt3QkFDVixXQUFXO3dCQUNYLFNBQVM7d0JBQ1QsTUFBTTt3QkFDTixjQUFjO3dCQUNkLFlBQVk7d0JBQ1osYUFBYTt3QkFDYixnQkFBZ0I7d0JBQ2hCLFVBQVU7d0JBQ1YsYUFBYSxFQUFFLG1CQUFtQixHQUFHLENBQUM7d0JBQ3RDLGNBQWM7d0JBQ2QsYUFBYSxFQUFFLG1CQUFtQjt3QkFDbEMsa0JBQWtCLEVBQUUsa0JBQWtCO3FCQUN2QyxDQUFDLENBQUM7aUJBQ0o7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO2FBQU0sSUFBSSxPQUFPLENBQUMsc0JBQXNCLEVBQUU7WUFDekMscUJBQWEsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1NBQ3REO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSCw2Q0FBNkM7SUFDN0MsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxVQUFDLEVBQUU7UUFDcEMsaURBQWlEO1FBQ2pELElBQUksUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLEtBQUssT0FBTyxFQUFFO1lBQzVELE9BQU87U0FDUjtRQUVELElBQUksRUFBRSxDQUFDLE9BQU8sS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtZQUNwQyxJQUFJLElBQUksSUFBSSxPQUFPLElBQUksUUFBUSxJQUFJLFdBQVcsRUFBRTtnQkFDOUMscUJBQWEsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO2FBQ3REO2lCQUFNO2dCQUNMLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDckI7b0JBQ0UsWUFBWTtvQkFDWixVQUFVO29CQUNWLFFBQVE7b0JBQ1IsZUFBZTtvQkFDZixrQkFBa0I7b0JBQ2xCLGdCQUFnQjtvQkFDaEIsY0FBYztvQkFDZCxRQUFRO29CQUNSLFlBQVk7b0JBQ1osYUFBYTtvQkFDYixnQkFBZ0I7b0JBQ2hCLG9CQUFvQjtvQkFDcEIsTUFBTTtvQkFDTixjQUFjO29CQUNkLGFBQWE7b0JBQ2IsY0FBYztpQkFDZixFQUNELFVBQUMsSUFBSTtvQkFFRCxjQUFVLEdBZ0JSLElBQUksV0FoQkksRUFDVixRQUFRLEdBZU4sSUFBSSxTQWZFLEVBQ1IsTUFBTSxHQWNKLElBQUksT0FkQSxFQUNOLGFBQWEsR0FhWCxJQUFJLGNBYk8sRUFDYixnQkFBZ0IsR0FZZCxJQUFJLGlCQVpVLEVBQ2hCLGNBQWMsR0FXWixJQUFJLGVBWFEsRUFDZCxZQUFZLEdBVVYsSUFBSSxhQVZNLEVBQ1osTUFBTSxHQVNKLElBQUksT0FUQSxFQUNOLFVBQVUsR0FRUixJQUFJLFdBUkksRUFDVixXQUFXLEdBT1QsSUFBSSxZQVBLLEVBQ1gsY0FBYyxHQU1aLElBQUksZUFOUSxFQUNkLGtCQUFrQixHQUtoQixJQUFJLG1CQUxZLEVBQ2xCLElBQUksR0FJRixJQUFJLEtBSkYsRUFDSixZQUFZLEdBR1YsSUFBSSxhQUhNLEVBQ1osV0FBVyxHQUVULElBQUksWUFGSyxFQUNYLFlBQVksR0FDVixJQUFJLGFBRE0sQ0FDTDtvQkFFVCxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQzt3QkFDekIsY0FBYyxFQUFFLElBQUk7d0JBQ3BCLFVBQVUsRUFBRSxRQUFRLENBQUMsVUFBVSxDQUFDO3dCQUNoQyxRQUFRLEVBQUUsUUFBUTt3QkFDbEIsTUFBTSxFQUFFLE1BQU07d0JBQ2QsYUFBYSxFQUFFLGFBQWE7d0JBQzVCLGdCQUFnQixFQUFFLGdCQUFnQjt3QkFDbEMsY0FBYyxFQUFFLGNBQWM7d0JBQzlCLFlBQVksRUFBRSxZQUFZO3dCQUMxQixTQUFTLEVBQUUsS0FBSzt3QkFDaEIsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUM7d0JBQ3hCLFVBQVUsRUFBRSxRQUFRLENBQUMsVUFBVSxDQUFDO3dCQUNoQyxXQUFXLEVBQUUsUUFBUSxDQUFDLFdBQVcsQ0FBQzt3QkFDbEMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxjQUFjLENBQUM7d0JBQ3hDLGtCQUFrQixFQUFFLGtCQUFrQjt3QkFDdEMsSUFBSSxFQUFFLElBQUksSUFBSSxPQUFPO3dCQUNyQixZQUFZLEVBQUUsWUFBWSxJQUFJLEdBQUc7d0JBQ2pDLFdBQVcsRUFBRSxXQUFXLElBQUksRUFBRTt3QkFDOUIsWUFBWSxFQUFFLFlBQVk7cUJBQzNCLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQ0YsQ0FBQzthQUNIO1NBQ0Y7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUVILElBQUksYUFBZ0MsQ0FBQztJQUNyQyxJQUFJLEdBQUcsQ0FBQztJQUNSLFdBQVcsQ0FBQztRQUNWLElBQUksQ0FBQyxxQ0FBMkIsRUFBRSxFQUFFO1lBQ2xDLElBQUksYUFBYSxFQUFFO2dCQUNqQixJQUFNLGlCQUFlLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUNyRCwrQ0FBK0MsQ0FDaEQsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFTCxpQkFBZSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDM0MsaUJBQWUsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRWpDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQ3JCLEdBQUcsR0FBRyxJQUFJLENBQUM7YUFDWjtZQUVELE9BQU87U0FDUjtRQUVELElBQUksUUFBUSxDQUFDLGNBQWMsQ0FBQyw0QkFBTSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ2pELE9BQU87U0FDUjtRQUVELGFBQWEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBc0IsQ0FBQztRQUN0RSxhQUFhLENBQUMsRUFBRSxHQUFHLDRCQUFNLENBQUMsYUFBYSxDQUFDO1FBQ3hDLGFBQWEsQ0FBQyxTQUFTLEdBQUcseUJBQXlCLENBQUM7UUFDcEQsYUFBYSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO1FBQ3JDLGFBQWEsQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLFlBQVksQ0FBQztRQUM5QyxhQUFhLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxrQ0FBa0MsQ0FBQztRQUNwRSxhQUFhLENBQUMsT0FBTyxHQUFHLCtCQUFzQixDQUFDO1FBQy9DLGFBQWEsQ0FBQyxLQUFLO1lBQ2pCLHlFQUF5RSxDQUFDO1FBRTVFLElBQU0sZUFBZSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDckQsK0NBQStDLENBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFTCxJQUFNLFVBQVUsR0FBRyxlQUFlLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDakUsVUFBVSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsYUFBYSxDQUFDO1FBQzFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFMUUsR0FBRyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO1FBQ3JCLGFBQWEsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUVRLHFCQUFhLEdBQUcsVUFBQyxNQUFjLEVBQUUsU0FBMEI7SUFBMUIsNkNBQTBCO0lBQ3RFLElBQUksSUFBSSxJQUFJLE9BQU8sSUFBSSxRQUFRLElBQUksV0FBVyxJQUFJLFNBQVMsRUFBRTtRQUMzRCxJQUFJLEdBQUcsS0FBSyxDQUFDO1FBRWIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RCLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFFZixZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdkIsUUFBUSxHQUFHLElBQUksQ0FBQztRQUVoQixZQUFZLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDMUIsV0FBVyxHQUFHLElBQUksQ0FBQztRQUNuQixZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV0QyxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRXBELElBQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQy9ELElBQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzNELElBQU0sY0FBYyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFFckUsSUFBTSxPQUFPLEdBQ1gsUUFBUSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUM7WUFDdkIsQ0FBQyxDQUFDLE1BQUksV0FBVyxtQkFBYyxTQUFTLHFCQUFnQixjQUFjLG1CQUFnQjtZQUN0RixDQUFDLENBQUMsRUFBRSxDQUFDO1FBRVQsS0FBSyxDQUFJLE1BQU0sU0FBSSxPQUFTLENBQUMsQ0FBQztLQUMvQjtBQUNILENBQUMsQ0FBQztBQUVGLElBQU0sU0FBUyxHQUFHO0lBQ2hCLElBQU0sR0FBRyxHQUFHLENBQUMsQ0FBQztJQUNkLElBQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQztJQUVmLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0FBQzNELENBQUMsQ0FBQztBQUVGLElBQU0sY0FBYyxHQUFHLFVBQUMsZ0JBQXdCO0lBQzlDLElBQUksZ0JBQWdCLElBQUksSUFBSSxFQUFFO1FBQzVCLE9BQU8sZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO0tBQzlCO1NBQU0sSUFBSSxnQkFBZ0IsSUFBSSxLQUFLLEVBQUU7UUFDcEMsT0FBTyxnQkFBZ0IsR0FBRyxHQUFHLENBQUM7S0FDL0I7U0FBTSxJQUFJLGdCQUFnQixJQUFJLE1BQU0sRUFBRTtRQUNyQyxPQUFPLGdCQUFnQixHQUFHLEdBQUcsQ0FBQztLQUMvQjtTQUFNO1FBQ0wsT0FBTyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7S0FDaEM7QUFDSCxDQUFDLENBQUM7QUFFRixJQUFNLFdBQVcsR0FBRyxVQUFDLE1BZ0JwQjtJQUVHLGFBQVMsR0FlUCxNQUFNLFVBZkMsRUFDVCxXQUFXLEdBY1QsTUFBTSxZQWRHLEVBQ1gsVUFBVSxHQWFSLE1BQU0sV0FiRSxFQUNWLFdBQVcsR0FZVCxNQUFNLFlBWkcsRUFDWCxTQUFTLEdBV1AsTUFBTSxVQVhDLEVBQ1QsTUFBTSxHQVVKLE1BQU0sT0FWRixFQUNOLGNBQWMsR0FTWixNQUFNLGVBVE0sRUFDZCxZQUFZLEdBUVYsTUFBTSxhQVJJLEVBQ1osYUFBYSxHQU9YLE1BQU0sY0FQSyxFQUNiLGdCQUFnQixHQU1kLE1BQU0saUJBTlEsRUFDaEIsVUFBVSxHQUtSLE1BQU0sV0FMRSxFQUNWLGFBQWEsR0FJWCxNQUFNLGNBSkssRUFDYixjQUFjLEdBR1osTUFBTSxlQUhNLEVBQ2QsYUFBYSxHQUVYLE1BQU0sY0FGSyxFQUNiLGtCQUFrQixHQUNoQixNQUFNLG1CQURVLENBQ1Q7SUFFWCxJQUFNLGlCQUFpQixHQUFHLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDN0MsSUFBTSxrQkFBa0IsR0FBRyxXQUFXLEdBQUcsS0FBSyxDQUFDO0lBRS9DLElBQUksR0FBRyxJQUFJLENBQUM7SUFFWiwyQkFBMkI7SUFDM0IsSUFBTSxXQUFXLEdBQUksUUFBUSxDQUFDLHNCQUFzQixDQUNsRCw0QkFBNEIsQ0FDN0IsQ0FBQyxDQUFDLENBQWlCLENBQUMsU0FBUyxDQUFDO0lBQy9CLElBQU0scUJBQXFCLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUM3RSxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO0lBRTFFLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUV0QixJQUFNLGNBQWMsR0FBRyxTQUFTLEVBQUUsQ0FBQztJQUVuQywwREFBMEQ7SUFDMUQsT0FBTyxHQUFHLFVBQVUsQ0FBQztRQUNuQixJQUFJLEdBQUcsS0FBSyxDQUFDO1FBRWIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLHlCQUF5QixFQUFFLFVBQUMsSUFBSTtZQUN0RCxJQUFJLElBQUksQ0FBQyx1QkFBdUIsRUFBRTtnQkFDaEMsSUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FDM0MsNEJBQU0sQ0FBQyxhQUFhLENBQ0QsQ0FBQztnQkFDdEIsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ3RCO1lBRUQsSUFBSSxTQUFTLEtBQUssV0FBVyxHQUFHLENBQUMsRUFBRTtnQkFDakMscUJBQWEsQ0FDWCxrRUFBa0UsQ0FDbkUsQ0FBQzthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLEVBQUUsaUJBQWlCLEdBQUcsY0FBYyxDQUFDLENBQUM7SUFFdkMsK0RBQStEO0lBQy9ELFFBQVEsR0FBRyxVQUFVLENBQUM7UUFDcEIsSUFBSSxTQUFTLEdBQUcsV0FBVyxHQUFHLENBQUMsRUFBRTtZQUMvQixXQUFXLENBQUM7Z0JBQ1YsU0FBUyxFQUFFLFNBQVMsR0FBRyxDQUFDO2dCQUN4QixXQUFXO2dCQUNYLFVBQVU7Z0JBQ1YsV0FBVztnQkFDWCxTQUFTO2dCQUNULE1BQU07Z0JBQ04sY0FBYztnQkFDZCxZQUFZO2dCQUNaLGFBQWE7Z0JBQ2IsZ0JBQWdCO2dCQUNoQixVQUFVO2dCQUNWLGFBQWE7Z0JBQ2IsY0FBYztnQkFDZCxhQUFhO2dCQUNiLGtCQUFrQjthQUNuQixDQUFDLENBQUM7U0FDSjtJQUNILENBQUMsRUFBRSxpQkFBaUIsR0FBRyxjQUFjLEdBQUcsa0JBQWtCLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUM7QUFFRixJQUFNLGFBQWEsR0FBRyxVQUFDLE1BWXRCO0lBRUcsYUFBUyxHQVdQLE1BQU0sVUFYQyxFQUNULE1BQU0sR0FVSixNQUFNLE9BVkYsRUFDTixjQUFjLEdBU1osTUFBTSxlQVRNLEVBQ2QsWUFBWSxHQVFWLE1BQU0sYUFSSSxFQUNaLGFBQWEsR0FPWCxNQUFNLGNBUEssRUFDYixnQkFBZ0IsR0FNZCxNQUFNLGlCQU5RLEVBQ2hCLFVBQVUsR0FLUixNQUFNLFdBTEUsRUFDVixhQUFhLEdBSVgsTUFBTSxjQUpLLEVBQ2IsY0FBYyxHQUdaLE1BQU0sZUFITSxFQUNkLGFBQWEsR0FFWCxNQUFNLGNBRkssRUFDYixrQkFBa0IsR0FDaEIsTUFBTSxtQkFEVSxDQUNUO0lBRVgsSUFBTSxpQkFBaUIsR0FBRyxXQUFXLENBQUMsYUFBYSxFQUFFLGdCQUFnQixDQUFDLENBQUM7SUFFdkUsb0JBQW9CO0lBQ3BCLElBQU0sY0FBYyxHQUNsQixRQUFRLENBQUMsc0JBQXNCLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ3JFLElBQUksY0FBYyxFQUFFO1FBQ2xCLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxVQUFDLElBQUk7WUFDckQsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7Z0JBQy9CLElBQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsNEJBQU0sQ0FBQyxLQUFLLENBQXFCLENBQUM7Z0JBQ3hFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNkO1lBRUQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7Z0JBQ3pCLEtBQUssRUFBRSxJQUFJO2FBQ1osQ0FBQyxDQUFDO1lBRUgscUJBQWEsQ0FDWCwyREFBMkQsQ0FDNUQsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTztLQUNSO0lBRUQseUJBQXlCO0lBQ3pCLElBQU0sV0FBVyxHQUFJLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDbEQsNEJBQTRCLENBQzdCLENBQUMsQ0FBQyxDQUFpQixDQUFDLFNBQVMsQ0FBQztJQUMvQixJQUFNLHFCQUFxQixHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBRWpFLHlDQUF5QztJQUN6QyxJQUFNLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUNyRCxxQkFBcUIsQ0FDdEIsQ0FBQztJQUVGLElBQUkscUJBQXFCLEdBQUcsa0JBQWtCLEVBQUU7UUFDOUMscUJBQWEsQ0FDWCxzR0FBc0csQ0FDdkcsQ0FBQztRQUVGLE9BQU87S0FDUjtTQUFNLElBQUksbUJBQW1CLEtBQUsscUJBQXFCLEVBQUU7UUFDeEQsSUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFL0Q7OztXQUdHO1FBQ0gsSUFBSSxXQUFXLEtBQUssTUFBTSxFQUFFO1lBQzFCLElBQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDL0QsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkQsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7WUFFbkUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNyQixDQUFDLDhCQUE4QixFQUFFLDZCQUE2QixDQUFDLEVBQy9ELFVBQUMsSUFBSTtnQkFDSCxJQUFJLElBQUksQ0FBQyw0QkFBNEIsRUFBRTtvQkFDckMsSUFBTSxrQkFBa0IsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUNoRCw0QkFBTSxDQUFDLGtCQUFrQixDQUNOLENBQUM7b0JBQ3RCLGtCQUFrQixDQUFDLElBQUksRUFBRSxDQUFDO2lCQUMzQjtnQkFFRCxJQUFJLElBQUksQ0FBQywyQkFBMkIsRUFBRTtvQkFDcEMsV0FBVyxDQUNULElBQUksQ0FBQywyQkFBMkIsRUFDaEM7d0JBQ0UsTUFBTSxFQUFFLE1BQU07d0JBQ2QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25CLE9BQU8sRUFBRSw4QkFBOEI7eUJBQ3hDLENBQUM7d0JBQ0YsT0FBTyxFQUFFOzRCQUNQLGNBQWMsRUFBRSxrQkFBa0I7eUJBQ25DO3FCQUNGLEVBQ0QsQ0FBQyxDQUNGLENBQUM7aUJBQ0g7WUFDSCxDQUFDLENBQ0YsQ0FBQztTQUNIO0tBQ0Y7SUFFRCwyQ0FBMkM7SUFDM0MsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBRXBELGdCQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUVuQixVQUFVLENBQUM7UUFDVCxVQUFVLENBQUM7WUFDVCxJQUFJO2dCQUNGLElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtvQkFDckIsY0FBSSxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUMsQ0FBQztpQkFDcEM7cUJBQU0sSUFBSSxNQUFNLEtBQUssVUFBVSxFQUFFO29CQUNoQyw0QkFBa0IsRUFBRSxDQUFDO2lCQUN0QjtxQkFBTSxJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7b0JBQzVCLHFCQUFXLEVBQUUsQ0FBQztpQkFDZjtxQkFBTSxJQUFJLE1BQU0sS0FBSyxNQUFNLElBQUksQ0FBQyxNQUFNLEVBQUU7b0JBQ3ZDLGFBQWE7aUJBQ2Q7YUFDRjtZQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUU7WUFFZCxVQUFVLENBQUM7Z0JBQ1QsSUFBSSxtQ0FBeUIsRUFBRSxFQUFFO29CQUMvQixjQUFNLEVBQUUsQ0FBQztpQkFDVjtZQUNILENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNWLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUVSLFVBQVUsQ0FBQztZQUNULElBQUksYUFBYSxFQUFFO2dCQUNqQixJQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQ2pELGNBQWMsQ0FDZixDQUFDLENBQUMsQ0FBcUIsQ0FBQztnQkFDekIsSUFBTSxhQUFhLEdBQ2pCLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFdEUsd0RBQXdEO2dCQUN4RCxJQUFJLGFBQWEsSUFBSSxVQUFVLEVBQUU7b0JBQy9CLFdBQVcsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUN2QixZQUFZLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQyxDQUFDO2lCQUM3QztnQkFFRCw2QkFBbUIsRUFBRSxDQUFDO2FBQ3ZCO2lCQUFNO2dCQUNMLElBQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDakQsY0FBYyxDQUNmLENBQUMsQ0FBQyxDQUFxQixDQUFDO2dCQUN6QixJQUFNLGFBQWEsR0FDakIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUV0RSx3REFBd0Q7Z0JBQ3hELElBQUksYUFBYSxJQUFJLFVBQVUsRUFBRTtvQkFDL0IsV0FBVyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ3ZCLFlBQVksQ0FBQyxhQUFhLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQzdDO2dCQUVELDZCQUFtQixFQUFFLENBQUM7YUFDdkI7WUFFRCxJQUFJLElBQUksRUFBRTtnQkFDUixhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDdkI7UUFDSCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDVixDQUFDLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUM7QUFFRjs7Ozs7R0FLRztBQUNILElBQU0sWUFBWSxHQUFHLFVBQUMsYUFBcUIsRUFBRSxjQUFzQjtJQUNqRSxJQUFJLGNBQWMsSUFBSSxhQUFhLEVBQUU7UUFDbkMsT0FBTztLQUNSO0lBRUQsSUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUNqRCxjQUFjLENBQ2YsQ0FBQyxDQUFDLENBQXFCLENBQUM7SUFDekIsSUFBTSxhQUFhLEdBQ2pCLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUV0RSxJQUFJLGFBQWEsS0FBSyxDQUFDLEVBQUU7UUFDdkIsT0FBTztLQUNSO0lBRUQsSUFBSSxhQUFhLElBQUksY0FBYyxFQUFFO1FBQ25DLFdBQVcsQ0FBQyxLQUFLLEdBQUcsYUFBYSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzdDLDZCQUFtQixFQUFFLENBQUM7UUFDdEIsNkJBQW1CLEVBQUUsQ0FBQztLQUN2QjtTQUFNO1FBQ0wsNkJBQW1CLEVBQUUsQ0FBQztLQUN2QjtBQUNILENBQUMsQ0FBQztBQUVGLFNBQVMsV0FBVyxDQUFDLGFBQXFCLEVBQUUsZ0JBQXdCO0lBQ2xFLElBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNwQyxJQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUV2QyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztBQUMzRCxDQUFDO0FBRUQsSUFBTSxXQUFXLEdBQUcsVUFBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUM7SUFDbEMsWUFBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxLQUFLO1FBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUM7WUFBRSxNQUFNLEtBQUssQ0FBQztRQUN6QixPQUFPLFdBQVcsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUMxQyxDQUFDLENBQUM7QUFIRixDQUdFLENBQUMiLCJmaWxlIjoiY29udGVudFNjcmlwdC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vc3JjL2NvbnRlbnRTY3JpcHQudHN4XCIpO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbi8qXG4gIE1JVCBMaWNlbnNlIGh0dHA6Ly93d3cub3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvbWl0LWxpY2Vuc2UucGhwXG4gIEF1dGhvciBUb2JpYXMgS29wcGVycyBAc29rcmFcbiovXG4vLyBjc3MgYmFzZSBjb2RlLCBpbmplY3RlZCBieSB0aGUgY3NzLWxvYWRlclxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAodXNlU291cmNlTWFwKSB7XG4gIHZhciBsaXN0ID0gW107IC8vIHJldHVybiB0aGUgbGlzdCBvZiBtb2R1bGVzIGFzIGNzcyBzdHJpbmdcblxuICBsaXN0LnRvU3RyaW5nID0gZnVuY3Rpb24gdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMubWFwKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICB2YXIgY29udGVudCA9IGNzc1dpdGhNYXBwaW5nVG9TdHJpbmcoaXRlbSwgdXNlU291cmNlTWFwKTtcblxuICAgICAgaWYgKGl0ZW1bMl0pIHtcbiAgICAgICAgcmV0dXJuICdAbWVkaWEgJyArIGl0ZW1bMl0gKyAneycgKyBjb250ZW50ICsgJ30nO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGNvbnRlbnQ7XG4gICAgICB9XG4gICAgfSkuam9pbignJyk7XG4gIH07IC8vIGltcG9ydCBhIGxpc3Qgb2YgbW9kdWxlcyBpbnRvIHRoZSBsaXN0XG5cblxuICBsaXN0LmkgPSBmdW5jdGlvbiAobW9kdWxlcywgbWVkaWFRdWVyeSkge1xuICAgIGlmICh0eXBlb2YgbW9kdWxlcyA9PT0gJ3N0cmluZycpIHtcbiAgICAgIG1vZHVsZXMgPSBbW251bGwsIG1vZHVsZXMsICcnXV07XG4gICAgfVxuXG4gICAgdmFyIGFscmVhZHlJbXBvcnRlZE1vZHVsZXMgPSB7fTtcblxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIGlkID0gdGhpc1tpXVswXTtcblxuICAgICAgaWYgKGlkICE9IG51bGwpIHtcbiAgICAgICAgYWxyZWFkeUltcG9ydGVkTW9kdWxlc1tpZF0gPSB0cnVlO1xuICAgICAgfVxuICAgIH1cblxuICAgIGZvciAoaSA9IDA7IGkgPCBtb2R1bGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgaXRlbSA9IG1vZHVsZXNbaV07IC8vIHNraXAgYWxyZWFkeSBpbXBvcnRlZCBtb2R1bGVcbiAgICAgIC8vIHRoaXMgaW1wbGVtZW50YXRpb24gaXMgbm90IDEwMCUgcGVyZmVjdCBmb3Igd2VpcmQgbWVkaWEgcXVlcnkgY29tYmluYXRpb25zXG4gICAgICAvLyB3aGVuIGEgbW9kdWxlIGlzIGltcG9ydGVkIG11bHRpcGxlIHRpbWVzIHdpdGggZGlmZmVyZW50IG1lZGlhIHF1ZXJpZXMuXG4gICAgICAvLyBJIGhvcGUgdGhpcyB3aWxsIG5ldmVyIG9jY3VyIChIZXkgdGhpcyB3YXkgd2UgaGF2ZSBzbWFsbGVyIGJ1bmRsZXMpXG5cbiAgICAgIGlmIChpdGVtWzBdID09IG51bGwgfHwgIWFscmVhZHlJbXBvcnRlZE1vZHVsZXNbaXRlbVswXV0pIHtcbiAgICAgICAgaWYgKG1lZGlhUXVlcnkgJiYgIWl0ZW1bMl0pIHtcbiAgICAgICAgICBpdGVtWzJdID0gbWVkaWFRdWVyeTtcbiAgICAgICAgfSBlbHNlIGlmIChtZWRpYVF1ZXJ5KSB7XG4gICAgICAgICAgaXRlbVsyXSA9ICcoJyArIGl0ZW1bMl0gKyAnKSBhbmQgKCcgKyBtZWRpYVF1ZXJ5ICsgJyknO1xuICAgICAgICB9XG5cbiAgICAgICAgbGlzdC5wdXNoKGl0ZW0pO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICByZXR1cm4gbGlzdDtcbn07XG5cbmZ1bmN0aW9uIGNzc1dpdGhNYXBwaW5nVG9TdHJpbmcoaXRlbSwgdXNlU291cmNlTWFwKSB7XG4gIHZhciBjb250ZW50ID0gaXRlbVsxXSB8fCAnJztcbiAgdmFyIGNzc01hcHBpbmcgPSBpdGVtWzNdO1xuXG4gIGlmICghY3NzTWFwcGluZykge1xuICAgIHJldHVybiBjb250ZW50O1xuICB9XG5cbiAgaWYgKHVzZVNvdXJjZU1hcCAmJiB0eXBlb2YgYnRvYSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHZhciBzb3VyY2VNYXBwaW5nID0gdG9Db21tZW50KGNzc01hcHBpbmcpO1xuICAgIHZhciBzb3VyY2VVUkxzID0gY3NzTWFwcGluZy5zb3VyY2VzLm1hcChmdW5jdGlvbiAoc291cmNlKSB7XG4gICAgICByZXR1cm4gJy8qIyBzb3VyY2VVUkw9JyArIGNzc01hcHBpbmcuc291cmNlUm9vdCArIHNvdXJjZSArICcgKi8nO1xuICAgIH0pO1xuICAgIHJldHVybiBbY29udGVudF0uY29uY2F0KHNvdXJjZVVSTHMpLmNvbmNhdChbc291cmNlTWFwcGluZ10pLmpvaW4oJ1xcbicpO1xuICB9XG5cbiAgcmV0dXJuIFtjb250ZW50XS5qb2luKCdcXG4nKTtcbn0gLy8gQWRhcHRlZCBmcm9tIGNvbnZlcnQtc291cmNlLW1hcCAoTUlUKVxuXG5cbmZ1bmN0aW9uIHRvQ29tbWVudChzb3VyY2VNYXApIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVmXG4gIHZhciBiYXNlNjQgPSBidG9hKHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChKU09OLnN0cmluZ2lmeShzb3VyY2VNYXApKSkpO1xuICB2YXIgZGF0YSA9ICdzb3VyY2VNYXBwaW5nVVJMPWRhdGE6YXBwbGljYXRpb24vanNvbjtjaGFyc2V0PXV0Zi04O2Jhc2U2NCwnICsgYmFzZTY0O1xuICByZXR1cm4gJy8qIyAnICsgZGF0YSArICcgKi8nO1xufSIsImV4cG9ydHMgPSBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCIuLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCIpKGZhbHNlKTtcbi8vIE1vZHVsZVxuZXhwb3J0cy5wdXNoKFttb2R1bGUuaWQsIFwiI18xMmZfcUJkQWZfYzNnOW9zU0xaZWM0LFxcbiNfMTlqYUNzN0ptUEktWG5WSi1MaUVrRSxcXG4jXzMxRm1fRWtkV1poeXVlZlVrOEtqNEMsXFxuI18zMEFMR0xyR0dGX2ZaZ0RqNWQ2WE9pIHtcXG4gIGRpc3BsYXk6IG5vbmU7IH1cXG5cXG4jXzE0VlFNN3h2YWM4Mm1DVHc4X3Q0WGIge1xcbiAgZGlzcGxheTogZmxleDsgfVxcblwiLCBcIlwiXSk7XG5cbi8vIEV4cG9ydHNcbmV4cG9ydHMubG9jYWxzID0ge1xuXHRcImF1ZGlvXCI6IFwiXzEyZl9xQmRBZl9jM2c5b3NTTFplYzRcIixcblx0XCJsb29wRG9uZVNvdW5kXCI6IFwiXzE5amFDczdKbVBJLVhuVkotTGlFa0VcIixcblx0XCJjYXJkU2VlblNvdW5kXCI6IFwiXzMxRm1fRWtkV1poeXVlZlVrOEtqNENcIixcblx0XCJjYXJkUHVyY2hhc2VkU291bmRcIjogXCJfMzBBTEdMckdHRl9mWmdEajVkNlhPaVwiLFxuXHRcImNsZWFudXBCdXR0b25cIjogXCJfMTRWUU03eHZhYzgybUNUdzhfdDRYYlwiXG59OyIsIi8qXG5cdE1JVCBMaWNlbnNlIGh0dHA6Ly93d3cub3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvbWl0LWxpY2Vuc2UucGhwXG5cdEF1dGhvciBUb2JpYXMgS29wcGVycyBAc29rcmFcbiovXG5cbnZhciBzdHlsZXNJbkRvbSA9IHt9O1xuXG52YXJcdG1lbW9pemUgPSBmdW5jdGlvbiAoZm4pIHtcblx0dmFyIG1lbW87XG5cblx0cmV0dXJuIGZ1bmN0aW9uICgpIHtcblx0XHRpZiAodHlwZW9mIG1lbW8gPT09IFwidW5kZWZpbmVkXCIpIG1lbW8gPSBmbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXHRcdHJldHVybiBtZW1vO1xuXHR9O1xufTtcblxudmFyIGlzT2xkSUUgPSBtZW1vaXplKGZ1bmN0aW9uICgpIHtcblx0Ly8gVGVzdCBmb3IgSUUgPD0gOSBhcyBwcm9wb3NlZCBieSBCcm93c2VyaGFja3Ncblx0Ly8gQHNlZSBodHRwOi8vYnJvd3NlcmhhY2tzLmNvbS8jaGFjay1lNzFkODY5MmY2NTMzNDE3M2ZlZTcxNWMyMjJjYjgwNVxuXHQvLyBUZXN0cyBmb3IgZXhpc3RlbmNlIG9mIHN0YW5kYXJkIGdsb2JhbHMgaXMgdG8gYWxsb3cgc3R5bGUtbG9hZGVyXG5cdC8vIHRvIG9wZXJhdGUgY29ycmVjdGx5IGludG8gbm9uLXN0YW5kYXJkIGVudmlyb25tZW50c1xuXHQvLyBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS93ZWJwYWNrLWNvbnRyaWIvc3R5bGUtbG9hZGVyL2lzc3Vlcy8xNzdcblx0cmV0dXJuIHdpbmRvdyAmJiBkb2N1bWVudCAmJiBkb2N1bWVudC5hbGwgJiYgIXdpbmRvdy5hdG9iO1xufSk7XG5cbnZhciBnZXRUYXJnZXQgPSBmdW5jdGlvbiAodGFyZ2V0KSB7XG4gIHJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHRhcmdldCk7XG59O1xuXG52YXIgZ2V0RWxlbWVudCA9IChmdW5jdGlvbiAoZm4pIHtcblx0dmFyIG1lbW8gPSB7fTtcblxuXHRyZXR1cm4gZnVuY3Rpb24odGFyZ2V0KSB7XG4gICAgICAgICAgICAgICAgLy8gSWYgcGFzc2luZyBmdW5jdGlvbiBpbiBvcHRpb25zLCB0aGVuIHVzZSBpdCBmb3IgcmVzb2x2ZSBcImhlYWRcIiBlbGVtZW50LlxuICAgICAgICAgICAgICAgIC8vIFVzZWZ1bCBmb3IgU2hhZG93IFJvb3Qgc3R5bGUgaS5lXG4gICAgICAgICAgICAgICAgLy8ge1xuICAgICAgICAgICAgICAgIC8vICAgaW5zZXJ0SW50bzogZnVuY3Rpb24gKCkgeyByZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNmb29cIikuc2hhZG93Um9vdCB9XG4gICAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGFyZ2V0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGFyZ2V0KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVtb1t0YXJnZXRdID09PSBcInVuZGVmaW5lZFwiKSB7XG5cdFx0XHR2YXIgc3R5bGVUYXJnZXQgPSBnZXRUYXJnZXQuY2FsbCh0aGlzLCB0YXJnZXQpO1xuXHRcdFx0Ly8gU3BlY2lhbCBjYXNlIHRvIHJldHVybiBoZWFkIG9mIGlmcmFtZSBpbnN0ZWFkIG9mIGlmcmFtZSBpdHNlbGZcblx0XHRcdGlmICh3aW5kb3cuSFRNTElGcmFtZUVsZW1lbnQgJiYgc3R5bGVUYXJnZXQgaW5zdGFuY2VvZiB3aW5kb3cuSFRNTElGcmFtZUVsZW1lbnQpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHQvLyBUaGlzIHdpbGwgdGhyb3cgYW4gZXhjZXB0aW9uIGlmIGFjY2VzcyB0byBpZnJhbWUgaXMgYmxvY2tlZFxuXHRcdFx0XHRcdC8vIGR1ZSB0byBjcm9zcy1vcmlnaW4gcmVzdHJpY3Rpb25zXG5cdFx0XHRcdFx0c3R5bGVUYXJnZXQgPSBzdHlsZVRhcmdldC5jb250ZW50RG9jdW1lbnQuaGVhZDtcblx0XHRcdFx0fSBjYXRjaChlKSB7XG5cdFx0XHRcdFx0c3R5bGVUYXJnZXQgPSBudWxsO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRtZW1vW3RhcmdldF0gPSBzdHlsZVRhcmdldDtcblx0XHR9XG5cdFx0cmV0dXJuIG1lbW9bdGFyZ2V0XVxuXHR9O1xufSkoKTtcblxudmFyIHNpbmdsZXRvbiA9IG51bGw7XG52YXJcdHNpbmdsZXRvbkNvdW50ZXIgPSAwO1xudmFyXHRzdHlsZXNJbnNlcnRlZEF0VG9wID0gW107XG5cbnZhclx0Zml4VXJscyA9IHJlcXVpcmUoXCIuL3VybHNcIik7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24obGlzdCwgb3B0aW9ucykge1xuXHRpZiAodHlwZW9mIERFQlVHICE9PSBcInVuZGVmaW5lZFwiICYmIERFQlVHKSB7XG5cdFx0aWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gXCJvYmplY3RcIikgdGhyb3cgbmV3IEVycm9yKFwiVGhlIHN0eWxlLWxvYWRlciBjYW5ub3QgYmUgdXNlZCBpbiBhIG5vbi1icm93c2VyIGVudmlyb25tZW50XCIpO1xuXHR9XG5cblx0b3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG5cblx0b3B0aW9ucy5hdHRycyA9IHR5cGVvZiBvcHRpb25zLmF0dHJzID09PSBcIm9iamVjdFwiID8gb3B0aW9ucy5hdHRycyA6IHt9O1xuXG5cdC8vIEZvcmNlIHNpbmdsZS10YWcgc29sdXRpb24gb24gSUU2LTksIHdoaWNoIGhhcyBhIGhhcmQgbGltaXQgb24gdGhlICMgb2YgPHN0eWxlPlxuXHQvLyB0YWdzIGl0IHdpbGwgYWxsb3cgb24gYSBwYWdlXG5cdGlmICghb3B0aW9ucy5zaW5nbGV0b24gJiYgdHlwZW9mIG9wdGlvbnMuc2luZ2xldG9uICE9PSBcImJvb2xlYW5cIikgb3B0aW9ucy5zaW5nbGV0b24gPSBpc09sZElFKCk7XG5cblx0Ly8gQnkgZGVmYXVsdCwgYWRkIDxzdHlsZT4gdGFncyB0byB0aGUgPGhlYWQ+IGVsZW1lbnRcbiAgICAgICAgaWYgKCFvcHRpb25zLmluc2VydEludG8pIG9wdGlvbnMuaW5zZXJ0SW50byA9IFwiaGVhZFwiO1xuXG5cdC8vIEJ5IGRlZmF1bHQsIGFkZCA8c3R5bGU+IHRhZ3MgdG8gdGhlIGJvdHRvbSBvZiB0aGUgdGFyZ2V0XG5cdGlmICghb3B0aW9ucy5pbnNlcnRBdCkgb3B0aW9ucy5pbnNlcnRBdCA9IFwiYm90dG9tXCI7XG5cblx0dmFyIHN0eWxlcyA9IGxpc3RUb1N0eWxlcyhsaXN0LCBvcHRpb25zKTtcblxuXHRhZGRTdHlsZXNUb0RvbShzdHlsZXMsIG9wdGlvbnMpO1xuXG5cdHJldHVybiBmdW5jdGlvbiB1cGRhdGUgKG5ld0xpc3QpIHtcblx0XHR2YXIgbWF5UmVtb3ZlID0gW107XG5cblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IHN0eWxlcy5sZW5ndGg7IGkrKykge1xuXHRcdFx0dmFyIGl0ZW0gPSBzdHlsZXNbaV07XG5cdFx0XHR2YXIgZG9tU3R5bGUgPSBzdHlsZXNJbkRvbVtpdGVtLmlkXTtcblxuXHRcdFx0ZG9tU3R5bGUucmVmcy0tO1xuXHRcdFx0bWF5UmVtb3ZlLnB1c2goZG9tU3R5bGUpO1xuXHRcdH1cblxuXHRcdGlmKG5ld0xpc3QpIHtcblx0XHRcdHZhciBuZXdTdHlsZXMgPSBsaXN0VG9TdHlsZXMobmV3TGlzdCwgb3B0aW9ucyk7XG5cdFx0XHRhZGRTdHlsZXNUb0RvbShuZXdTdHlsZXMsIG9wdGlvbnMpO1xuXHRcdH1cblxuXHRcdGZvciAodmFyIGkgPSAwOyBpIDwgbWF5UmVtb3ZlLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHR2YXIgZG9tU3R5bGUgPSBtYXlSZW1vdmVbaV07XG5cblx0XHRcdGlmKGRvbVN0eWxlLnJlZnMgPT09IDApIHtcblx0XHRcdFx0Zm9yICh2YXIgaiA9IDA7IGogPCBkb21TdHlsZS5wYXJ0cy5sZW5ndGg7IGorKykgZG9tU3R5bGUucGFydHNbal0oKTtcblxuXHRcdFx0XHRkZWxldGUgc3R5bGVzSW5Eb21bZG9tU3R5bGUuaWRdO1xuXHRcdFx0fVxuXHRcdH1cblx0fTtcbn07XG5cbmZ1bmN0aW9uIGFkZFN0eWxlc1RvRG9tIChzdHlsZXMsIG9wdGlvbnMpIHtcblx0Zm9yICh2YXIgaSA9IDA7IGkgPCBzdHlsZXMubGVuZ3RoOyBpKyspIHtcblx0XHR2YXIgaXRlbSA9IHN0eWxlc1tpXTtcblx0XHR2YXIgZG9tU3R5bGUgPSBzdHlsZXNJbkRvbVtpdGVtLmlkXTtcblxuXHRcdGlmKGRvbVN0eWxlKSB7XG5cdFx0XHRkb21TdHlsZS5yZWZzKys7XG5cblx0XHRcdGZvcih2YXIgaiA9IDA7IGogPCBkb21TdHlsZS5wYXJ0cy5sZW5ndGg7IGorKykge1xuXHRcdFx0XHRkb21TdHlsZS5wYXJ0c1tqXShpdGVtLnBhcnRzW2pdKTtcblx0XHRcdH1cblxuXHRcdFx0Zm9yKDsgaiA8IGl0ZW0ucGFydHMubGVuZ3RoOyBqKyspIHtcblx0XHRcdFx0ZG9tU3R5bGUucGFydHMucHVzaChhZGRTdHlsZShpdGVtLnBhcnRzW2pdLCBvcHRpb25zKSk7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHtcblx0XHRcdHZhciBwYXJ0cyA9IFtdO1xuXG5cdFx0XHRmb3IodmFyIGogPSAwOyBqIDwgaXRlbS5wYXJ0cy5sZW5ndGg7IGorKykge1xuXHRcdFx0XHRwYXJ0cy5wdXNoKGFkZFN0eWxlKGl0ZW0ucGFydHNbal0sIG9wdGlvbnMpKTtcblx0XHRcdH1cblxuXHRcdFx0c3R5bGVzSW5Eb21baXRlbS5pZF0gPSB7aWQ6IGl0ZW0uaWQsIHJlZnM6IDEsIHBhcnRzOiBwYXJ0c307XG5cdFx0fVxuXHR9XG59XG5cbmZ1bmN0aW9uIGxpc3RUb1N0eWxlcyAobGlzdCwgb3B0aW9ucykge1xuXHR2YXIgc3R5bGVzID0gW107XG5cdHZhciBuZXdTdHlsZXMgPSB7fTtcblxuXHRmb3IgKHZhciBpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyBpKyspIHtcblx0XHR2YXIgaXRlbSA9IGxpc3RbaV07XG5cdFx0dmFyIGlkID0gb3B0aW9ucy5iYXNlID8gaXRlbVswXSArIG9wdGlvbnMuYmFzZSA6IGl0ZW1bMF07XG5cdFx0dmFyIGNzcyA9IGl0ZW1bMV07XG5cdFx0dmFyIG1lZGlhID0gaXRlbVsyXTtcblx0XHR2YXIgc291cmNlTWFwID0gaXRlbVszXTtcblx0XHR2YXIgcGFydCA9IHtjc3M6IGNzcywgbWVkaWE6IG1lZGlhLCBzb3VyY2VNYXA6IHNvdXJjZU1hcH07XG5cblx0XHRpZighbmV3U3R5bGVzW2lkXSkgc3R5bGVzLnB1c2gobmV3U3R5bGVzW2lkXSA9IHtpZDogaWQsIHBhcnRzOiBbcGFydF19KTtcblx0XHRlbHNlIG5ld1N0eWxlc1tpZF0ucGFydHMucHVzaChwYXJ0KTtcblx0fVxuXG5cdHJldHVybiBzdHlsZXM7XG59XG5cbmZ1bmN0aW9uIGluc2VydFN0eWxlRWxlbWVudCAob3B0aW9ucywgc3R5bGUpIHtcblx0dmFyIHRhcmdldCA9IGdldEVsZW1lbnQob3B0aW9ucy5pbnNlcnRJbnRvKVxuXG5cdGlmICghdGFyZ2V0KSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKFwiQ291bGRuJ3QgZmluZCBhIHN0eWxlIHRhcmdldC4gVGhpcyBwcm9iYWJseSBtZWFucyB0aGF0IHRoZSB2YWx1ZSBmb3IgdGhlICdpbnNlcnRJbnRvJyBwYXJhbWV0ZXIgaXMgaW52YWxpZC5cIik7XG5cdH1cblxuXHR2YXIgbGFzdFN0eWxlRWxlbWVudEluc2VydGVkQXRUb3AgPSBzdHlsZXNJbnNlcnRlZEF0VG9wW3N0eWxlc0luc2VydGVkQXRUb3AubGVuZ3RoIC0gMV07XG5cblx0aWYgKG9wdGlvbnMuaW5zZXJ0QXQgPT09IFwidG9wXCIpIHtcblx0XHRpZiAoIWxhc3RTdHlsZUVsZW1lbnRJbnNlcnRlZEF0VG9wKSB7XG5cdFx0XHR0YXJnZXQuaW5zZXJ0QmVmb3JlKHN0eWxlLCB0YXJnZXQuZmlyc3RDaGlsZCk7XG5cdFx0fSBlbHNlIGlmIChsYXN0U3R5bGVFbGVtZW50SW5zZXJ0ZWRBdFRvcC5uZXh0U2libGluZykge1xuXHRcdFx0dGFyZ2V0Lmluc2VydEJlZm9yZShzdHlsZSwgbGFzdFN0eWxlRWxlbWVudEluc2VydGVkQXRUb3AubmV4dFNpYmxpbmcpO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHR0YXJnZXQuYXBwZW5kQ2hpbGQoc3R5bGUpO1xuXHRcdH1cblx0XHRzdHlsZXNJbnNlcnRlZEF0VG9wLnB1c2goc3R5bGUpO1xuXHR9IGVsc2UgaWYgKG9wdGlvbnMuaW5zZXJ0QXQgPT09IFwiYm90dG9tXCIpIHtcblx0XHR0YXJnZXQuYXBwZW5kQ2hpbGQoc3R5bGUpO1xuXHR9IGVsc2UgaWYgKHR5cGVvZiBvcHRpb25zLmluc2VydEF0ID09PSBcIm9iamVjdFwiICYmIG9wdGlvbnMuaW5zZXJ0QXQuYmVmb3JlKSB7XG5cdFx0dmFyIG5leHRTaWJsaW5nID0gZ2V0RWxlbWVudChvcHRpb25zLmluc2VydEludG8gKyBcIiBcIiArIG9wdGlvbnMuaW5zZXJ0QXQuYmVmb3JlKTtcblx0XHR0YXJnZXQuaW5zZXJ0QmVmb3JlKHN0eWxlLCBuZXh0U2libGluZyk7XG5cdH0gZWxzZSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKFwiW1N0eWxlIExvYWRlcl1cXG5cXG4gSW52YWxpZCB2YWx1ZSBmb3IgcGFyYW1ldGVyICdpbnNlcnRBdCcgKCdvcHRpb25zLmluc2VydEF0JykgZm91bmQuXFxuIE11c3QgYmUgJ3RvcCcsICdib3R0b20nLCBvciBPYmplY3QuXFxuIChodHRwczovL2dpdGh1Yi5jb20vd2VicGFjay1jb250cmliL3N0eWxlLWxvYWRlciNpbnNlcnRhdClcXG5cIik7XG5cdH1cbn1cblxuZnVuY3Rpb24gcmVtb3ZlU3R5bGVFbGVtZW50IChzdHlsZSkge1xuXHRpZiAoc3R5bGUucGFyZW50Tm9kZSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuXHRzdHlsZS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHN0eWxlKTtcblxuXHR2YXIgaWR4ID0gc3R5bGVzSW5zZXJ0ZWRBdFRvcC5pbmRleE9mKHN0eWxlKTtcblx0aWYoaWR4ID49IDApIHtcblx0XHRzdHlsZXNJbnNlcnRlZEF0VG9wLnNwbGljZShpZHgsIDEpO1xuXHR9XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVN0eWxlRWxlbWVudCAob3B0aW9ucykge1xuXHR2YXIgc3R5bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIik7XG5cblx0b3B0aW9ucy5hdHRycy50eXBlID0gXCJ0ZXh0L2Nzc1wiO1xuXG5cdGFkZEF0dHJzKHN0eWxlLCBvcHRpb25zLmF0dHJzKTtcblx0aW5zZXJ0U3R5bGVFbGVtZW50KG9wdGlvbnMsIHN0eWxlKTtcblxuXHRyZXR1cm4gc3R5bGU7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZUxpbmtFbGVtZW50IChvcHRpb25zKSB7XG5cdHZhciBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpbmtcIik7XG5cblx0b3B0aW9ucy5hdHRycy50eXBlID0gXCJ0ZXh0L2Nzc1wiO1xuXHRvcHRpb25zLmF0dHJzLnJlbCA9IFwic3R5bGVzaGVldFwiO1xuXG5cdGFkZEF0dHJzKGxpbmssIG9wdGlvbnMuYXR0cnMpO1xuXHRpbnNlcnRTdHlsZUVsZW1lbnQob3B0aW9ucywgbGluayk7XG5cblx0cmV0dXJuIGxpbms7XG59XG5cbmZ1bmN0aW9uIGFkZEF0dHJzIChlbCwgYXR0cnMpIHtcblx0T2JqZWN0LmtleXMoYXR0cnMpLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuXHRcdGVsLnNldEF0dHJpYnV0ZShrZXksIGF0dHJzW2tleV0pO1xuXHR9KTtcbn1cblxuZnVuY3Rpb24gYWRkU3R5bGUgKG9iaiwgb3B0aW9ucykge1xuXHR2YXIgc3R5bGUsIHVwZGF0ZSwgcmVtb3ZlLCByZXN1bHQ7XG5cblx0Ly8gSWYgYSB0cmFuc2Zvcm0gZnVuY3Rpb24gd2FzIGRlZmluZWQsIHJ1biBpdCBvbiB0aGUgY3NzXG5cdGlmIChvcHRpb25zLnRyYW5zZm9ybSAmJiBvYmouY3NzKSB7XG5cdCAgICByZXN1bHQgPSBvcHRpb25zLnRyYW5zZm9ybShvYmouY3NzKTtcblxuXHQgICAgaWYgKHJlc3VsdCkge1xuXHQgICAgXHQvLyBJZiB0cmFuc2Zvcm0gcmV0dXJucyBhIHZhbHVlLCB1c2UgdGhhdCBpbnN0ZWFkIG9mIHRoZSBvcmlnaW5hbCBjc3MuXG5cdCAgICBcdC8vIFRoaXMgYWxsb3dzIHJ1bm5pbmcgcnVudGltZSB0cmFuc2Zvcm1hdGlvbnMgb24gdGhlIGNzcy5cblx0ICAgIFx0b2JqLmNzcyA9IHJlc3VsdDtcblx0ICAgIH0gZWxzZSB7XG5cdCAgICBcdC8vIElmIHRoZSB0cmFuc2Zvcm0gZnVuY3Rpb24gcmV0dXJucyBhIGZhbHN5IHZhbHVlLCBkb24ndCBhZGQgdGhpcyBjc3MuXG5cdCAgICBcdC8vIFRoaXMgYWxsb3dzIGNvbmRpdGlvbmFsIGxvYWRpbmcgb2YgY3NzXG5cdCAgICBcdHJldHVybiBmdW5jdGlvbigpIHtcblx0ICAgIFx0XHQvLyBub29wXG5cdCAgICBcdH07XG5cdCAgICB9XG5cdH1cblxuXHRpZiAob3B0aW9ucy5zaW5nbGV0b24pIHtcblx0XHR2YXIgc3R5bGVJbmRleCA9IHNpbmdsZXRvbkNvdW50ZXIrKztcblxuXHRcdHN0eWxlID0gc2luZ2xldG9uIHx8IChzaW5nbGV0b24gPSBjcmVhdGVTdHlsZUVsZW1lbnQob3B0aW9ucykpO1xuXG5cdFx0dXBkYXRlID0gYXBwbHlUb1NpbmdsZXRvblRhZy5iaW5kKG51bGwsIHN0eWxlLCBzdHlsZUluZGV4LCBmYWxzZSk7XG5cdFx0cmVtb3ZlID0gYXBwbHlUb1NpbmdsZXRvblRhZy5iaW5kKG51bGwsIHN0eWxlLCBzdHlsZUluZGV4LCB0cnVlKTtcblxuXHR9IGVsc2UgaWYgKFxuXHRcdG9iai5zb3VyY2VNYXAgJiZcblx0XHR0eXBlb2YgVVJMID09PSBcImZ1bmN0aW9uXCIgJiZcblx0XHR0eXBlb2YgVVJMLmNyZWF0ZU9iamVjdFVSTCA9PT0gXCJmdW5jdGlvblwiICYmXG5cdFx0dHlwZW9mIFVSTC5yZXZva2VPYmplY3RVUkwgPT09IFwiZnVuY3Rpb25cIiAmJlxuXHRcdHR5cGVvZiBCbG9iID09PSBcImZ1bmN0aW9uXCIgJiZcblx0XHR0eXBlb2YgYnRvYSA9PT0gXCJmdW5jdGlvblwiXG5cdCkge1xuXHRcdHN0eWxlID0gY3JlYXRlTGlua0VsZW1lbnQob3B0aW9ucyk7XG5cdFx0dXBkYXRlID0gdXBkYXRlTGluay5iaW5kKG51bGwsIHN0eWxlLCBvcHRpb25zKTtcblx0XHRyZW1vdmUgPSBmdW5jdGlvbiAoKSB7XG5cdFx0XHRyZW1vdmVTdHlsZUVsZW1lbnQoc3R5bGUpO1xuXG5cdFx0XHRpZihzdHlsZS5ocmVmKSBVUkwucmV2b2tlT2JqZWN0VVJMKHN0eWxlLmhyZWYpO1xuXHRcdH07XG5cdH0gZWxzZSB7XG5cdFx0c3R5bGUgPSBjcmVhdGVTdHlsZUVsZW1lbnQob3B0aW9ucyk7XG5cdFx0dXBkYXRlID0gYXBwbHlUb1RhZy5iaW5kKG51bGwsIHN0eWxlKTtcblx0XHRyZW1vdmUgPSBmdW5jdGlvbiAoKSB7XG5cdFx0XHRyZW1vdmVTdHlsZUVsZW1lbnQoc3R5bGUpO1xuXHRcdH07XG5cdH1cblxuXHR1cGRhdGUob2JqKTtcblxuXHRyZXR1cm4gZnVuY3Rpb24gdXBkYXRlU3R5bGUgKG5ld09iaikge1xuXHRcdGlmIChuZXdPYmopIHtcblx0XHRcdGlmIChcblx0XHRcdFx0bmV3T2JqLmNzcyA9PT0gb2JqLmNzcyAmJlxuXHRcdFx0XHRuZXdPYmoubWVkaWEgPT09IG9iai5tZWRpYSAmJlxuXHRcdFx0XHRuZXdPYmouc291cmNlTWFwID09PSBvYmouc291cmNlTWFwXG5cdFx0XHQpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHR1cGRhdGUob2JqID0gbmV3T2JqKTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0cmVtb3ZlKCk7XG5cdFx0fVxuXHR9O1xufVxuXG52YXIgcmVwbGFjZVRleHQgPSAoZnVuY3Rpb24gKCkge1xuXHR2YXIgdGV4dFN0b3JlID0gW107XG5cblx0cmV0dXJuIGZ1bmN0aW9uIChpbmRleCwgcmVwbGFjZW1lbnQpIHtcblx0XHR0ZXh0U3RvcmVbaW5kZXhdID0gcmVwbGFjZW1lbnQ7XG5cblx0XHRyZXR1cm4gdGV4dFN0b3JlLmZpbHRlcihCb29sZWFuKS5qb2luKCdcXG4nKTtcblx0fTtcbn0pKCk7XG5cbmZ1bmN0aW9uIGFwcGx5VG9TaW5nbGV0b25UYWcgKHN0eWxlLCBpbmRleCwgcmVtb3ZlLCBvYmopIHtcblx0dmFyIGNzcyA9IHJlbW92ZSA/IFwiXCIgOiBvYmouY3NzO1xuXG5cdGlmIChzdHlsZS5zdHlsZVNoZWV0KSB7XG5cdFx0c3R5bGUuc3R5bGVTaGVldC5jc3NUZXh0ID0gcmVwbGFjZVRleHQoaW5kZXgsIGNzcyk7XG5cdH0gZWxzZSB7XG5cdFx0dmFyIGNzc05vZGUgPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3MpO1xuXHRcdHZhciBjaGlsZE5vZGVzID0gc3R5bGUuY2hpbGROb2RlcztcblxuXHRcdGlmIChjaGlsZE5vZGVzW2luZGV4XSkgc3R5bGUucmVtb3ZlQ2hpbGQoY2hpbGROb2Rlc1tpbmRleF0pO1xuXG5cdFx0aWYgKGNoaWxkTm9kZXMubGVuZ3RoKSB7XG5cdFx0XHRzdHlsZS5pbnNlcnRCZWZvcmUoY3NzTm9kZSwgY2hpbGROb2Rlc1tpbmRleF0pO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRzdHlsZS5hcHBlbmRDaGlsZChjc3NOb2RlKTtcblx0XHR9XG5cdH1cbn1cblxuZnVuY3Rpb24gYXBwbHlUb1RhZyAoc3R5bGUsIG9iaikge1xuXHR2YXIgY3NzID0gb2JqLmNzcztcblx0dmFyIG1lZGlhID0gb2JqLm1lZGlhO1xuXG5cdGlmKG1lZGlhKSB7XG5cdFx0c3R5bGUuc2V0QXR0cmlidXRlKFwibWVkaWFcIiwgbWVkaWEpXG5cdH1cblxuXHRpZihzdHlsZS5zdHlsZVNoZWV0KSB7XG5cdFx0c3R5bGUuc3R5bGVTaGVldC5jc3NUZXh0ID0gY3NzO1xuXHR9IGVsc2Uge1xuXHRcdHdoaWxlKHN0eWxlLmZpcnN0Q2hpbGQpIHtcblx0XHRcdHN0eWxlLnJlbW92ZUNoaWxkKHN0eWxlLmZpcnN0Q2hpbGQpO1xuXHRcdH1cblxuXHRcdHN0eWxlLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNzcykpO1xuXHR9XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZUxpbmsgKGxpbmssIG9wdGlvbnMsIG9iaikge1xuXHR2YXIgY3NzID0gb2JqLmNzcztcblx0dmFyIHNvdXJjZU1hcCA9IG9iai5zb3VyY2VNYXA7XG5cblx0Lypcblx0XHRJZiBjb252ZXJ0VG9BYnNvbHV0ZVVybHMgaXNuJ3QgZGVmaW5lZCwgYnV0IHNvdXJjZW1hcHMgYXJlIGVuYWJsZWRcblx0XHRhbmQgdGhlcmUgaXMgbm8gcHVibGljUGF0aCBkZWZpbmVkIHRoZW4gbGV0cyB0dXJuIGNvbnZlcnRUb0Fic29sdXRlVXJsc1xuXHRcdG9uIGJ5IGRlZmF1bHQuICBPdGhlcndpc2UgZGVmYXVsdCB0byB0aGUgY29udmVydFRvQWJzb2x1dGVVcmxzIG9wdGlvblxuXHRcdGRpcmVjdGx5XG5cdCovXG5cdHZhciBhdXRvRml4VXJscyA9IG9wdGlvbnMuY29udmVydFRvQWJzb2x1dGVVcmxzID09PSB1bmRlZmluZWQgJiYgc291cmNlTWFwO1xuXG5cdGlmIChvcHRpb25zLmNvbnZlcnRUb0Fic29sdXRlVXJscyB8fCBhdXRvRml4VXJscykge1xuXHRcdGNzcyA9IGZpeFVybHMoY3NzKTtcblx0fVxuXG5cdGlmIChzb3VyY2VNYXApIHtcblx0XHQvLyBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8yNjYwMzg3NVxuXHRcdGNzcyArPSBcIlxcbi8qIyBzb3VyY2VNYXBwaW5nVVJMPWRhdGE6YXBwbGljYXRpb24vanNvbjtiYXNlNjQsXCIgKyBidG9hKHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChKU09OLnN0cmluZ2lmeShzb3VyY2VNYXApKSkpICsgXCIgKi9cIjtcblx0fVxuXG5cdHZhciBibG9iID0gbmV3IEJsb2IoW2Nzc10sIHsgdHlwZTogXCJ0ZXh0L2Nzc1wiIH0pO1xuXG5cdHZhciBvbGRTcmMgPSBsaW5rLmhyZWY7XG5cblx0bGluay5ocmVmID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcblxuXHRpZihvbGRTcmMpIFVSTC5yZXZva2VPYmplY3RVUkwob2xkU3JjKTtcbn1cbiIsIlxuLyoqXG4gKiBXaGVuIHNvdXJjZSBtYXBzIGFyZSBlbmFibGVkLCBgc3R5bGUtbG9hZGVyYCB1c2VzIGEgbGluayBlbGVtZW50IHdpdGggYSBkYXRhLXVyaSB0b1xuICogZW1iZWQgdGhlIGNzcyBvbiB0aGUgcGFnZS4gVGhpcyBicmVha3MgYWxsIHJlbGF0aXZlIHVybHMgYmVjYXVzZSBub3cgdGhleSBhcmUgcmVsYXRpdmUgdG8gYVxuICogYnVuZGxlIGluc3RlYWQgb2YgdGhlIGN1cnJlbnQgcGFnZS5cbiAqXG4gKiBPbmUgc29sdXRpb24gaXMgdG8gb25seSB1c2UgZnVsbCB1cmxzLCBidXQgdGhhdCBtYXkgYmUgaW1wb3NzaWJsZS5cbiAqXG4gKiBJbnN0ZWFkLCB0aGlzIGZ1bmN0aW9uIFwiZml4ZXNcIiB0aGUgcmVsYXRpdmUgdXJscyB0byBiZSBhYnNvbHV0ZSBhY2NvcmRpbmcgdG8gdGhlIGN1cnJlbnQgcGFnZSBsb2NhdGlvbi5cbiAqXG4gKiBBIHJ1ZGltZW50YXJ5IHRlc3Qgc3VpdGUgaXMgbG9jYXRlZCBhdCBgdGVzdC9maXhVcmxzLmpzYCBhbmQgY2FuIGJlIHJ1biB2aWEgdGhlIGBucG0gdGVzdGAgY29tbWFuZC5cbiAqXG4gKi9cblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoY3NzKSB7XG4gIC8vIGdldCBjdXJyZW50IGxvY2F0aW9uXG4gIHZhciBsb2NhdGlvbiA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93LmxvY2F0aW9uO1xuXG4gIGlmICghbG9jYXRpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJmaXhVcmxzIHJlcXVpcmVzIHdpbmRvdy5sb2NhdGlvblwiKTtcbiAgfVxuXG5cdC8vIGJsYW5rIG9yIG51bGw/XG5cdGlmICghY3NzIHx8IHR5cGVvZiBjc3MgIT09IFwic3RyaW5nXCIpIHtcblx0ICByZXR1cm4gY3NzO1xuICB9XG5cbiAgdmFyIGJhc2VVcmwgPSBsb2NhdGlvbi5wcm90b2NvbCArIFwiLy9cIiArIGxvY2F0aW9uLmhvc3Q7XG4gIHZhciBjdXJyZW50RGlyID0gYmFzZVVybCArIGxvY2F0aW9uLnBhdGhuYW1lLnJlcGxhY2UoL1xcL1teXFwvXSokLywgXCIvXCIpO1xuXG5cdC8vIGNvbnZlcnQgZWFjaCB1cmwoLi4uKVxuXHQvKlxuXHRUaGlzIHJlZ3VsYXIgZXhwcmVzc2lvbiBpcyBqdXN0IGEgd2F5IHRvIHJlY3Vyc2l2ZWx5IG1hdGNoIGJyYWNrZXRzIHdpdGhpblxuXHRhIHN0cmluZy5cblxuXHQgL3VybFxccypcXCggID0gTWF0Y2ggb24gdGhlIHdvcmQgXCJ1cmxcIiB3aXRoIGFueSB3aGl0ZXNwYWNlIGFmdGVyIGl0IGFuZCB0aGVuIGEgcGFyZW5zXG5cdCAgICggID0gU3RhcnQgYSBjYXB0dXJpbmcgZ3JvdXBcblx0ICAgICAoPzogID0gU3RhcnQgYSBub24tY2FwdHVyaW5nIGdyb3VwXG5cdCAgICAgICAgIFteKShdICA9IE1hdGNoIGFueXRoaW5nIHRoYXQgaXNuJ3QgYSBwYXJlbnRoZXNlc1xuXHQgICAgICAgICB8ICA9IE9SXG5cdCAgICAgICAgIFxcKCAgPSBNYXRjaCBhIHN0YXJ0IHBhcmVudGhlc2VzXG5cdCAgICAgICAgICAgICAoPzogID0gU3RhcnQgYW5vdGhlciBub24tY2FwdHVyaW5nIGdyb3Vwc1xuXHQgICAgICAgICAgICAgICAgIFteKShdKyAgPSBNYXRjaCBhbnl0aGluZyB0aGF0IGlzbid0IGEgcGFyZW50aGVzZXNcblx0ICAgICAgICAgICAgICAgICB8ICA9IE9SXG5cdCAgICAgICAgICAgICAgICAgXFwoICA9IE1hdGNoIGEgc3RhcnQgcGFyZW50aGVzZXNcblx0ICAgICAgICAgICAgICAgICAgICAgW14pKF0qICA9IE1hdGNoIGFueXRoaW5nIHRoYXQgaXNuJ3QgYSBwYXJlbnRoZXNlc1xuXHQgICAgICAgICAgICAgICAgIFxcKSAgPSBNYXRjaCBhIGVuZCBwYXJlbnRoZXNlc1xuXHQgICAgICAgICAgICAgKSAgPSBFbmQgR3JvdXBcbiAgICAgICAgICAgICAgKlxcKSA9IE1hdGNoIGFueXRoaW5nIGFuZCB0aGVuIGEgY2xvc2UgcGFyZW5zXG4gICAgICAgICAgKSAgPSBDbG9zZSBub24tY2FwdHVyaW5nIGdyb3VwXG4gICAgICAgICAgKiAgPSBNYXRjaCBhbnl0aGluZ1xuICAgICAgICkgID0gQ2xvc2UgY2FwdHVyaW5nIGdyb3VwXG5cdCBcXCkgID0gTWF0Y2ggYSBjbG9zZSBwYXJlbnNcblxuXHQgL2dpICA9IEdldCBhbGwgbWF0Y2hlcywgbm90IHRoZSBmaXJzdC4gIEJlIGNhc2UgaW5zZW5zaXRpdmUuXG5cdCAqL1xuXHR2YXIgZml4ZWRDc3MgPSBjc3MucmVwbGFjZSgvdXJsXFxzKlxcKCgoPzpbXikoXXxcXCgoPzpbXikoXSt8XFwoW14pKF0qXFwpKSpcXCkpKilcXCkvZ2ksIGZ1bmN0aW9uKGZ1bGxNYXRjaCwgb3JpZ1VybCkge1xuXHRcdC8vIHN0cmlwIHF1b3RlcyAoaWYgdGhleSBleGlzdClcblx0XHR2YXIgdW5xdW90ZWRPcmlnVXJsID0gb3JpZ1VybFxuXHRcdFx0LnRyaW0oKVxuXHRcdFx0LnJlcGxhY2UoL15cIiguKilcIiQvLCBmdW5jdGlvbihvLCAkMSl7IHJldHVybiAkMTsgfSlcblx0XHRcdC5yZXBsYWNlKC9eJyguKiknJC8sIGZ1bmN0aW9uKG8sICQxKXsgcmV0dXJuICQxOyB9KTtcblxuXHRcdC8vIGFscmVhZHkgYSBmdWxsIHVybD8gbm8gY2hhbmdlXG5cdFx0aWYgKC9eKCN8ZGF0YTp8aHR0cDpcXC9cXC98aHR0cHM6XFwvXFwvfGZpbGU6XFwvXFwvXFwvfFxccyokKS9pLnRlc3QodW5xdW90ZWRPcmlnVXJsKSkge1xuXHRcdCAgcmV0dXJuIGZ1bGxNYXRjaDtcblx0XHR9XG5cblx0XHQvLyBjb252ZXJ0IHRoZSB1cmwgdG8gYSBmdWxsIHVybFxuXHRcdHZhciBuZXdVcmw7XG5cblx0XHRpZiAodW5xdW90ZWRPcmlnVXJsLmluZGV4T2YoXCIvL1wiKSA9PT0gMCkge1xuXHRcdCAgXHQvL1RPRE86IHNob3VsZCB3ZSBhZGQgcHJvdG9jb2w/XG5cdFx0XHRuZXdVcmwgPSB1bnF1b3RlZE9yaWdVcmw7XG5cdFx0fSBlbHNlIGlmICh1bnF1b3RlZE9yaWdVcmwuaW5kZXhPZihcIi9cIikgPT09IDApIHtcblx0XHRcdC8vIHBhdGggc2hvdWxkIGJlIHJlbGF0aXZlIHRvIHRoZSBiYXNlIHVybFxuXHRcdFx0bmV3VXJsID0gYmFzZVVybCArIHVucXVvdGVkT3JpZ1VybDsgLy8gYWxyZWFkeSBzdGFydHMgd2l0aCAnLydcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gcGF0aCBzaG91bGQgYmUgcmVsYXRpdmUgdG8gY3VycmVudCBkaXJlY3Rvcnlcblx0XHRcdG5ld1VybCA9IGN1cnJlbnREaXIgKyB1bnF1b3RlZE9yaWdVcmwucmVwbGFjZSgvXlxcLlxcLy8sIFwiXCIpOyAvLyBTdHJpcCBsZWFkaW5nICcuLydcblx0XHR9XG5cblx0XHQvLyBzZW5kIGJhY2sgdGhlIGZpeGVkIHVybCguLi4pXG5cdFx0cmV0dXJuIFwidXJsKFwiICsgSlNPTi5zdHJpbmdpZnkobmV3VXJsKSArIFwiKVwiO1xuXHR9KTtcblxuXHQvLyBzZW5kIGJhY2sgdGhlIGZpeGVkIGNzc1xuXHRyZXR1cm4gZml4ZWRDc3M7XG59O1xuIiwiaW1wb3J0IGNsaWNrRWxlbWVudCBmcm9tIFwiLi9oZWxwZXJzL2NsaWNrRWxlbWVudFwiO1xuaW1wb3J0IGdldExpc3RJdGVtcyBmcm9tIFwiLi9oZWxwZXJzL2dldExpc3RJdGVtc1wiO1xuaW1wb3J0IGlzVXNlck9uU2VhcmNoUmVzdWx0c1BhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlXCI7XG5pbXBvcnQgaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZVwiO1xuaW1wb3J0IGlzVXNlck9uVHJhbnNmZXJzUGFnZSBmcm9tIFwiLi9oZWxwZXJzL2lzVXNlck9uVHJhbnNmZXJzUGFnZVwiO1xuaW1wb3J0IGlzVXNlck9uVHJhbnNmZXJUYXJnZXRzUGFnZSBmcm9tIFwiLi9oZWxwZXJzL2lzVXNlck9uVHJhbnNmZXJUYXJnZXRzUGFnZVwiO1xuaW1wb3J0IGlzVXNlck9uVW5hc3NpZ25lZFBhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblVuYXNzaWduZWRQYWdlXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGdvQmFjaygpIHtcbiAgICAvLyBQcmlvcml0aXplcyBiYWNrIGJ1dHRvbiBpbiBzZWNvbmRhcnkgbmF2LlxuICAgIGNvbnN0IHNlY29uZGFyeUhlYWRlciA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICAgIFwibmF2YmFyLXN0eWxlLXNlY29uZGFyeVwiXG4gICAgKVswXTtcblxuICAgIGlmIChzZWNvbmRhcnlIZWFkZXIgJiYgc2Vjb25kYXJ5SGVhZGVyLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYnV0dG9uXCIpWzBdKSB7XG4gICAgICAgIGNsaWNrRWxlbWVudChzZWNvbmRhcnlIZWFkZXIuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJidXR0b25cIilbMF0pO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gRmFsbHMgYmFjayB0byBwcmltYXJ5IG5hdiBiYWNrIGJ1dHRvbi5cbiAgICBpZiAoXG4gICAgICAgIGlzVXNlck9uU2VhcmNoVHJhbnNmZXJNYXJrZXRQYWdlKCkgfHxcbiAgICAgICAgaXNVc2VyT25TZWFyY2hSZXN1bHRzUGFnZSgpIHx8XG4gICAgICAgIGlzVXNlck9uVW5hc3NpZ25lZFBhZ2UoKSB8fFxuICAgICAgICBpc1VzZXJPblRyYW5zZmVyc1BhZ2UoKSB8fFxuICAgICAgICBpc1VzZXJPblRyYW5zZmVyVGFyZ2V0c1BhZ2UoKVxuICAgICkge1xuICAgICAgICBpZiAoaXNVc2VyT25TZWFyY2hSZXN1bHRzUGFnZSgpKSB7XG4gICAgICAgICAgICBjb25zdCBoYXNTZWFyY2hSZXN1bHRzID0gZ2V0TGlzdEl0ZW1zKCkubGVuZ3RoID4gMDtcblxuICAgICAgICAgICAgLy8gSWYgdGhlcmUgYXJlIG5vIHJlc3VsdHMsIHdlJ2xsIGdvIGJhY2sgcmVnYXJkbGVzcy5cbiAgICAgICAgICAgIGlmICghaGFzU2VhcmNoUmVzdWx0cykge1xuICAgICAgICAgICAgICAgIGNsaWNrRWxlbWVudChcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidXQtbmF2aWdhdGlvbi1idXR0b24tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgICAgIClbMF1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gSWYgdGhlcmUgYXJlIHJlc3VsdHMsIGNoZWNrIHNldHRpbmcgYW5kIGlmIGxhc3Qgc2VhcmNoIHdhcyBsZXNzIHRoYW4gMi41IHNlY29uZHMgYWdvLlxuICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoW1wibGFzdFNlYXJjaFRpbWVcIiwgXCJkaXNhYmxlQmFja1wiXSwgZGF0YSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBsYXN0U2VhcmNoVGltZSwgZGlzYWJsZUJhY2sgfSA9IGRhdGE7XG5cbiAgICAgICAgICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHRpbWVTaW5jZVNlYXJjaCA9IG5vdyAtIChsYXN0U2VhcmNoVGltZSB8fCAwKTtcblxuICAgICAgICAgICAgICAgIGlmICh0aW1lU2luY2VTZWFyY2ggPCAyNTAwICYmIGRpc2FibGVCYWNrKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBjbGlja0VsZW1lbnQoXG4gICAgICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidXQtbmF2aWdhdGlvbi1idXR0b24tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICApWzBdXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjbGlja0VsZW1lbnQoXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcbiAgICAgICAgICAgICAgICAgICAgXCJ1dC1uYXZpZ2F0aW9uLWJ1dHRvbi1jb250cm9sXCJcbiAgICAgICAgICAgICAgICApWzBdXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IGNvbmZpcm1Db25maXJtYXRpb25EaWFsb2cgZnJvbSBcIi4vaGVscGVycy9jb25maXJtQ29uZmlybWF0aW9uRGlhbG9nXCI7XG5pbXBvcnQgaXNVc2VyT25TZWFyY2hSZXN1bHRzUGFnZSBmcm9tIFwiLi9oZWxwZXJzL2lzVXNlck9uU2VhcmNoUmVzdWx0c1BhZ2VcIjtcbmltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vaGVscGVycy9jbGlja0VsZW1lbnRcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gYnV5Tm93KCkge1xuICAgIGlmIChpc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlKCkpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGJ1eUNhcmQoKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHt9XG4gICAgfVxufVxuXG5mdW5jdGlvbiBidXlDYXJkKCkge1xuICAgIGNsaWNrQnV5Tm93QnV0dG9uKCk7XG5cbiAgICBjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgY29uZmlybUNvbmZpcm1hdGlvbkRpYWxvZygoKSA9PiB7XG4gICAgICAgICAgICBjbGVhckludGVydmFsKHRpbWVyKTtcbiAgICAgICAgfSk7XG4gICAgfSwgMCk7XG59XG5cbmZ1bmN0aW9uIGNsaWNrQnV5Tm93QnV0dG9uKCkge1xuICAgIGNvbnN0IGJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJidXlCdXR0b25cIilbMF07XG4gICAgY2xpY2tFbGVtZW50KGJ1dHRvbik7XG59XG4iLCJpbXBvcnQgY2xpY2tFbGVtZW50IGZyb20gXCIuL2hlbHBlcnMvY2xpY2tFbGVtZW50XCI7XG5pbXBvcnQgaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZVwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBkZWNyZWFzZU1heEJpblByaWNlKCkge1xuICAgIGlmIChpc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZSgpKSB7XG4gICAgICAgIGNvbnN0IGJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJkZWNyZW1lbnQtdmFsdWVcIilbM107XG4gICAgICAgIGNsaWNrRWxlbWVudChidXR0b24pO1xuICAgIH1cbn1cbiIsImltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vY2xpY2tFbGVtZW50XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNsaWNrRGV0YWlsc1BhbmVsQnV0dG9uKGJ1dHRvbkxhYmVsOiBzdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgICAvLyBFeHBhbmQgXCJMaXN0IG9uIFRyYW5zZmVyIE1hcmtldFwiIHNlY3Rpb24uXG4gICAgICAgIGlmIChidXR0b25MYWJlbCA9PT0gXCJMaXN0IEl0ZW1cIikge1xuICAgICAgICAgICAgY29uc3QgX2J1dHRvbnMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImJ1dHRvblwiKTtcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvbnMgPSBBcnJheS5mcm9tKF9idXR0b25zKTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgYnV0dG9uIG9mIGJ1dHRvbnMpIHtcbiAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbiAmJlxuICAgICAgICAgICAgICAgICAgICBidXR0b24uaW5uZXJIVE1MLmluZGV4T2YoXCJMaXN0IG9uIFRyYW5zZmVyIE1hcmtldFwiKSA+IC0xXG4gICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgIGNsaWNrRWxlbWVudChidXR0b24pO1xuXG4gICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gR2V0IGJ1dHRvbnMgaW4gdGhlIGRldGFpbHMgcGFuZWwuXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkZXRhaWxzUGFuZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiRGV0YWlsUGFuZWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKVswXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRldGFpbHNQYW5lbEJ1dHRvbnMgPSBkZXRhaWxzUGFuZWwuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1dHRvbkFycmF5ID0gQXJyYXkuZnJvbShkZXRhaWxzUGFuZWxCdXR0b25zKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gRmluZCB0YXJnZXQgYnV0dG9uIGJ5IHNlYXJjaGluZyBieSBsYWJlbC5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IF9idXR0b24gPSBidXR0b25BcnJheS5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX19idXR0b24gPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX19idXR0b24uaW5uZXJIVE1MLmluZGV4T2YoYnV0dG9uTGFiZWwpID4gLTEgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX19idXR0b24uc3R5bGUuZGlzcGxheSAhPT0gXCJub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIClbMF07XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIENsaWNrIHRhcmdldCBidXR0b24uXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGlja0VsZW1lbnQoX2J1dHRvbik7XG4gICAgICAgICAgICAgICAgICAgIH0sIDEwMDApO1xuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBHZXQgYnV0dG9ucyBpbiB0aGUgZGV0YWlscyBwYW5lbC5cbiAgICAgICAgY29uc3QgZGV0YWlsc1BhbmVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcIkRldGFpbFBhbmVsXCIpWzBdO1xuICAgICAgICBjb25zdCBkZXRhaWxzUGFuZWxCdXR0b25zID0gZGV0YWlsc1BhbmVsLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYnV0dG9uXCIpO1xuICAgICAgICBjb25zdCBidXR0b25BcnJheSA9IEFycmF5LmZyb20oZGV0YWlsc1BhbmVsQnV0dG9ucyk7XG5cbiAgICAgICAgLy8gRmluZCB0YXJnZXQgYnV0dG9uIGJ5IHNlYXJjaGluZyBieSBsYWJlbC5cbiAgICAgICAgY29uc3QgX2J1dHRvbiA9IGJ1dHRvbkFycmF5LmZpbHRlcihcbiAgICAgICAgICAgIGZvbyA9PlxuICAgICAgICAgICAgICAgIGZvby5pbm5lckhUTUwuaW5kZXhPZihidXR0b25MYWJlbCkgPiAtMSAmJlxuICAgICAgICAgICAgICAgIGZvby5zdHlsZS5kaXNwbGF5ICE9PSBcIm5vbmVcIlxuICAgICAgICApWzBdO1xuXG4gICAgICAgIC8vIENsaWNrIHRhcmdldCBidXR0b24uXG4gICAgICAgIGNsaWNrRWxlbWVudChfYnV0dG9uKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyBcIlVuYWJsZSB0byBmaW5kIHRoYXQgYnV0dG9uLlwiO1xuICAgIH1cbn1cbiIsIi8qKlxuICogU2ltdWxhdGVzIGEgY2xpY2sgb24gYW4gZWxlbWVudC5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gY2xpY2tFbGVtZW50KGVsZW1lbnQpIHtcbiAgICBzZW5kVG91Y2hFdmVudChlbGVtZW50LCAndG91Y2hzdGFydCcpO1xuICAgIHNlbmRUb3VjaEV2ZW50KGVsZW1lbnQsICd0b3VjaGVuZCcpO1xufVxuXG4vKipcbiAqIERpc3BhdGNoZXMgYSB0b3VjaCBldmVudCBvbiB0aGUgZWxlbWVudC5cbiAqIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vYS80MjQ0NzYyMFxuICpcbiAqIEBwYXJhbSB7SFRNTEVsZW1lbnR9IGVsZW1lbnRcbiAqIEBwYXJhbSB7c3RyaW5nfSBldmVudFR5cGVcbiAqL1xuZnVuY3Rpb24gc2VuZFRvdWNoRXZlbnQoZWxlbWVudCwgZXZlbnRUeXBlKSB7XG4gICAgLyoqXG4gICAgICogVG91Y2ggY29uc3RydWN0b3IgZG9lcyB0YWtlIGFuIG9iamVjdCBpbiBDaHJvbWUsIGJ1dCB0eXBpbmdzIGFyZW4ndCB1cGRhdGVkLFxuICAgICAqIHNvIGl0IHNob3dzIGFzIGFuIGVycm9yIHdoZW4gaW4gcmVhbGl0eSBpdCdzIGZpbmUuXG4gICAgICovXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIGNvbnN0IHRvdWNoID0gbmV3IFRvdWNoKHtcbiAgICAgICAgLy8gVXNpbmcgYSBudW1iZXIgbGlrZSBUUyBzdWdnZXN0IGJyZWFrcyB0aGlzLi4uIHN0dXBpZC5cbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICBpZGVudGlmaWVyOiBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKCksXG4gICAgICAgIHRhcmdldDogZWxlbWVudCxcbiAgICAgICAgY2xpZW50WDogTWF0aC5yYW5kb20oKSxcbiAgICAgICAgY2xpZW50WTogTWF0aC5yYW5kb20oKSxcbiAgICAgICAgcmFkaXVzWDogMi41LFxuICAgICAgICByYWRpdXNZOiAyLjUsXG4gICAgICAgIHJvdGF0aW9uQW5nbGU6IDEwLFxuICAgICAgICBmb3JjZTogMC41XG4gICAgfSk7XG5cbiAgICBjb25zdCB0b3VjaEV2ZW50ID0gbmV3IFRvdWNoRXZlbnQoZXZlbnRUeXBlLCB7XG4gICAgICAgIGNhbmNlbGFibGU6IHRydWUsXG4gICAgICAgIGJ1YmJsZXM6IHRydWUsXG4gICAgICAgIHRvdWNoZXM6IFt0b3VjaF0sXG4gICAgICAgIHRhcmdldFRvdWNoZXM6IFt0b3VjaF0sXG4gICAgICAgIGNoYW5nZWRUb3VjaGVzOiBbdG91Y2hdLFxuICAgICAgICBzaGlmdEtleTogdHJ1ZVxuICAgIH0pO1xuXG4gICAgZWxlbWVudC5kaXNwYXRjaEV2ZW50KHRvdWNoRXZlbnQpO1xufVxuIiwiaW1wb3J0IGNsaWNrRWxlbWVudCBmcm9tIFwiLi9jbGlja0VsZW1lbnRcIjtcblxuLyoqXG4gKiBQcmVzc2VzIFwiT0tcIiBidXR0b24gaW4gY29uZmlybWF0aW9uIGRpYWxvZy5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gY29uZmlybUNvbmZpcm1hdGlvbkRpYWxvZyhzdWNjZXNzPzogKCkgPT4gdm9pZCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IG9rQnV0dG9uID0gZG9jdW1lbnRcbiAgICAgICAgICAgIC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiRGlhbG9nXCIpWzBdXG4gICAgICAgICAgICAuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJidXR0b25cIilbMF07XG4gICAgICAgIGNsaWNrRWxlbWVudChva0J1dHRvbik7XG4gICAgICAgIHN1Y2Nlc3MgJiYgc3VjY2VzcygpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7fVxufVxuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0TGlzdEl0ZW1CdXR0b25UZXh0KCk6IHN0cmluZyB7XG4gIGxldCBidXR0b25UZXh0ID0gXCJMaXN0IGZvciBUcmFuc2ZlclwiO1xuICBjb25zdCBsYW5ndWFnZSA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiaHRtbFwiKVswXS5sYW5nO1xuXG4gIHN3aXRjaCAobGFuZ3VhZ2UpIHtcbiAgICBjYXNlIFwiZnJcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIlBsYWNlciBzdXIgbGlzdGUgZGVzIHRyYW5zZmVydHNcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJpdFwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiTWV0dGkgc3VsIG1lcmNhdG9cIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJkZVwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiQW5iaWV0ZW5cIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJwbFwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiV3lzdGF3IG5hIGxpY3l0YWNqxJlcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJubFwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiT3AgdHJhbnNmZXJsaWpzdCBwbGFhdHNlblwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInB0XCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJMaXN0YXIgcGFyYSB0cmFuc2ZlcsOqbmNpYVwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImVzXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJBw7FhZGlyIGEgdHJhbnNmZXJpYmxlc1wiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInJ1XCI6XG4gICAgICBidXR0b25UZXh0ID0gXCLQktGL0YHRgtCw0LLQuNGC0Ywg0L3QsCDQv9GA0L7QtNCw0LbRg1wiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInRyXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJUcmFuc2ZlciBpw6dpbiBMaXN0ZWxlXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwia29cIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIuydtOyggSDrqqnroZ3sl5Ag7Jis66as6riwXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZGFcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIlPDpnQgcMOlIHRyYW5zZmVybGlzdGVuXCI7XG4gICAgICBicmVhaztcbiAgfVxuXG4gIHJldHVybiBidXR0b25UZXh0O1xufVxuIiwiaW1wb3J0IGlzVXNlck9uU2VhcmNoUmVzdWx0c1BhZ2UgZnJvbSBcIi4vaXNVc2VyT25TZWFyY2hSZXN1bHRzUGFnZVwiO1xuaW1wb3J0IGlzVXNlck9uVW5hc3NpZ25lZFBhZ2UgZnJvbSBcIi4vaXNVc2VyT25VbmFzc2lnbmVkUGFnZVwiO1xuaW1wb3J0IGlzVXNlck9uVHJhbnNmZXJzUGFnZSBmcm9tIFwiLi9pc1VzZXJPblRyYW5zZmVyc1BhZ2VcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0TGlzdEl0ZW1zKCkge1xuICAgIGxldCBpdGVtcyA9IFtdO1xuXG4gICAgaWYgKGlzVXNlck9uU2VhcmNoUmVzdWx0c1BhZ2UoKSkge1xuICAgICAgICBjb25zdCBpdGVtTGlzdCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICAgICAgICBcInBhZ2luYXRlZC1pdGVtLWxpc3RcIlxuICAgICAgICApWzBdO1xuICAgICAgICBpdGVtcyA9IEFycmF5LmZyb20oaXRlbUxpc3QuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImxpc3RGVVRJdGVtXCIpKTtcbiAgICB9IGVsc2UgaWYgKGlzVXNlck9uVW5hc3NpZ25lZFBhZ2UoKSB8fCBpc1VzZXJPblRyYW5zZmVyc1BhZ2UoKSkge1xuICAgICAgICBjb25zdCBpdGVtTGlzdHMgPSBBcnJheS5mcm9tKFxuICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcIml0ZW1MaXN0XCIpXG4gICAgICAgICk7XG4gICAgICAgIGl0ZW1MaXN0cy5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW1MaXN0KSB7XG4gICAgICAgICAgICBpdGVtcyA9IGl0ZW1zLmNvbmNhdChcbiAgICAgICAgICAgICAgICBBcnJheS5mcm9tKGl0ZW1MaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJsaXN0RlVUSXRlbVwiKSlcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0sIHRoaXMpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGl0ZW1MaXN0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcbiAgICAgICAgICAgIFwicGFnaW5hdGVkLWl0ZW0tbGlzdFwiXG4gICAgICAgIClbMF07XG4gICAgICAgIGl0ZW1zID0gQXJyYXkuZnJvbShpdGVtTGlzdC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwibGlzdEZVVEl0ZW1cIikpO1xuICAgIH1cblxuICAgIHJldHVybiBpdGVtcztcbn1cbiIsIi8qKlxuICogQ2hlY2tzIGlmIHVzZXIgaXMgb24gc3BlY2lmaWMgcGFnZS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaXNVc2VyT25QYWdlKHBhZ2VUaXRsZTogc3RyaW5nKSB7XG4gICAgY29uc3QgdGl0bGUgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCd0aXRsZScpWzBdO1xuICAgIHJldHVybiB0aXRsZSAmJiB0aXRsZS5pbm5lckhUTUwgPT09IHBhZ2VUaXRsZTtcbn1cbiIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzVXNlck9uU2VhcmNoUmVzdWx0c1BhZ2UoKTogYm9vbGVhbiB7XG4gICAgY29uc3QgZWxlbWVudHMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiU2VhcmNoUmVzdWx0c1wiKTtcbiAgICByZXR1cm4gZWxlbWVudHMubGVuZ3RoID4gMDtcbn1cbiIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzVXNlck9uU2VhcmNoVHJhbnNmZXJNYXJrZXRQYWdlKCk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IGVsZW1lbnRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcbiAgICAgICAgXCJ1dC1tYXJrZXQtc2VhcmNoLWZpbHRlcnMtdmlld1wiXG4gICAgKTtcblxuICAgIGNvbnN0IHNiY0VsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwic2JjXCIpO1xuXG4gICAgcmV0dXJuIGVsZW1lbnRzLmxlbmd0aCA+IDAgJiYgc2JjRWxlbWVudC5sZW5ndGggPT09IDA7XG59XG4iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc1VzZXJPblRyYW5zZmVyVGFyZ2V0c1BhZ2UoKTogYm9vbGVhbiB7XG4gICAgY29uc3QgZWxlbWVudHMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwidXQtd2F0Y2gtbGlzdC12aWV3XCIpO1xuICAgIHJldHVybiBlbGVtZW50cy5sZW5ndGggPiAwO1xufVxuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaXNVc2VyT25UcmFuc2ZlcnNQYWdlKCk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IGVsZW1lbnRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInV0LXRyYW5zZmVyLWxpc3Qtdmlld1wiKTtcbiAgICByZXR1cm4gZWxlbWVudHMubGVuZ3RoID4gMDtcbn1cbiIsImltcG9ydCBpc1VzZXJPblBhZ2UgZnJvbSBcIi4vaXNVc2VyT25QYWdlXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzVXNlck9uVW5hc3NpZ25lZFBhZ2UoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgLy8gRW5nbGlzaFxuICAgICAgICBpc1VzZXJPblBhZ2UoXCJVbmFzc2lnbmVkXCIpIHx8XG4gICAgICAgIC8vIEZyZW5jaFxuICAgICAgICBpc1VzZXJPblBhZ2UoXCJOT04gQVRUUklCVcOJU1wiKSB8fFxuICAgICAgICAvLyBJdGFsaWFuXG4gICAgICAgIGlzVXNlck9uUGFnZShcIk5PTiBBU1NFR05BVElcIikgfHxcbiAgICAgICAgLy8gR2VybWFuXG4gICAgICAgIGlzVXNlck9uUGFnZShcIk5JQ0hUIFpVR0VXSUVTRU5cIikgfHxcbiAgICAgICAgLy8gUG9saXNoXG4gICAgICAgIGlzVXNlck9uUGFnZShcIk5pZXByenlwaXNhbmVcIikgfHxcbiAgICAgICAgLy8gRHV0Y2hcbiAgICAgICAgaXNVc2VyT25QYWdlKFwiTklFVCBUT0VHRVdFWi5cIikgfHxcbiAgICAgICAgLy8gUG9ydHVndWVzZVxuICAgICAgICBpc1VzZXJPblBhZ2UoXCJOw6NvIEF0cmlidcOtZG9zXCIpIHx8XG4gICAgICAgIC8vIFNwYW5pc2hcbiAgICAgICAgaXNVc2VyT25QYWdlKFwiTm8gYXNpZ25hZG9zXCIpIHx8XG4gICAgICAgIC8vIFJ1c3NpYW5cbiAgICAgICAgaXNVc2VyT25QYWdlKFwi0J3QtSDQvdCw0LfQvdCw0YfQtdC90L5cIikgfHxcbiAgICAgICAgLy8gVHVya2lzaFxuICAgICAgICBpc1VzZXJPblBhZ2UoXCJBdGFubWF5YW5cIikgfHxcbiAgICAgICAgLy8gS29yZWFuXG4gICAgICAgIGlzVXNlck9uUGFnZShcIuyngOygleuQmOyngCDslYrsnYxcIilcbiAgICApO1xufVxuIiwiaW1wb3J0IGNsaWNrRWxlbWVudCBmcm9tIFwiLi9oZWxwZXJzL2NsaWNrRWxlbWVudFwiO1xuaW1wb3J0IGlzVXNlck9uU2VhcmNoVHJhbnNmZXJNYXJrZXRQYWdlIGZyb20gXCIuL2hlbHBlcnMvaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2VcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaW5jcmVhc2VNYXhCaW5QcmljZSgpIHtcbiAgICBpZiAoaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UoKSkge1xuICAgICAgICBjb25zdCBidXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiaW5jcmVtZW50LXZhbHVlXCIpWzNdO1xuICAgICAgICBjbGlja0VsZW1lbnQoYnV0dG9uKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgY2xpY2tFbGVtZW50IGZyb20gXCIuL2hlbHBlcnMvY2xpY2tFbGVtZW50XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGluY3JlYXNlTWluQmlkUHJpY2UoKSB7XG4gICAgY29uc3QgYnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImluY3JlbWVudC12YWx1ZVwiKVswXTtcbiAgICBjbGlja0VsZW1lbnQoYnV0dG9uKTtcbn1cbiIsImltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vaGVscGVycy9jbGlja0VsZW1lbnRcIjtcbmltcG9ydCBpc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZSBmcm9tIFwiLi9oZWxwZXJzL2lzVXNlck9uU2VhcmNoVHJhbnNmZXJNYXJrZXRQYWdlXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGluY3JlYXNlTWluQmluUHJpY2UoKSB7XG4gICAgaWYgKGlzVXNlck9uU2VhcmNoVHJhbnNmZXJNYXJrZXRQYWdlKCkpIHtcbiAgICAgICAgY29uc3QgYnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImluY3JlbWVudC12YWx1ZVwiKVsyXTtcbiAgICAgICAgY2xpY2tFbGVtZW50KGJ1dHRvbik7XG4gICAgfVxufVxuIiwiaW1wb3J0IGNsaWNrRWxlbWVudCBmcm9tIFwiLi9oZWxwZXJzL2NsaWNrRWxlbWVudFwiO1xuaW1wb3J0IGdldExpc3RJdGVtQnV0dG9uVGV4dCBmcm9tIFwiLi9oZWxwZXJzL2dldExpc3RJdGVtQnV0dG9uVGV4dFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBsaXN0KHN0YXJ0UHJpY2U6IHN0cmluZywgYnV5Tm93UHJpY2U6IHN0cmluZykge1xuICAgIGNvbnN0IHF1aWNrTGlzdFBhbmVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcIkRldGFpbFBhbmVsXCIpWzBdO1xuXG4gICAgY29uc3QgcXVpY2tMaXN0UGFuZWxBY3Rpb25zID0gcXVpY2tMaXN0UGFuZWwuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcbiAgICAgICAgXCJwYW5lbEFjdGlvbnNcIlxuICAgIClbMF07XG5cbiAgICBjb25zdCBhY3Rpb25Sb3dzID0gcXVpY2tMaXN0UGFuZWxBY3Rpb25zLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICAgIFwicGFuZWxBY3Rpb25Sb3dcIlxuICAgICk7XG5cbiAgICBpZiAoc3RhcnRQcmljZSkge1xuICAgICAgICBjb25zdCBzdGFydFByaWNlUm93ID0gYWN0aW9uUm93c1sxXTtcbiAgICAgICAgY29uc3Qgc3RhcnRQcmljZUlucHV0ID0gc3RhcnRQcmljZVJvdy5nZXRFbGVtZW50c0J5VGFnTmFtZShcImlucHV0XCIpWzBdO1xuICAgICAgICBzdGFydFByaWNlSW5wdXQudmFsdWUgPSBzdGFydFByaWNlO1xuICAgIH1cblxuICAgIGlmIChidXlOb3dQcmljZSkge1xuICAgICAgICBjb25zdCBiaW5Sb3cgPSBhY3Rpb25Sb3dzWzJdO1xuICAgICAgICBjb25zdCBiaW5JbnB1dCA9IGJpblJvdy5nZXRFbGVtZW50c0J5VGFnTmFtZShcImlucHV0XCIpWzBdO1xuICAgICAgICBiaW5JbnB1dC52YWx1ZSA9IGJ1eU5vd1ByaWNlLnRvU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgLy8gR2V0IGFsbCBidXR0b25zIGluIFwiTGlzdCBvbiBUcmFuc2ZlciBNYXJrZXRcIiBzZWN0aW9uLlxuICAgIGNvbnN0IF9idXR0b25zID0gcXVpY2tMaXN0UGFuZWxBY3Rpb25zLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYnV0dG9uXCIpO1xuICAgIGNvbnN0IGJ1dHRvbnM6IEhUTUxFbGVtZW50W10gPSBBcnJheS5mcm9tKF9idXR0b25zKTtcblxuICAgIC8vIEZpbmQgYnV0dG9uIHdpdGggXCJMaXN0IEl0ZW1cIiBhcyB0ZXh0IGFuZCB0YXAgaXQuXG4gICAgbGV0IGxpc3RJdGVtQnV0dG9uO1xuICAgIGNvbnN0IGJ1dHRvblRleHQgPSBnZXRMaXN0SXRlbUJ1dHRvblRleHQoKTtcbiAgICBmb3IgKGNvbnN0IGJ1dHRvbiBvZiBidXR0b25zKSB7XG4gICAgICAgIGlmIChidXR0b24gJiYgYnV0dG9uLmlubmVySFRNTCA9PT0gYnV0dG9uVGV4dCkge1xuICAgICAgICAgICAgbGlzdEl0ZW1CdXR0b24gPSBidXR0b247XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBjbGlja0VsZW1lbnQobGlzdEl0ZW1CdXR0b24pO1xufVxuIiwiaW1wb3J0IGJ1eU5vdyBmcm9tIFwiLi9idXlOb3dcIjtcbmltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vaGVscGVycy9jbGlja0VsZW1lbnRcIjtcbmltcG9ydCBnZXRMaXN0SXRlbXMgZnJvbSBcIi4vaGVscGVycy9nZXRMaXN0SXRlbXNcIjtcbmltcG9ydCBpc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZSBmcm9tIFwiLi9oZWxwZXJzL2lzVXNlck9uU2VhcmNoVHJhbnNmZXJNYXJrZXRQYWdlXCI7XG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuLi9jb250ZW50U2NyaXB0LnNjc3NcIjtcblxubGV0IGRhbmdlcm91c0ludGVydmFsID0gbnVsbDtcbmxldCBnbG9iYWxJbnRlcnZhbElkID0gMDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gc2VhcmNoKGRvSGFuZHNmcmVlQmluOiBib29sZWFuKSB7XG4gIGlmICghaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UoKSkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8vIENsZWFyIGludGVydmFsIHdoZW4gbmV3IHNlYXJjaCBpcyBoYXBwZW5pbmcuXG4gIGNsZWFyRGFuZ2Vyb3VzSW50ZXJ2YWwoKTtcblxuICBjb25zdCBzZWFyY2hCdXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgIFwiYnRuLXN0YW5kYXJkIGNhbGwtdG8tYWN0aW9uXCJcbiAgKVswXTtcblxuICBjbGlja0VsZW1lbnQoc2VhcmNoQnV0dG9uKTtcblxuICBjb25zdCBvbGRTZWFyY2hDb3VudCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInNlYXJjaENvdW50XCIpO1xuICBjb25zdCBuZXdTZWFyY2hDb3VudCA9IG9sZFNlYXJjaENvdW50ID8gcGFyc2VJbnQob2xkU2VhcmNoQ291bnQpICsgMSA6IDE7XG4gIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInNlYXJjaENvdW50XCIsIG5ld1NlYXJjaENvdW50LnRvU3RyaW5nKCkpO1xuXG4gIGlmIChuZXdTZWFyY2hDb3VudCA9PT0gMSkge1xuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFtcImRpc2NvcmRXZWJob29rQ2FyZFNlZW5cIl0sIChkYXRhKSA9PiB7XG4gICAgICBpZiAoZGF0YS5kaXNjb3JkV2ViaG9va0NhcmRTZWVuKSB7XG4gICAgICAgIC8vIFRPRE86IEFkZCBcInN0YXJ0ZWRcIiBtZXNzYWdlIHdoZW4gd2UgZG8gbG9nZ2luZ1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLy8gaW5jcmVtZW1lbnQgSUQgdG8gdHJhY2sgbmV3IGludGVydmFsXG4gIGdsb2JhbEludGVydmFsSWQgPSBnbG9iYWxJbnRlcnZhbElkICsgMTtcbiAgY29uc3QgaXRlcmF0aW9uSWQgPSBnbG9iYWxJbnRlcnZhbElkO1xuXG4gIGRhbmdlcm91c0ludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBoYXNTZWFyY2hSZXN1bHRzID0gZ2V0TGlzdEl0ZW1zKCkubGVuZ3RoID4gMDtcbiAgICAgIGNvbnN0IGlzTm9SZXN1bHRzUGFnZSA9XG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ1dC1uby1yZXN1bHRzLXZpZXdcIikubGVuZ3RoID4gMDtcblxuICAgICAgaWYgKGhhc1NlYXJjaFJlc3VsdHMgfHwgaXNOb1Jlc3VsdHNQYWdlKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgaXRlbXMgPSBnZXRMaXN0SXRlbXMoKTtcbiAgICAgICAgICBjbGlja0VsZW1lbnQoXG4gICAgICAgICAgICBpdGVtc1tpdGVtcy5sZW5ndGggLSAxXS5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgICAgICAgICAgICBcImhhcy10YXAtY2FsbGJhY2tcIlxuICAgICAgICAgICAgKVswXVxuICAgICAgICAgICk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7fVxuXG4gICAgICAgIGlmIChkb0hhbmRzZnJlZUJpbikge1xuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgaGFuZHNmcmVlQmluKCk7XG4gICAgICAgICAgfSwgNTApO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQ2xlYXIgaW50ZXJ2YWwgb25jZSBzZWFyY2ggaGFzIGNvbXBsZXRlZC5cbiAgICAgICAgY2xlYXJEYW5nZXJvdXNJbnRlcnZhbCgpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHt9XG4gIH0sIDApO1xuXG4gIC8vIGNsZWFyIGRhbmdlcm91cyB0aW1lciBhZnRlciBhIGZldyBzZWNvbmRzXG4gIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgIGNsZWFyRGFuZ2Vyb3VzSW50ZXJ2YWwoaXRlcmF0aW9uSWQpO1xuICB9LCAzNTAwKTtcbn1cblxuY29uc3QgaGFuZHNmcmVlQmluID0gKCkgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IGlzQnV5QnV0dG9uUHJlc2VudCA9XG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiYnV5QnV0dG9uXCIpLmxlbmd0aCA+IDA7XG5cbiAgICBpZiAoaXNCdXlCdXR0b25QcmVzZW50KSB7XG4gICAgICBidXlOb3coKTtcblxuICAgICAgLy8gaW5jcmVtZW50cyBzZWVuIGNvdW50XG4gICAgICBjb25zdCBvbGRDb3VudCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInNlZW5Db3VudFwiKTtcbiAgICAgIGNvbnN0IG5ld0NvdW50ID0gb2xkQ291bnQgPyBwYXJzZUludChvbGRDb3VudCkgKyAxIDogMTtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInNlZW5Db3VudFwiLCBuZXdDb3VudC50b1N0cmluZygpKTtcblxuICAgICAgLy8gbm90ZXMgdGhhdCB3ZSBqdXN0IHNhdyBhIGNhcmQgZm9yIFwiY2FyZCBwdXJjaGFzZWRcIiBjb3VudFxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwianVzdFNhd0NhcmRcIiwgXCJ0cnVlXCIpO1xuXG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldChcbiAgICAgICAgW1wic2hvdWxkUGxheVJlc3VsdFNlZW5Tb3VuZFwiLCBcImRpc2NvcmRXZWJob29rQ2FyZFNlZW5cIl0sXG4gICAgICAgIChkYXRhKSA9PiB7XG4gICAgICAgICAgaWYgKGRhdGEuc2hvdWxkUGxheVJlc3VsdFNlZW5Tb3VuZCkge1xuICAgICAgICAgICAgY29uc3QgY2FyZFNlZW5Tb3VuZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFxuICAgICAgICAgICAgICBzdHlsZXMuY2FyZFNlZW5Tb3VuZFxuICAgICAgICAgICAgKSBhcyBIVE1MQXVkaW9FbGVtZW50O1xuICAgICAgICAgICAgY2FyZFNlZW5Tb3VuZC5wbGF5KCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKGRhdGEuZGlzY29yZFdlYmhvb2tDYXJkU2Vlbikge1xuICAgICAgICAgICAgZmV0Y2hfcmV0cnkoXG4gICAgICAgICAgICAgIGRhdGEuZGlzY29yZFdlYmhvb2tDYXJkU2VlbixcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgY29udGVudDogYEEgY2FyZCBwb3BwZWQgdXBgLFxuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIDVcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgfSBjYXRjaCAoZSkge31cbn07XG5cbi8qKlxuICogY2xlYXIgdGltZXIgaWYgbm8gSUQgaXMgcGFzc2VkIG9yIGlmIElEIG1hdGNoZXMgZ2xvYmFsXG4gKi9cbmNvbnN0IGNsZWFyRGFuZ2Vyb3VzSW50ZXJ2YWwgPSAoaW50ZXJ2YWxJZD86IG51bWJlcikgPT4ge1xuICBpZiAoIWludGVydmFsSWQgfHwgaW50ZXJ2YWxJZCA9PT0gZ2xvYmFsSW50ZXJ2YWxJZCkge1xuICAgIGNsZWFySW50ZXJ2YWwoZGFuZ2Vyb3VzSW50ZXJ2YWwpO1xuICB9XG59O1xuXG5jb25zdCBmZXRjaF9yZXRyeSA9ICh1cmwsIG9wdGlvbnMsIG4pID0+XG4gIGZldGNoKHVybCwgb3B0aW9ucykuY2F0Y2goZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgaWYgKG4gPT09IDEpIHRocm93IGVycm9yO1xuICAgIHJldHVybiBmZXRjaF9yZXRyeSh1cmwsIG9wdGlvbnMsIG4gLSAxKTtcbiAgfSk7XG4iLCJpbXBvcnQgY2xpY2tEZXRhaWxzUGFuZWxCdXR0b24gZnJvbSBcIi4vaGVscGVycy9jbGlja0RldGFpbHNQYW5lbEJ1dHRvblwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzZW5kVG9UcmFuc2Zlckxpc3QoKSB7XG4gIGxldCBidXR0b25UZXh0ID0gXCJTZW5kIHRvIFRyYW5zZmVyIExpc3RcIjtcbiAgY29uc3QgbGFuZ3VhZ2UgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImh0bWxcIilbMF0ubGFuZztcblxuICBzd2l0Y2ggKGxhbmd1YWdlKSB7XG4gICAgY2FzZSBcImZyXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJFbnYuIExpc3RlIHRyYW5zZi5cIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJpdFwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiSW52aWEgYSB0cmFzZmVyaW0uXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZGVcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIkF1ZiBUcmFuc2Zlcmxpc3RlXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwicGxcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIld5xZtsaWogbmEgbGlzdMSZIHRyYW5zZmVyb3fEhVwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcIm5sXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJOYWFyIHRyYW5zZmVybGlqc3RcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJwdFwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiRW52aWFyIHBhcmEgVHJhbnNmZXIuXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZXNcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIkVudmlhciBhIHRyYW5zZmVyaWJsZXNcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJydVwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwi0J7RgtC/0YDQsNCy0LjRgtGMINCyINGB0L/QuNGB0L7QuiDQv9GA0L7QtNCw0LZcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJ0clwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiVHJhbnNmZXIgTGlzdGVzaeKAmW5lIEfDtm5kZXJcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJrb1wiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwi7J207KCBIOuqqeuhneycvOuhnCDrs7TrgrTquLBcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJkYVwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiU2VuZCB0aWwgdHJhbnNmZXJsaXN0ZW5cIjtcbiAgICAgIGJyZWFrO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjbGlja0RldGFpbHNQYW5lbEJ1dHRvbihidXR0b25UZXh0KTtcbiAgfSBjYXRjaCAoZXJyb3IpIHt9XG59XG4iLCJpbXBvcnQgY2xpY2tEZXRhaWxzUGFuZWxCdXR0b24gZnJvbSBcIi4vaGVscGVycy9jbGlja0RldGFpbHNQYW5lbEJ1dHRvblwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzdG9yZUluQ2x1YigpIHtcbiAgbGV0IGJ1dHRvblRleHQgPSBcIlNlbmQgdG8gTXkgQ2x1YlwiO1xuICBjb25zdCBsYW5ndWFnZSA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiaHRtbFwiKVswXS5sYW5nO1xuXG4gIHN3aXRjaCAobGFuZ3VhZ2UpIHtcbiAgICBjYXNlIFwiZnJcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIkVudm95ZXIgdmVycyBNb24gY2x1YlwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcIml0XCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJJbnZpYSBhIElsIG1pbyBjbHViXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZGVcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIlp1IE1laW4gVmVyZWluXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwicGxcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIld5xZtsaWogZG8ga2x1YnVcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJubFwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiTmFhciBNaWpuIGNsdWIgc3R1cmVuXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwicHRcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIkVudmlhciBhbyBNZXUgY2x1YmVcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJlc1wiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiRW52aWFyIGEgTWkgY2x1YlwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInJ1XCI6XG4gICAgICBidXR0b25UZXh0ID0gXCLQntGC0L/RgNCw0LLQuNGC0Ywg0LIg0JzQvtC5INC60LvRg9CxXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwidHJcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIkt1bMO8YsO8bWUgR8O2bmRlclwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImtvXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCLrgrQg7YG065+97Jy866GcIOuztOuCtOq4sFwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImRhXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJTZW5kIHRpbCBNaW4ga2x1YlwiO1xuICAgICAgYnJlYWs7XG4gIH1cblxuICB0cnkge1xuICAgIGNsaWNrRGV0YWlsc1BhbmVsQnV0dG9uKGJ1dHRvblRleHQpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIC8vXG4gIH1cbn1cbiIsImltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vYWN0aW9ucy9oZWxwZXJzL2NsaWNrRWxlbWVudFwiO1xyXG5pbXBvcnQgaXNVc2VyT25UcmFuc2ZlclRhcmdldHNQYWdlIGZyb20gXCIuL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblRyYW5zZmVyVGFyZ2V0c1BhZ2VcIjtcclxuaW1wb3J0IHsgc3RvcEF1dG9idXllciB9IGZyb20gXCIuL2NvbnRlbnRTY3JpcHRcIjtcclxuXHJcbmxldCBwYWdlRmxpcHBlclRpbWVyID0gbnVsbDtcclxubGV0IGJpZGRlclRpbWVyID0gbnVsbDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHN0YXJ0QmlkZGVyKFxyXG4gIG1heEJpZEFtb3VudDogbnVtYmVyLFxyXG4gIGR1cmF0aW9uOiBudW1iZXIsXHJcbiAgc2hvdWxkQmlkTWF4OiBib29sZWFuXHJcbikge1xyXG4gIC8vIG5vdGUgdGhhdCBiaWRkZXIgaXMgcnVubmluZ1xyXG4gIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYmlkZGVyXCIsIFwib25cIik7XHJcblxyXG4gIGJpZGRlclRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICBzdG9wQmlkZGVyKGBCb3Qgc3RvcHBlZCBiZWNhdXNlIGl0IHJhbiBmb3IgJHtkdXJhdGlvbn0gbWludXRlcy5gKTtcclxuICB9LCBkdXJhdGlvbiAqIDYwMDAwKTtcclxuXHJcbiAgLy8gc2V0IG1heCBiaWQgdG8gdXNlcidzIHByZWZlcmVuY2VcclxuICAoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgIFwibnVtZXJpY0lucHV0XCJcclxuICApWzFdIGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlID0gbWF4QmlkQW1vdW50LnRvU3RyaW5nKCk7XHJcblxyXG4gIC8vIGNsaWNrIGJ1dHRvbnMgdG8gbG9jayBpdCBpblxyXG4gIGNsaWNrRWxlbWVudChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiaW5jcmVtZW50LXZhbHVlXCIpWzFdKTtcclxuICBjbGlja0VsZW1lbnQoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImRlY3JlbWVudC12YWx1ZVwiKVsxXSk7XHJcbiAgY2xpY2tFbGVtZW50KGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJkZWNyZW1lbnQtdmFsdWVcIilbMV0pO1xyXG5cclxuICAvLyBzZXQgbWF4IEJJTiB0byAxNSwwMDAsMDAwXHJcbiAgKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXHJcbiAgICBcIm51bWVyaWNJbnB1dFwiXHJcbiAgKVszXSBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZSA9IFwiMTQ5OTk5OTlcIjtcclxuXHJcbiAgLy8gY2xpY2sgaW5jcmVtZW50IGJ1dHRvbiB0byBsb2NrIGl0IGluXHJcbiAgY29uc3QgaW5jcmVtZW50QnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImluY3JlbWVudC12YWx1ZVwiKVszXTtcclxuICBjbGlja0VsZW1lbnQoaW5jcmVtZW50QnV0dG9uKTtcclxuXHJcbiAgLy8gbGV0J3MgZG8gaXRcclxuICBkb1dvcmsobWF4QmlkQW1vdW50LCBzaG91bGRCaWRNYXgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBkb1dvcmsobWF4QmlkQW1vdW50OiBudW1iZXIsIHNob3VsZEJpZE1heDogYm9vbGVhbikge1xyXG4gIC8vIGRlY3JlbWVudCBtYXggQklOIHRvIGdldCBmcmVzaCByZXN1bHRzXHJcbiAgY29uc3QgZGVjcmVtZW50QnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImRlY3JlbWVudC12YWx1ZVwiKVszXTtcclxuICBjbGlja0VsZW1lbnQoZGVjcmVtZW50QnV0dG9uKTtcclxuXHJcbiAgLy8gZXhlY3V0ZSBhIHNlYXJjaFxyXG4gIGNvbnN0IHNlYXJjaEJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXHJcbiAgICBcImJ0bi1zdGFuZGFyZCBjYWxsLXRvLWFjdGlvblwiXHJcbiAgKVswXTtcclxuICBjbGlja0VsZW1lbnQoc2VhcmNoQnV0dG9uKTtcclxuXHJcbiAgLy8gYmlkIG9uIHNlYXJjaCByZXN1bHRzXHJcbiAgYmlkT25TZWFyY2hSZXN1bHRzKG1heEJpZEFtb3VudCwgc2hvdWxkQmlkTWF4KTtcclxufVxyXG5cclxuY29uc3QgYmlkT25TZWFyY2hSZXN1bHRzID0gKG1heEJpZEFtb3VudDogbnVtYmVyLCBzaG91bGRCaWRNYXg6IGJvb2xlYW4pID0+IHtcclxuICAvLyBjaGVjayBpZiBib3QgaGFzIGJlZW4gc3RvcHBlZFxyXG4gIGlmIChsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJpZGRlclwiKSA9PT0gXCJvZmZcIikge1xyXG4gICAgY2xlYXJUaW1lb3V0KHBhZ2VGbGlwcGVyVGltZXIpO1xyXG4gICAgcGFnZUZsaXBwZXJUaW1lciA9IG51bGw7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICAvLyBnZXQgaXRlbXMgKGFsbG93IHRpbWUgZm9yIHNlYXJjaCB0byBmaW5pc2gpXHJcbiAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICBjb25zdCBpdGVtTGlzdCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJwYWdpbmF0ZWQtaXRlbS1saXN0XCIpWzBdO1xyXG4gICAgY29uc3QgaXRlbXMgPSBBcnJheS5mcm9tKGl0ZW1MaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJsaXN0RlVUSXRlbVwiKSk7XHJcblxyXG4gICAgbGV0IGl0ZW1zVG9CaWRPbkNvdW50ID0gMDtcclxuXHJcbiAgICAvLyBpZiB0aGVyZSBhcmUgbm8gc2VhcmNoIHJlc3VsdHMsIHdlIG5lZWQgdG8gZ28gYmFjayBhbmQgcmUtc2VhcmNoXHJcbiAgICBpZiAoaXRlbXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIC8vIGdvIGJhY2sgdG8gc2VhcmNoIHBhZ2VcclxuICAgICAgICBjbGlja0VsZW1lbnQoXHJcbiAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwidXQtbmF2aWdhdGlvbi1idXR0b24tY29udHJvbFwiKVswXVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIGdvIGFnYWluXHJcbiAgICAgICAgZG9Xb3JrKG1heEJpZEFtb3VudCwgc2hvdWxkQmlkTWF4KTtcclxuICAgICAgfSwgMjUwKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBpdGVyYXRlIHRocm91Z2ggaXRlbXMgYW5kIGRvIHdvcmtcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgY29uc3QgdmFsID0gaTsgLy8gc3RvcmVzIHZhbHVlIHNvIHByb3BlciBpdGVtIGlzIHNlbGVjdGVkXHJcblxyXG4gICAgICAvLyAtIHNraXAgcHJvY2Vzc2luZyB0aGUgaXRlbSBpZiB1c2VyIGFscmVhZHkgaGFzIGhpZ2hlc3QgYmlkXHJcbiAgICAgIC8vIC0gZG9uJ3Qgc2tpcCBpZiBpdCdzIHRoZSBsYXN0IG9uZSBzbyB3ZSBjYW4gZ28gdG8gbmV4dCBwYWdlXHJcbiAgICAgIGlmIChcclxuICAgICAgICBpdGVtc1t2YWxdLmNsYXNzTGlzdC5jb250YWlucyhcImhpZ2hlc3QtYmlkXCIpICYmXHJcbiAgICAgICAgaSAhPT0gaXRlbXMubGVuZ3RoIC0gMVxyXG4gICAgICApIHtcclxuICAgICAgICBjb250aW51ZTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpdGVtc1RvQmlkT25Db3VudCsrO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAvLyBjaGVjayBpZiBib3QgaGFzIGJlZW4gc3RvcHBlZFxyXG4gICAgICAgIGlmIChsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJpZGRlclwiKSA9PT0gXCJvZmZcIikge1xyXG4gICAgICAgICAgY2xlYXJUaW1lb3V0KHBhZ2VGbGlwcGVyVGltZXIpO1xyXG4gICAgICAgICAgcGFnZUZsaXBwZXJUaW1lciA9IG51bGw7XHJcbiAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICAoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgICAgICAgICAgXCJkaWFsb2ctdGl0bGVcIlxyXG4gICAgICAgICAgKT8uWzBdIGFzIEhUTUxTcGFuRWxlbWVudCk/LmlubmVyVGV4dC5zdGFydHNXaXRoKFwiTElNSVRcIilcclxuICAgICAgICApIHtcclxuICAgICAgICAgIHN0b3BCaWRkZXIoXCJCb3Qgc3RvcHBlZCBiZWNhdXNlIHRyYW5zZmVyIHRhcmdldHMgbGlzdCBpcyBmdWxsLlwiKTtcclxuICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHNlbGVjdCBpdGVtXHJcbiAgICAgICAgY2xpY2tFbGVtZW50KGl0ZW1zW3ZhbF0uZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImhhcy10YXAtY2FsbGJhY2tcIilbMF0pO1xyXG5cclxuICAgICAgICAvLyBiaWQgb24gaXRlbVxyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgaWYgKCFpdGVtc1t2YWxdLmNsYXNzTGlzdC5jb250YWlucyhcImhpZ2hlc3QtYmlkXCIpKSB7XHJcbiAgICAgICAgICAgIC8vIGdldCBjdXJyZW50IGJpZCBwcmljZVxyXG4gICAgICAgICAgICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiY3VycmVudEJpZFwiKVswXTtcclxuICAgICAgICAgICAgY29uc3QgY3VycmVudEJpZCA9IChjb250YWluZXIuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgICAgICAgICAgICBcImN1cnJlbmN5LWNvaW5zXCJcclxuICAgICAgICAgICAgKVswXSBhcyBIVE1MU3BhbkVsZW1lbnQpLmlubmVyVGV4dDtcclxuICAgICAgICAgICAgY29uc3QgY3VycmVudEJpZE51bWJlciA9IHBhcnNlSW50KFxyXG4gICAgICAgICAgICAgIGN1cnJlbnRCaWQucmVwbGFjZSgvWy4sIFxcdTAwYTBcXHUyMDJGXSovZywgXCJcIilcclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGlmIGN1cnJlbnQgYmlkIGlzIGxlc3MgdGhhbiBtYXggYmlkIGFtb3VudCwgdGhlbiBiaWRcclxuICAgICAgICAgICAgaWYgKGN1cnJlbnRCaWROdW1iZXIgPCBtYXhCaWRBbW91bnQpIHtcclxuICAgICAgICAgICAgICAvLyBpZiBcImFsd2F5cyBiaWQgbWF4XCIgaXMgZW5hYmxlZCwgcmVwbGFjZSBiaWQgYW1vdW50IHZhbHVlXHJcbiAgICAgICAgICAgICAgaWYgKHNob3VsZEJpZE1heCkge1xyXG4gICAgICAgICAgICAgICAgKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXHJcbiAgICAgICAgICAgICAgICAgIFwibnVtZXJpY0lucHV0XCJcclxuICAgICAgICAgICAgICAgIClbMF0gYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWUgPSBtYXhCaWRBbW91bnQudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIGNsaWNrRWxlbWVudChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiYmlkQnV0dG9uXCIpWzBdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXHJcbiAgICAgICAgICAgICAgXCJkaWFsb2ctdGl0bGVcIlxyXG4gICAgICAgICAgICApPy5bMF0gYXMgSFRNTFNwYW5FbGVtZW50KT8uaW5uZXJUZXh0LnN0YXJ0c1dpdGgoXCJMSU1JVFwiKVxyXG4gICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHN0b3BCaWRkZXIoXCJCb3Qgc3RvcHBlZCBiZWNhdXNlIHRyYW5zZmVyIHRhcmdldHMgbGlzdCBpcyBmdWxsLlwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIC8vIGNoZWNrIGZvciBuZXh0IHBhZ2UgYWZ0ZXIgcHJvY2Vzc2luZyBsYXN0IGl0ZW1cclxuICAgICAgICAgIGlmIChpID09PSBpdGVtcy5sZW5ndGggLSAxKSB7XHJcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IG5leHRQYWdlQnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgICAgICAgICAgICAgIFwicGFnaW5hdGlvbiBuZXh0XCJcclxuICAgICAgICAgICAgICApWzBdIGFzIEhUTUxCdXR0b25FbGVtZW50O1xyXG5cclxuICAgICAgICAgICAgICBpZiAobmV4dFBhZ2VCdXR0b24uc3R5bGUuZGlzcGxheSA9PT0gXCJub25lXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vIGdvIGJhY2sgdG8gc2VhcmNoIHBhZ2VcclxuICAgICAgICAgICAgICAgIGNsaWNrRWxlbWVudChcclxuICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgICAgICAgICAgICAgICAgICBcInV0LW5hdmlnYXRpb24tYnV0dG9uLWNvbnRyb2xcIlxyXG4gICAgICAgICAgICAgICAgICApWzBdXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIGdvIGFnYWluXHJcbiAgICAgICAgICAgICAgICBkb1dvcmsobWF4QmlkQW1vdW50LCBzaG91bGRCaWRNYXgpO1xyXG4gICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjbGlja0VsZW1lbnQobmV4dFBhZ2VCdXR0b24pO1xyXG4gICAgICAgICAgICAgICAgYmlkT25TZWFyY2hSZXN1bHRzKG1heEJpZEFtb3VudCwgc2hvdWxkQmlkTWF4KTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIDI1MCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSwgMTAwICsgcmFuZG9taXplKCkpO1xyXG4gICAgICB9LCAxNTAwICogaXRlbXNUb0JpZE9uQ291bnQpO1xyXG4gICAgfVxyXG4gIH0sIDIwMDAgKyByYW5kb21pemUoMTAwMCkpO1xyXG59O1xyXG5cclxuY29uc3Qgc3RvcEJpZGRlciA9IChyZWFzb246IHN0cmluZykgPT4ge1xyXG4gIC8vIGNoZWNrIGlmIGJvdCBoYXMgYmVlbiBzdG9wcGVkXHJcbiAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYmlkZGVyXCIpID09PSBcIm9mZlwiKSB7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICBjbGVhclRpbWVvdXQocGFnZUZsaXBwZXJUaW1lcik7XHJcbiAgcGFnZUZsaXBwZXJUaW1lciA9IG51bGw7XHJcblxyXG4gIGNsZWFyVGltZW91dChiaWRkZXJUaW1lcik7XHJcbiAgYmlkZGVyVGltZXIgPSBudWxsO1xyXG5cclxuICBzdG9wQXV0b2J1eWVyKHJlYXNvbik7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgY2xlYW51cFRyYW5zZmVyVGFyZ2V0cyA9ICgpID0+IHtcclxuICBpZiAoIWlzVXNlck9uVHJhbnNmZXJUYXJnZXRzUGFnZSgpKSB7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICAvLyBnZXRzIGFsbCBpdGVtIGdyb3VwcyBvbiB0cmFuc2ZlciB0YXJnZXRzIHBhZ2VcclxuICBjb25zdCBpdGVtTGlzdHMgPSBBcnJheS5mcm9tKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJpdGVtTGlzdFwiKSk7XHJcblxyXG4gIC8vIGdldHMgaXRlbXMgZnJvbSB0aGUgZmlyc3Qgc2VjdGlvblxyXG4gIGNvbnN0IGFjdGl2ZUl0ZW1zID0gQXJyYXkuZnJvbShcclxuICAgIGl0ZW1MaXN0c1swXS5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwibGlzdEZVVEl0ZW1cIilcclxuICApO1xyXG5cclxuICBsZXQgaXRlbXNUb1Vud2F0Y2hDb3VudCA9IDA7XHJcblxyXG4gIC8vIGl0ZXJhdGUgdGhyb3VnaCBpdGVtcyBhbmQgZG8gd29ya1xyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYWN0aXZlSXRlbXMubGVuZ3RoOyBpKyspIHtcclxuICAgIGNvbnN0IHZhbCA9IGk7IC8vIHN0b3JlcyB2YWx1ZSBzbyBwcm9wZXIgaXRlbSBpcyBzZWxlY3RlZFxyXG5cclxuICAgIC8vIC0gc2tpcCBwcm9jZXNzaW5nIHRoZSBpdGVtIGlmIHVzZXIgaXNuJ3Qgb3V0YmlkXHJcbiAgICAvLyAtIGRvbid0IHNraXAgaWYgaXQncyB0aGUgbGFzdCBvbmUgc28gd2UgY2FuIGdvIHRvIG5leHQgcGFnZVxyXG4gICAgaWYgKFxyXG4gICAgICAhYWN0aXZlSXRlbXNbdmFsXS5jbGFzc0xpc3QuY29udGFpbnMoXCJvdXRiaWRcIikgJiZcclxuICAgICAgaSAhPT0gYWN0aXZlSXRlbXMubGVuZ3RoIC0gMVxyXG4gICAgKSB7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaXRlbXNUb1Vud2F0Y2hDb3VudCsrO1xyXG4gICAgfVxyXG5cclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAvLyBzZWxlY3QgaXRlbVxyXG4gICAgICBjbGlja0VsZW1lbnQoXHJcbiAgICAgICAgYWN0aXZlSXRlbXNbdmFsXS5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiaGFzLXRhcC1jYWxsYmFja1wiKVswXVxyXG4gICAgICApO1xyXG5cclxuICAgICAgLy8gdW53YXRjaCBpdGVtXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGlmIChhY3RpdmVJdGVtc1t2YWxdLmNsYXNzTGlzdC5jb250YWlucyhcIm91dGJpZFwiKSkge1xyXG4gICAgICAgICAgY2xpY2tFbGVtZW50KGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ3YXRjaFwiKVswXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBpZiBsYXN0IHRpbWUsIHRoZW4gdHJ5IHRvIGNsZWFyIGV4cGlyZWQgaXRlbXNcclxuICAgICAgICBpZiAoaSA9PT0gYWN0aXZlSXRlbXMubGVuZ3RoIC0gMSkge1xyXG4gICAgICAgICAgY29uc3QgY2xlYXJFeHBpcmVkQnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgICAgICAgICAgXCJidG4tc3RhbmRhcmQgc2VjdGlvbi1oZWFkZXItYnRuIGNhbGwtdG8tYWN0aW9uXCJcclxuICAgICAgICAgIClbM107XHJcblxyXG4gICAgICAgICAgaWYgKGNsZWFyRXhwaXJlZEJ1dHRvbikge1xyXG4gICAgICAgICAgICBjbGlja0VsZW1lbnQoY2xlYXJFeHBpcmVkQnV0dG9uKTtcclxuXHJcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgIGFsZXJ0KFwiRmluaXNoZWQgY2xlYW5pbmcgeW91ciBUcmFuc2ZlciBUYXJnZXRzIGxpc3QhXCIpO1xyXG4gICAgICAgICAgICB9LCAxMDAwKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGFsZXJ0KFwiRmluaXNoZWQgY2xlYW5pbmcgeW91ciBUcmFuc2ZlciBUYXJnZXRzIGxpc3QhXCIpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSwgMTAwICsgcmFuZG9taXplKCkpO1xyXG4gICAgfSwgMjAwMCAqIGl0ZW1zVG9VbndhdGNoQ291bnQpO1xyXG4gIH1cclxufTtcclxuXHJcbmNvbnN0IHJhbmRvbWl6ZSA9IChtYXhPdmVycmlkZT86IG51bWJlcik6IG51bWJlciA9PiB7XHJcbiAgY29uc3QgbWluID0gMDtcclxuICBjb25zdCBtYXggPSBtYXhPdmVycmlkZSB8fCAxMDA7XHJcblxyXG4gIHJldHVybiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAobWF4IC0gbWluICsgMSkgKyBtaW4pO1xyXG59O1xyXG4iLCJcbnZhciBjb250ZW50ID0gcmVxdWlyZShcIiEhLi4vbm9kZV9tb2R1bGVzL2Nzcy1tb2R1bGVzLXR5cGVzY3JpcHQtbG9hZGVyL2luZGV4LmpzIS4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9yZWYtLTUtMiEuLi9ub2RlX21vZHVsZXMvc2Fzcy1sb2FkZXIvbGliL2xvYWRlci5qcyEuL2NvbnRlbnRTY3JpcHQuc2Nzc1wiKTtcblxuaWYodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSBjb250ZW50ID0gW1ttb2R1bGUuaWQsIGNvbnRlbnQsICcnXV07XG5cbnZhciB0cmFuc2Zvcm07XG52YXIgaW5zZXJ0SW50bztcblxuXG5cbnZhciBvcHRpb25zID0ge1wiaG1yXCI6dHJ1ZX1cblxub3B0aW9ucy50cmFuc2Zvcm0gPSB0cmFuc2Zvcm1cbm9wdGlvbnMuaW5zZXJ0SW50byA9IHVuZGVmaW5lZDtcblxudmFyIHVwZGF0ZSA9IHJlcXVpcmUoXCIhLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9saWIvYWRkU3R5bGVzLmpzXCIpKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5pZihjb250ZW50LmxvY2FscykgbW9kdWxlLmV4cG9ydHMgPSBjb250ZW50LmxvY2FscztcblxuaWYobW9kdWxlLmhvdCkge1xuXHRtb2R1bGUuaG90LmFjY2VwdChcIiEhLi4vbm9kZV9tb2R1bGVzL2Nzcy1tb2R1bGVzLXR5cGVzY3JpcHQtbG9hZGVyL2luZGV4LmpzIS4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9yZWYtLTUtMiEuLi9ub2RlX21vZHVsZXMvc2Fzcy1sb2FkZXIvbGliL2xvYWRlci5qcyEuL2NvbnRlbnRTY3JpcHQuc2Nzc1wiLCBmdW5jdGlvbigpIHtcblx0XHR2YXIgbmV3Q29udGVudCA9IHJlcXVpcmUoXCIhIS4uL25vZGVfbW9kdWxlcy9jc3MtbW9kdWxlcy10eXBlc2NyaXB0LWxvYWRlci9pbmRleC5qcyEuLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcz8/cmVmLS01LTIhLi4vbm9kZV9tb2R1bGVzL3Nhc3MtbG9hZGVyL2xpYi9sb2FkZXIuanMhLi9jb250ZW50U2NyaXB0LnNjc3NcIik7XG5cblx0XHRpZih0eXBlb2YgbmV3Q29udGVudCA9PT0gJ3N0cmluZycpIG5ld0NvbnRlbnQgPSBbW21vZHVsZS5pZCwgbmV3Q29udGVudCwgJyddXTtcblxuXHRcdHZhciBsb2NhbHMgPSAoZnVuY3Rpb24oYSwgYikge1xuXHRcdFx0dmFyIGtleSwgaWR4ID0gMDtcblxuXHRcdFx0Zm9yKGtleSBpbiBhKSB7XG5cdFx0XHRcdGlmKCFiIHx8IGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRcdGlkeCsrO1xuXHRcdFx0fVxuXG5cdFx0XHRmb3Ioa2V5IGluIGIpIGlkeC0tO1xuXG5cdFx0XHRyZXR1cm4gaWR4ID09PSAwO1xuXHRcdH0oY29udGVudC5sb2NhbHMsIG5ld0NvbnRlbnQubG9jYWxzKSk7XG5cblx0XHRpZighbG9jYWxzKSB0aHJvdyBuZXcgRXJyb3IoJ0Fib3J0aW5nIENTUyBITVIgZHVlIHRvIGNoYW5nZWQgY3NzLW1vZHVsZXMgbG9jYWxzLicpO1xuXG5cdFx0dXBkYXRlKG5ld0NvbnRlbnQpO1xuXHR9KTtcblxuXHRtb2R1bGUuaG90LmRpc3Bvc2UoZnVuY3Rpb24oKSB7IHVwZGF0ZSgpOyB9KTtcbn0iLCJpbXBvcnQgZ29CYWNrIGZyb20gXCIuL2FjdGlvbnMvYmFja1wiO1xuaW1wb3J0IGxpc3QgZnJvbSBcIi4vYWN0aW9ucy9saXN0XCI7XG5pbXBvcnQgc2VhcmNoIGZyb20gXCIuL2FjdGlvbnMvc2VhcmNoXCI7XG5pbXBvcnQgc2VuZFRvVHJhbnNmZXJMaXN0IGZyb20gXCIuL2FjdGlvbnMvc2VuZFRvVHJhbnNmZXJMaXN0XCI7XG5pbXBvcnQgaW5jcmVhc2VNaW5CaWRQcmljZSBmcm9tIFwiLi9hY3Rpb25zL2luY3JlYXNlTWluQmlkUHJpY2VcIjtcbmltcG9ydCBzdG9yZUluQ2x1YiBmcm9tIFwiLi9hY3Rpb25zL3N0b3JlSW5DbHViXCI7XG5pbXBvcnQgaXNVc2VyT25TZWFyY2hSZXN1bHRzUGFnZSBmcm9tIFwiLi9hY3Rpb25zL2hlbHBlcnMvaXNVc2VyT25TZWFyY2hSZXN1bHRzUGFnZVwiO1xuaW1wb3J0IGluY3JlYXNlTWluQmluUHJpY2UgZnJvbSBcIi4vYWN0aW9ucy9pbmNyZWFzZU1pbkJpblByaWNlXCI7XG5pbXBvcnQgaW5jcmVhc2VNYXhCaW5QcmljZSBmcm9tIFwiLi9hY3Rpb25zL2luY3JlYXNlTWF4QmluUHJpY2VcIjtcbmltcG9ydCBkZWNyZWFzZU1heEJpblByaWNlIGZyb20gXCIuL2FjdGlvbnMvZGVjcmVhc2VNYXhCaW5QcmljZVwiO1xuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9jb250ZW50U2NyaXB0LnNjc3NcIjtcbmltcG9ydCBzdGFydEJpZGRlciwgeyBjbGVhbnVwVHJhbnNmZXJUYXJnZXRzIH0gZnJvbSBcIi4vYmlkZGVyXCI7XG5pbXBvcnQgaXNVc2VyT25UcmFuc2ZlclRhcmdldHNQYWdlIGZyb20gXCIuL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblRyYW5zZmVyVGFyZ2V0c1BhZ2VcIjtcblxubGV0IG9uVGltZXIgPSBudWxsO1xubGV0IG9mZlRpbWVyID0gbnVsbDtcbmxldCBpc09uID0gZmFsc2U7XG5sZXQgYmlkZGVyVGltZXIgPSBudWxsO1xuXG4oZnVuY3Rpb24gKCkge1xuICBjb25zdCBpZCA9IGNocm9tZS5ydW50aW1lLmlkO1xuICBpZiAoaWQgIT09IFwiZWpocG1wZ2Zhb2llY2lqbWdnamxkbG1qbGlna25ibmJcIikge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgIGxvZzogdHJ1ZSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIG1lc3NhZ2UgbGlzdGVuZXIgdGVsbCB1c2VyIHRvIHJlZnJlc2ggYWZ0ZXIgcmVkZWVtaW5nIGF1dG9idXllciBhY2Nlc3NcbiAgY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChyZXF1ZXN0KSA9PiB7XG4gICAgaWYgKHJlcXVlc3QuYXV0b2J1eWVyQWNjZXNzUmVkZWVtZWQpIHtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBhbGVydChcIlBsZWFzZSByZWZyZXNoIHRoZSBwYWdlIHNvIHNob3J0ZnV0cyBhdXRvIGNhbiBiZSBpbml0aWFsaXplZCFcIik7XG4gICAgICB9LCAxNTAwKTtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIG1lc3NhZ2UgbGlzdGVuZXIgdG8gZ2V0IGN1cnJlbnQgY29pbiBiYWxhbmNlXG4gIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigocmVxdWVzdCwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcbiAgICBpZiAocmVxdWVzdC5nZXRDdXJyZW50Q29pbkJhbGFuY2UpIHtcbiAgICAgIGNvbnN0IGNvaW5CYWxhbmNlID0gKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICAgIFwidmlldy1uYXZiYXItY3VycmVuY3ktY29pbnNcIlxuICAgICAgKVswXSBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0O1xuICAgICAgY29uc3Qgbm9ybWFsaXplZENvaW5CYWxhbmNlID0gY29pbkJhbGFuY2UucmVwbGFjZShcbiAgICAgICAgL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csXG4gICAgICAgIFwiXCJcbiAgICAgICk7XG5cbiAgICAgIHNlbmRSZXNwb25zZSh7XG4gICAgICAgIG5vcm1hbGl6ZWRDb2luQmFsYW5jZTogbm9ybWFsaXplZENvaW5CYWxhbmNlLFxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcblxuICBjb25zdCBhdWRpbyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhdWRpb1wiKTtcbiAgYXVkaW8uaWQgPSBzdHlsZXMuYXVkaW87XG4gIGF1ZGlvLmF1dG9wbGF5ID0gZmFsc2U7XG4gIGF1ZGlvLnNyYyA9IFwiaHR0cHM6Ly93d3cuc291bmRqYXkuY29tL2J1dHRvbnMvc291bmRzL2J1dHRvbi0xMi5tcDNcIjtcbiAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFwcGVuZENoaWxkKGF1ZGlvKTtcblxuICBjb25zdCBsb29wRG9uZVNvdW5kID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImF1ZGlvXCIpO1xuICBsb29wRG9uZVNvdW5kLmlkID0gc3R5bGVzLmxvb3BEb25lU291bmQ7XG4gIGxvb3BEb25lU291bmQuYXV0b3BsYXkgPSBmYWxzZTtcbiAgbG9vcERvbmVTb3VuZC5zcmMgPSBcImh0dHBzOi8vd3d3LnNvdW5kamF5LmNvbS9taXNjL2JlbGwtcmluZy0wMS5tcDNcIjtcbiAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFwcGVuZENoaWxkKGxvb3BEb25lU291bmQpO1xuXG4gIGNvbnN0IGNhcmRTZWVuU291bmQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYXVkaW9cIik7XG4gIGNhcmRTZWVuU291bmQuaWQgPSBzdHlsZXMuY2FyZFNlZW5Tb3VuZDtcbiAgY2FyZFNlZW5Tb3VuZC5hdXRvcGxheSA9IGZhbHNlO1xuICBjYXJkU2VlblNvdW5kLnNyYyA9IFwiaHR0cHM6Ly93d3cuc291bmRqYXkuY29tL2J1dHRvbnMvc291bmRzL2J1dHRvbi0wOWEubXAzXCI7XG4gIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5hcHBlbmRDaGlsZChjYXJkU2VlblNvdW5kKTtcblxuICBjb25zdCBjYXJkUHVyY2hhc2VkU291bmQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYXVkaW9cIik7XG4gIGNhcmRQdXJjaGFzZWRTb3VuZC5pZCA9IHN0eWxlcy5jYXJkUHVyY2hhc2VkU291bmQ7XG4gIGNhcmRQdXJjaGFzZWRTb3VuZC5hdXRvcGxheSA9IGZhbHNlO1xuICBjYXJkUHVyY2hhc2VkU291bmQuc3JjID1cbiAgICBcImh0dHBzOi8vd3d3LnNvdW5kamF5LmNvbS9tZWNoYW5pY2FsL3NvdW5kcy9ndW4tZ3Vuc2hvdC0wMS5tcDNcIjtcbiAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFwcGVuZENoaWxkKGNhcmRQdXJjaGFzZWRTb3VuZCk7XG5cbiAgLy8gcmVzZXRzIGJhZGdlIG9uIHJlZnJlc2ggKHNpbmNlIGl0J3Mgb2J2aW91c2x5IHN0b3BwZWQpXG4gIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgc3RvcEF1dG9idXllcjogdHJ1ZSB9KTtcbiAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwic2VlbkNvdW50XCIsIFwiMFwiKTtcbiAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwic2VhcmNoQ291bnRcIiwgXCIwXCIpO1xuICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJwdXJjaGFzZWRDb3VudFwiLCBcIjBcIik7XG5cbiAgY29uc29sZS5sb2coXCJTZXR0aW5nIHVwIGV2ZW50IGxpc3RlbmVyLi4uXCIpO1xuXG4gIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigocmVxdWVzdCkgPT4ge1xuICAgIGlmIChyZXF1ZXN0LnN0YXJ0QXV0b2J1eWVyKSB7XG4gICAgICAvLyBzdGFydCB0aGUgYXV0b2J1eWVyIGlmIHRoZSB1c2VyIGhhcyByZWRlZW1lZFxuICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyBjaGVja0FjY2VzczogdHJ1ZSB9LCAocmVzcG9uc2UpID0+IHtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5oYXNBY2Nlc3MpIHtcbiAgICAgICAgICBhbGVydChcbiAgICAgICAgICAgIFwiUGxlYXNlIG9wZW4gdGhlIHNob3J0ZnV0cyBhdXRvIENocm9tZSBleHRlbnNpb24gYW5kIHJlZGVlbSB5b3VyIGNvZGUgdGhhdCB3YXMgc2VudCB0byB5b3VyIGVtYWlsIGFkZHJlc3MuIFBsZWFzZSByZWZyZXNoIHRoZSB3ZWIgYXBwIGlmIHlvdSd2ZSBhbHJlYWR5IHJlZGVlbWVkIHlvdXIgY29kZS5cIlxuICAgICAgICAgICk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwic2VlbkNvdW50XCIsIFwiMFwiKTtcbiAgICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwic2VhcmNoQ291bnRcIiwgXCIwXCIpO1xuICAgICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJwdXJjaGFzZWRDb3VudFwiLCBcIjBcIik7XG5cbiAgICAgICAgY29uc3QgcGxheWVyTmFtZUlucHV0ID0gZG9jdW1lbnRcbiAgICAgICAgICAuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInV0LXBsYXllci1zZWFyY2gtY29udHJvbFwiKVswXVxuICAgICAgICAgIC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImlucHV0XCIpWzBdO1xuICAgICAgICBpZiAocGxheWVyTmFtZUlucHV0ICYmIHBsYXllck5hbWVJbnB1dC52YWx1ZSA9PT0gXCJcIikge1xuICAgICAgICAgIGNvbnN0IHJldFZhbCA9IGNvbmZpcm0oXG4gICAgICAgICAgICBcIlBsYXllciBuYW1lIGlucHV0IGlzIGVtcHR5LiBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gc3RhcnQgdGhlIGJvdD9cIlxuICAgICAgICAgICk7XG5cbiAgICAgICAgICBpZiAoIXJldFZhbCkge1xuICAgICAgICAgICAgc3RvcEF1dG9idXllcihcbiAgICAgICAgICAgICAgXCJCb3QgZGlkbid0IGdldCBzdGFydGVkLiBUaGF0IHdhcyBhIGNsb3NlIG9uZSFcIixcbiAgICAgICAgICAgICAgdHJ1ZVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgcmVzZXRQb2ludCxcbiAgICAgICAgICBhY3Rpb24sXG4gICAgICAgICAgaXRlcmF0aW9uVGltZSxcbiAgICAgICAgICBpdGVyYXRpb25UaW1lTWF4LFxuICAgICAgICAgIGxpc3RTdGFydFByaWNlLFxuICAgICAgICAgIGxpc3RCaW5QcmljZSxcbiAgICAgICAgICBpc1Rlc3RSdW4sXG4gICAgICAgICAgY3ljbGVzLFxuICAgICAgICAgIG9uSW50ZXJ2YWwsXG4gICAgICAgICAgb2ZmSW50ZXJ2YWwsXG4gICAgICAgICAgbWF4QnV5Tm93UHJpY2UsXG4gICAgICAgICAgbWluaW11bUNvaW5CYWxhbmNlLFxuICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgbWF4QmlkQW1vdW50LFxuICAgICAgICAgIGJpZER1cmF0aW9uLFxuICAgICAgICAgIHNob3VsZEJpZE1heCxcbiAgICAgICAgfSA9IHJlcXVlc3Q7XG4gICAgICAgIGlmIChtb2RlID09PSBcImJpZFwiKSB7XG4gICAgICAgICAgYmlkZGVyVGltZXIgPSBzZXRUaW1lb3V0KFxuICAgICAgICAgICAgKCkgPT4gc3RhcnRCaWRkZXIobWF4QmlkQW1vdW50LCBiaWREdXJhdGlvbiwgc2hvdWxkQmlkTWF4KSxcbiAgICAgICAgICAgIDBcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIENoZWNrcyB0byBtYWtlIHN1cmUgbWF4IEJJTiBpcyBzZXRcbiAgICAgICAgICBjb25zdCBtYXhCaW5JbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICAgICAgICBcIm51bWVyaWNJbnB1dFwiXG4gICAgICAgICAgKVszXTtcbiAgICAgICAgICBpZiAoKG1heEJpbklucHV0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlID09PSBcIlwiKSB7XG4gICAgICAgICAgICBjb25zdCByZXRWYWwgPSBjb25maXJtKFxuICAgICAgICAgICAgICBcIlRoZSBtYXggYnV5IG5vdyBwcmljZSBpcyBlbXB0eS4gQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHN0YXJ0IHRoZSBib3Q/XCJcbiAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgIGlmICghcmV0VmFsKSB7XG4gICAgICAgICAgICAgIHN0b3BBdXRvYnV5ZXIoXG4gICAgICAgICAgICAgICAgXCJCb3QgZGlkbid0IGdldCBzdGFydGVkLiBUaGF0IHdhcyBhIGNsb3NlIG9uZSFcIixcbiAgICAgICAgICAgICAgICB0cnVlXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBHZXQgaW5pdGlhbCBtaW4gQklOIHNldCBieSB1c2VyXG4gICAgICAgICAgY29uc3QgaW5pdGlhbE1pbkJpbiA9IChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgICAgICAgICAgXCJudW1lcmljSW5wdXRcIlxuICAgICAgICAgIClbMl0gYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XG4gICAgICAgICAgY29uc3QgaW5pdGlhbE1pbkJpbk51bWJlciA9XG4gICAgICAgICAgICBwYXJzZUludChpbml0aWFsTWluQmluLnJlcGxhY2UoL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csIFwiXCIpKSB8fCAwO1xuXG4gICAgICAgICAgLy8gRGV0ZXJtaW5lIHJlc2V0IHByaWNlXG4gICAgICAgICAgY29uc3QgbWF4UHVyY2hhc2VQcmljZSA9IGluaXRpYWxNaW5CaW5OdW1iZXIgfHwgcmVzZXRQb2ludDtcbiAgICAgICAgICBjb25zdCByZXNldFByaWNlID0gZ2V0TWF4QmlkUHJpY2UobWF4UHVyY2hhc2VQcmljZSk7XG5cbiAgICAgICAgICAvLyBHZXQgaW5pdGlhbCBtYXggQklOIHNldCBieSB1c2VyXG4gICAgICAgICAgY29uc3QgaW5pdGlhbE1heEJpbiA9IChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgICAgICAgICAgXCJudW1lcmljSW5wdXRcIlxuICAgICAgICAgIClbM10gYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XG4gICAgICAgICAgY29uc3QgaW5pdGlhbE1heEJpbk51bWJlciA9XG4gICAgICAgICAgICBwYXJzZUludChpbml0aWFsTWF4QmluLnJlcGxhY2UoL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csIFwiXCIpKSB8fCAwO1xuXG4gICAgICAgICAgaWYgKGluaXRpYWxNYXhCaW5OdW1iZXIgPD0gcmVzZXRQcmljZSkge1xuICAgICAgICAgICAgc3RvcEF1dG9idXllcihcbiAgICAgICAgICAgICAgJ1lvdXIgXCJSZXNldCBwcmljZVwiIG11c3QgYmUgbGVzcyB0aGFuIHRoZSBtYXggQklOIHByaWNlIG9mIHlvdXIgc25pcGluZyBmaWx0ZXIuJyxcbiAgICAgICAgICAgICAgdHJ1ZVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjcmVhdGVDeWNsZSh7XG4gICAgICAgICAgICBjdXJyQ3ljbGU6IDAsXG4gICAgICAgICAgICB0b3RhbEN5Y2xlczogY3ljbGVzLFxuICAgICAgICAgICAgb25JbnRlcnZhbCxcbiAgICAgICAgICAgIG9mZkludGVydmFsLFxuICAgICAgICAgICAgaXNUZXN0UnVuLFxuICAgICAgICAgICAgYWN0aW9uLFxuICAgICAgICAgICAgbGlzdFN0YXJ0UHJpY2UsXG4gICAgICAgICAgICBsaXN0QmluUHJpY2UsXG4gICAgICAgICAgICBpdGVyYXRpb25UaW1lLFxuICAgICAgICAgICAgaXRlcmF0aW9uVGltZU1heCxcbiAgICAgICAgICAgIHJlc2V0UHJpY2UsXG4gICAgICAgICAgICB1c2VyU2V0TWluQmluOiBpbml0aWFsTWluQmluTnVtYmVyID4gMCxcbiAgICAgICAgICAgIG1heEJ1eU5vd1ByaWNlLFxuICAgICAgICAgICAgaW5pdGlhbE1heEJpbjogaW5pdGlhbE1heEJpbk51bWJlcixcbiAgICAgICAgICAgIG1pbmltdW1Db2luQmFsYW5jZTogbWluaW11bUNvaW5CYWxhbmNlLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHJlcXVlc3Quc3RvcEF1dG9idXllckZyb21Qb3B1cCkge1xuICAgICAgc3RvcEF1dG9idXllcihcIkJvdCBzdG9wcGVkIGJlY2F1c2UgeW91IHN0b3BwZWQgaXQuXCIpO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gRXZlbnQgbGlzdGVuZXIgdG8gc3RvcCBhdXRvYnV5ZXIgb24gZGVtYW5kXG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCAoZXYpID0+IHtcbiAgICAvLyBJZiB1c2VyIGlzIHR5cGluZyBpbiBhbiBpbnB1dCwgaWdub3JlIGhvdGtleXMuXG4gICAgaWYgKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQudGFnTmFtZS50b0xvd2VyQ2FzZSgpID09PSBcImlucHV0XCIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoZXYua2V5Q29kZSA9PT0gMzIgJiYgZXYuc2hpZnRLZXkpIHtcbiAgICAgIGlmIChpc09uIHx8IG9uVGltZXIgfHwgb2ZmVGltZXIgfHwgYmlkZGVyVGltZXIpIHtcbiAgICAgICAgc3RvcEF1dG9idXllcihcIkJvdCBzdG9wcGVkIGJlY2F1c2UgeW91IHN0b3BwZWQgaXQuXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXG4gICAgICAgICAgW1xuICAgICAgICAgICAgXCJyZXNldFBvaW50XCIsXG4gICAgICAgICAgICBcImR1cmF0aW9uXCIsXG4gICAgICAgICAgICBcImFjdGlvblwiLFxuICAgICAgICAgICAgXCJpdGVyYXRpb25UaW1lXCIsXG4gICAgICAgICAgICBcIml0ZXJhdGlvblRpbWVNYXhcIixcbiAgICAgICAgICAgIFwibGlzdFN0YXJ0UHJpY2VcIixcbiAgICAgICAgICAgIFwibGlzdEJpblByaWNlXCIsXG4gICAgICAgICAgICBcImN5Y2xlc1wiLFxuICAgICAgICAgICAgXCJvbkludGVydmFsXCIsXG4gICAgICAgICAgICBcIm9mZkludGVydmFsXCIsXG4gICAgICAgICAgICBcIm1heEJ1eU5vd1ByaWNlXCIsXG4gICAgICAgICAgICBcIm1pbmltdW1Db2luQmFsYW5jZVwiLFxuICAgICAgICAgICAgXCJtb2RlXCIsXG4gICAgICAgICAgICBcIm1heEJpZEFtb3VudFwiLFxuICAgICAgICAgICAgXCJiaWREdXJhdGlvblwiLFxuICAgICAgICAgICAgXCJzaG91bGRCaWRNYXhcIixcbiAgICAgICAgICBdLFxuICAgICAgICAgIChkYXRhKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICAgIHJlc2V0UG9pbnQsXG4gICAgICAgICAgICAgIGR1cmF0aW9uLFxuICAgICAgICAgICAgICBhY3Rpb24sXG4gICAgICAgICAgICAgIGl0ZXJhdGlvblRpbWUsXG4gICAgICAgICAgICAgIGl0ZXJhdGlvblRpbWVNYXgsXG4gICAgICAgICAgICAgIGxpc3RTdGFydFByaWNlLFxuICAgICAgICAgICAgICBsaXN0QmluUHJpY2UsXG4gICAgICAgICAgICAgIGN5Y2xlcyxcbiAgICAgICAgICAgICAgb25JbnRlcnZhbCxcbiAgICAgICAgICAgICAgb2ZmSW50ZXJ2YWwsXG4gICAgICAgICAgICAgIG1heEJ1eU5vd1ByaWNlLFxuICAgICAgICAgICAgICBtaW5pbXVtQ29pbkJhbGFuY2UsXG4gICAgICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgICAgIG1heEJpZEFtb3VudCxcbiAgICAgICAgICAgICAgYmlkRHVyYXRpb24sXG4gICAgICAgICAgICAgIHNob3VsZEJpZE1heCxcbiAgICAgICAgICAgIH0gPSBkYXRhO1xuXG4gICAgICAgICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7XG4gICAgICAgICAgICAgIHN0YXJ0QXV0b2J1eWVyOiB0cnVlLFxuICAgICAgICAgICAgICByZXNldFBvaW50OiBwYXJzZUludChyZXNldFBvaW50KSxcbiAgICAgICAgICAgICAgZHVyYXRpb246IGR1cmF0aW9uLFxuICAgICAgICAgICAgICBhY3Rpb246IGFjdGlvbixcbiAgICAgICAgICAgICAgaXRlcmF0aW9uVGltZTogaXRlcmF0aW9uVGltZSxcbiAgICAgICAgICAgICAgaXRlcmF0aW9uVGltZU1heDogaXRlcmF0aW9uVGltZU1heCxcbiAgICAgICAgICAgICAgbGlzdFN0YXJ0UHJpY2U6IGxpc3RTdGFydFByaWNlLFxuICAgICAgICAgICAgICBsaXN0QmluUHJpY2U6IGxpc3RCaW5QcmljZSxcbiAgICAgICAgICAgICAgaXNUZXN0UnVuOiBmYWxzZSxcbiAgICAgICAgICAgICAgY3ljbGVzOiBwYXJzZUludChjeWNsZXMpLFxuICAgICAgICAgICAgICBvbkludGVydmFsOiBwYXJzZUludChvbkludGVydmFsKSxcbiAgICAgICAgICAgICAgb2ZmSW50ZXJ2YWw6IHBhcnNlSW50KG9mZkludGVydmFsKSxcbiAgICAgICAgICAgICAgbWF4QnV5Tm93UHJpY2U6IHBhcnNlSW50KG1heEJ1eU5vd1ByaWNlKSxcbiAgICAgICAgICAgICAgbWluaW11bUNvaW5CYWxhbmNlOiBtaW5pbXVtQ29pbkJhbGFuY2UsXG4gICAgICAgICAgICAgIG1vZGU6IG1vZGUgfHwgXCJzbmlwZVwiLFxuICAgICAgICAgICAgICBtYXhCaWRBbW91bnQ6IG1heEJpZEFtb3VudCB8fCAxNTAsXG4gICAgICAgICAgICAgIGJpZER1cmF0aW9uOiBiaWREdXJhdGlvbiB8fCAzMCxcbiAgICAgICAgICAgICAgc2hvdWxkQmlkTWF4OiBzaG91bGRCaWRNYXgsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcblxuICBsZXQgY2xlYW51cEJ1dHRvbjogSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGxldCBkaXY7XG4gIHNldEludGVydmFsKCgpID0+IHtcbiAgICBpZiAoIWlzVXNlck9uVHJhbnNmZXJUYXJnZXRzUGFnZSgpKSB7XG4gICAgICBpZiAoY2xlYW51cEJ1dHRvbikge1xuICAgICAgICBjb25zdCBoZWFkZXJDb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgICAgICAgIFwidXQtbmF2aWdhdGlvbi1iYXItdmlldyBuYXZiYXItc3R5bGUtbGFuZHNjYXBlXCJcbiAgICAgICAgKVswXTtcblxuICAgICAgICBoZWFkZXJDb250YWluZXIucmVtb3ZlQ2hpbGQoY2xlYW51cEJ1dHRvbik7XG4gICAgICAgIGhlYWRlckNvbnRhaW5lci5yZW1vdmVDaGlsZChkaXYpO1xuXG4gICAgICAgIGNsZWFudXBCdXR0b24gPSBudWxsO1xuICAgICAgICBkaXYgPSBudWxsO1xuICAgICAgfVxuXG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHN0eWxlcy5jbGVhbnVwQnV0dG9uKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNsZWFudXBCdXR0b24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICAgIGNsZWFudXBCdXR0b24uaWQgPSBzdHlsZXMuY2xlYW51cEJ1dHRvbjtcbiAgICBjbGVhbnVwQnV0dG9uLmlubmVyVGV4dCA9IFwiQ0xFQU5VUCBUUkFOU0VSIFRBUkdFVFNcIjtcbiAgICBjbGVhbnVwQnV0dG9uLnN0eWxlLnBhZGRpbmcgPSBcIjEycHhcIjtcbiAgICBjbGVhbnVwQnV0dG9uLnN0eWxlLmJhY2tncm91bmQgPSBcIndoaXRlc21va2VcIjtcbiAgICBjbGVhbnVwQnV0dG9uLnN0eWxlLmZvbnRGYW1pbHkgPSBcIlVsdGltYXRlVGVhbUNvbmRlbnNlZCxzYW5zLXNlcmlmXCI7XG4gICAgY2xlYW51cEJ1dHRvbi5vbmNsaWNrID0gY2xlYW51cFRyYW5zZmVyVGFyZ2V0cztcbiAgICBjbGVhbnVwQnV0dG9uLnRpdGxlID1cbiAgICAgIFwiSXRlbXMgeW91J3JlIG91dGJpZCBvbiBhbmQgaXRlbXMgZnJvbSBleHBpcmVkIGF1Y3Rpb25zIHdpbGwgYmUgcmVtb3ZlZC5cIjtcblxuICAgIGNvbnN0IGhlYWRlckNvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICBcInV0LW5hdmlnYXRpb24tYmFyLXZpZXcgbmF2YmFyLXN0eWxlLWxhbmRzY2FwZVwiXG4gICAgKVswXTtcblxuICAgIGNvbnN0IGhlYWRlck5vZGUgPSBoZWFkZXJDb250YWluZXIuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJoMVwiKVswXTtcbiAgICBoZWFkZXJOb2RlLnN0eWxlLm1heFdpZHRoID0gXCJmaXQtY29udGVudFwiO1xuICAgIGhlYWRlck5vZGUucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoY2xlYW51cEJ1dHRvbiwgaGVhZGVyTm9kZS5uZXh0U2libGluZyk7XG5cbiAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIGRpdi5zdHlsZS5mbGV4ID0gXCIxXCI7XG4gICAgY2xlYW51cEJ1dHRvbi5wYXJlbnROb2RlLmluc2VydEJlZm9yZShkaXYsIGNsZWFudXBCdXR0b24ubmV4dFNpYmxpbmcpO1xuICB9LCAxMDAwKTtcbn0pKCk7XG5cbmV4cG9ydCBjb25zdCBzdG9wQXV0b2J1eWVyID0gKHJlYXNvbjogc3RyaW5nLCBza2lwQ2hlY2s6IGJvb2xlYW4gPSBmYWxzZSkgPT4ge1xuICBpZiAoaXNPbiB8fCBvblRpbWVyIHx8IG9mZlRpbWVyIHx8IGJpZGRlclRpbWVyIHx8IHNraXBDaGVjaykge1xuICAgIGlzT24gPSBmYWxzZTtcblxuICAgIGNsZWFyVGltZW91dChvblRpbWVyKTtcbiAgICBvblRpbWVyID0gbnVsbDtcblxuICAgIGNsZWFyVGltZW91dChvZmZUaW1lcik7XG4gICAgb2ZmVGltZXIgPSBudWxsO1xuXG4gICAgY2xlYXJUaW1lb3V0KGJpZGRlclRpbWVyKTtcbiAgICBiaWRkZXJUaW1lciA9IG51bGw7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJiaWRkZXJcIiwgXCJvZmZcIik7XG5cbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHN0b3BBdXRvYnV5ZXI6IHRydWUgfSk7XG5cbiAgICBjb25zdCBzZWFyY2hDb3VudCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInNlYXJjaENvdW50XCIpO1xuICAgIGNvbnN0IHNlZW5Db3VudCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInNlZW5Db3VudFwiKTtcbiAgICBjb25zdCBwdXJjaGFzZWRDb3VudCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInB1cmNoYXNlZENvdW50XCIpO1xuXG4gICAgY29uc3QgX3N0cmluZyA9XG4gICAgICBwYXJzZUludChzZWFyY2hDb3VudCkgPiAwXG4gICAgICAgID8gYCgke3NlYXJjaENvdW50fSBzZWFyY2hlcywgJHtzZWVuQ291bnR9IGNhcmRzIHNlZW4sICR7cHVyY2hhc2VkQ291bnR9IGNhcmRzIGJvdWdodClgXG4gICAgICAgIDogXCJcIjtcblxuICAgIGFsZXJ0KGAke3JlYXNvbn0gJHtfc3RyaW5nfWApO1xuICB9XG59O1xuXG5jb25zdCByYW5kb21pemUgPSAoKTogbnVtYmVyID0+IHtcbiAgY29uc3QgbWluID0gMDtcbiAgY29uc3QgbWF4ID0gNTA7XG5cbiAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIChtYXggLSBtaW4gKyAxKSArIG1pbik7XG59O1xuXG5jb25zdCBnZXRNYXhCaWRQcmljZSA9IChtYXhQdXJjaGFzZVByaWNlOiBudW1iZXIpOiBudW1iZXIgPT4ge1xuICBpZiAobWF4UHVyY2hhc2VQcmljZSA8PSAxMDAwKSB7XG4gICAgcmV0dXJuIG1heFB1cmNoYXNlUHJpY2UgLSA1MDtcbiAgfSBlbHNlIGlmIChtYXhQdXJjaGFzZVByaWNlIDw9IDEwMDAwKSB7XG4gICAgcmV0dXJuIG1heFB1cmNoYXNlUHJpY2UgLSAxMDA7XG4gIH0gZWxzZSBpZiAobWF4UHVyY2hhc2VQcmljZSA8PSAxMDAwMDApIHtcbiAgICByZXR1cm4gbWF4UHVyY2hhc2VQcmljZSAtIDUwMDtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gbWF4UHVyY2hhc2VQcmljZSAtIDEwMDA7XG4gIH1cbn07XG5cbmNvbnN0IGNyZWF0ZUN5Y2xlID0gKHBhcmFtczoge1xuICBjdXJyQ3ljbGU6IG51bWJlcjtcbiAgdG90YWxDeWNsZXM6IG51bWJlcjtcbiAgb25JbnRlcnZhbDogbnVtYmVyO1xuICBvZmZJbnRlcnZhbDogbnVtYmVyO1xuICBpc1Rlc3RSdW46IGJvb2xlYW47XG4gIGFjdGlvbjogc3RyaW5nO1xuICBsaXN0U3RhcnRQcmljZTogc3RyaW5nO1xuICBsaXN0QmluUHJpY2U6IHN0cmluZztcbiAgaXRlcmF0aW9uVGltZTogc3RyaW5nO1xuICBpdGVyYXRpb25UaW1lTWF4OiBzdHJpbmc7XG4gIHJlc2V0UHJpY2U6IG51bWJlcjtcbiAgdXNlclNldE1pbkJpbjogYm9vbGVhbjtcbiAgbWF4QnV5Tm93UHJpY2U6IG51bWJlcjtcbiAgaW5pdGlhbE1heEJpbjogbnVtYmVyO1xuICBtaW5pbXVtQ29pbkJhbGFuY2U6IHN0cmluZztcbn0pID0+IHtcbiAgY29uc3Qge1xuICAgIGN1cnJDeWNsZSxcbiAgICB0b3RhbEN5Y2xlcyxcbiAgICBvbkludGVydmFsLFxuICAgIG9mZkludGVydmFsLFxuICAgIGlzVGVzdFJ1bixcbiAgICBhY3Rpb24sXG4gICAgbGlzdFN0YXJ0UHJpY2UsXG4gICAgbGlzdEJpblByaWNlLFxuICAgIGl0ZXJhdGlvblRpbWUsXG4gICAgaXRlcmF0aW9uVGltZU1heCxcbiAgICByZXNldFByaWNlLFxuICAgIHVzZXJTZXRNaW5CaW4sXG4gICAgbWF4QnV5Tm93UHJpY2UsXG4gICAgaW5pdGlhbE1heEJpbixcbiAgICBtaW5pbXVtQ29pbkJhbGFuY2UsXG4gIH0gPSBwYXJhbXM7XG5cbiAgY29uc3Qgb25JbnRlcnZhbE1pbnV0ZXMgPSBvbkludGVydmFsICogNjAwMDA7XG4gIGNvbnN0IG9mZkludGVydmFsTWludXRlcyA9IG9mZkludGVydmFsICogNjAwMDA7XG5cbiAgaXNPbiA9IHRydWU7XG5cbiAgLy8gc2V0IGluaXRpYWwgY29pbiBiYWxhbmNlXG4gIGNvbnN0IGNvaW5CYWxhbmNlID0gKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgXCJ2aWV3LW5hdmJhci1jdXJyZW5jeS1jb2luc1wiXG4gIClbMF0gYXMgSFRNTEVsZW1lbnQpLmlubmVyVGV4dDtcbiAgY29uc3Qgbm9ybWFsaXplZENvaW5CYWxhbmNlID0gY29pbkJhbGFuY2UucmVwbGFjZSgvWy4sIFxcdTAwYTBcXHUyMDJGXSovZywgXCJcIik7XG4gIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInByZXZpb3VzQ29pbkJhbGFuY2VcIiwgbm9ybWFsaXplZENvaW5CYWxhbmNlKTtcblxuICBtb25leUZ1bmN0aW9uKHBhcmFtcyk7XG5cbiAgY29uc3QgcmFuZG9tTW9kaWZpZXIgPSByYW5kb21pemUoKTtcblxuICAvLyBTdGFydCBhIHRpbWVyIHRoYXQgc3RvcHMgXCJvblwiIGxvb3AgYWZ0ZXIgc3BlY2lmaWVkIHRpbWVcbiAgb25UaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgIGlzT24gPSBmYWxzZTtcblxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFwic2hvdWxkUGxheUxvb3BEb25lU291bmRcIiwgKGRhdGEpID0+IHtcbiAgICAgIGlmIChkYXRhLnNob3VsZFBsYXlMb29wRG9uZVNvdW5kKSB7XG4gICAgICAgIGNvbnN0IGxvb3BEb25lU291bmQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcbiAgICAgICAgICBzdHlsZXMubG9vcERvbmVTb3VuZFxuICAgICAgICApIGFzIEhUTUxBdWRpb0VsZW1lbnQ7XG4gICAgICAgIGxvb3BEb25lU291bmQucGxheSgpO1xuICAgICAgfVxuXG4gICAgICBpZiAoY3VyckN5Y2xlID09PSB0b3RhbEN5Y2xlcyAtIDEpIHtcbiAgICAgICAgc3RvcEF1dG9idXllcihcbiAgICAgICAgICBcIkJvdCBzdG9wcGVkIGJlY2F1c2UgaXQgY29tcGxldGVkIHRoZSBudW1iZXIgb2YgcmVxdWVzdGVkIGN5Y2xlcy5cIlxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0pO1xuICB9LCBvbkludGVydmFsTWludXRlcyArIHJhbmRvbU1vZGlmaWVyKTtcblxuICAvLyBTdGFydCBhIHRpbWVyIHRoYXQgcmVzdGFydHMgXCJvblwiIGxvb3AgYWZ0ZXIgc3BlY2lmaWNpZWQgdGltZVxuICBvZmZUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgIGlmIChjdXJyQ3ljbGUgPCB0b3RhbEN5Y2xlcyAtIDEpIHtcbiAgICAgIGNyZWF0ZUN5Y2xlKHtcbiAgICAgICAgY3VyckN5Y2xlOiBjdXJyQ3ljbGUgKyAxLFxuICAgICAgICB0b3RhbEN5Y2xlcyxcbiAgICAgICAgb25JbnRlcnZhbCxcbiAgICAgICAgb2ZmSW50ZXJ2YWwsXG4gICAgICAgIGlzVGVzdFJ1bixcbiAgICAgICAgYWN0aW9uLFxuICAgICAgICBsaXN0U3RhcnRQcmljZSxcbiAgICAgICAgbGlzdEJpblByaWNlLFxuICAgICAgICBpdGVyYXRpb25UaW1lLFxuICAgICAgICBpdGVyYXRpb25UaW1lTWF4LFxuICAgICAgICByZXNldFByaWNlLFxuICAgICAgICB1c2VyU2V0TWluQmluLFxuICAgICAgICBtYXhCdXlOb3dQcmljZSxcbiAgICAgICAgaW5pdGlhbE1heEJpbixcbiAgICAgICAgbWluaW11bUNvaW5CYWxhbmNlLFxuICAgICAgfSk7XG4gICAgfVxuICB9LCBvbkludGVydmFsTWludXRlcyArIHJhbmRvbU1vZGlmaWVyICsgb2ZmSW50ZXJ2YWxNaW51dGVzKTtcbn07XG5cbmNvbnN0IG1vbmV5RnVuY3Rpb24gPSAocGFyYW1zOiB7XG4gIGlzVGVzdFJ1bjogYm9vbGVhbjtcbiAgYWN0aW9uOiBzdHJpbmc7XG4gIGxpc3RTdGFydFByaWNlOiBzdHJpbmc7XG4gIGxpc3RCaW5QcmljZTogc3RyaW5nO1xuICBpdGVyYXRpb25UaW1lOiBzdHJpbmc7XG4gIGl0ZXJhdGlvblRpbWVNYXg6IHN0cmluZztcbiAgcmVzZXRQcmljZTogbnVtYmVyO1xuICB1c2VyU2V0TWluQmluOiBib29sZWFuO1xuICBtYXhCdXlOb3dQcmljZTogbnVtYmVyO1xuICBpbml0aWFsTWF4QmluOiBudW1iZXI7XG4gIG1pbmltdW1Db2luQmFsYW5jZTogc3RyaW5nO1xufSkgPT4ge1xuICBjb25zdCB7XG4gICAgaXNUZXN0UnVuLFxuICAgIGFjdGlvbixcbiAgICBsaXN0U3RhcnRQcmljZSxcbiAgICBsaXN0QmluUHJpY2UsXG4gICAgaXRlcmF0aW9uVGltZSxcbiAgICBpdGVyYXRpb25UaW1lTWF4LFxuICAgIHJlc2V0UHJpY2UsXG4gICAgdXNlclNldE1pbkJpbixcbiAgICBtYXhCdXlOb3dQcmljZSxcbiAgICBpbml0aWFsTWF4QmluLFxuICAgIG1pbmltdW1Db2luQmFsYW5jZSxcbiAgfSA9IHBhcmFtcztcblxuICBjb25zdCBpdGVyYXRpb25UaW1lUmVhbCA9IGdldEludGVydmFsKGl0ZXJhdGlvblRpbWUsIGl0ZXJhdGlvblRpbWVNYXgpO1xuXG4gIC8vIGNoZWNrIGZvciBjYXB0Y2hhXG4gIGNvbnN0IGlzQWxlcnRQcmVzZW50ID1cbiAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwidWktZGlhbG9nLXR5cGUtYWxlcnRcIikubGVuZ3RoID4gMDtcbiAgaWYgKGlzQWxlcnRQcmVzZW50KSB7XG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXCJzaG91bGRQbGF5Q2FwdGNoYVNvdW5kXCIsIChkYXRhKSA9PiB7XG4gICAgICBpZiAoZGF0YS5zaG91bGRQbGF5Q2FwdGNoYVNvdW5kKSB7XG4gICAgICAgIGNvbnN0IGF1ZGlvID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoc3R5bGVzLmF1ZGlvKSBhcyBIVE1MQXVkaW9FbGVtZW50O1xuICAgICAgICBhdWRpby5wbGF5KCk7XG4gICAgICB9XG5cbiAgICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgYWxlcnQ6IHRydWUsXG4gICAgICB9KTtcblxuICAgICAgc3RvcEF1dG9idXllcihcbiAgICAgICAgXCJCb3Qgc3RvcHBlZCBiZWNhdXNlIGh1bWFuIHZlcmlmaWNhdGlvbiBpcyByZXF1aXJlZCBieSBFQS5cIlxuICAgICAgKTtcbiAgICB9KTtcblxuICAgIHJldHVybjtcbiAgfVxuXG4gIC8vIGNoZWNrIGZvciBjb2luIGJhbGFuY2VcbiAgY29uc3QgY29pbkJhbGFuY2UgPSAoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcbiAgICBcInZpZXctbmF2YmFyLWN1cnJlbmN5LWNvaW5zXCJcbiAgKVswXSBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0O1xuICBjb25zdCBub3JtYWxpemVkQ29pbkJhbGFuY2UgPSBjb2luQmFsYW5jZS5yZXBsYWNlKC9bLiwgXSovZywgXCJcIik7XG5cbiAgLy8gZ2V0IHByZXZpb3VzIGNvaW4gYmFsYW5jZSBmcm9tIHN0b3JhZ2VcbiAgY29uc3QgcHJldmlvdXNDb2luQmFsYW5jZSA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcbiAgICBcInByZXZpb3VzQ29pbkJhbGFuY2VcIlxuICApO1xuXG4gIGlmIChub3JtYWxpemVkQ29pbkJhbGFuY2UgPCBtaW5pbXVtQ29pbkJhbGFuY2UpIHtcbiAgICBzdG9wQXV0b2J1eWVyKFxuICAgICAgXCJCb3Qgc3RvcHBlZCBiZWNhdXNlIHlvdXIgY29pbiBiYWxhbmNlIGhhcyBmYWxsZW4gYmVuZWF0aCB0aGUgbWluaW11bSBjb2luIGJhbGFuY2UgdGhyZXNob2xkIHlvdSBzZXQuXCJcbiAgICApO1xuXG4gICAgcmV0dXJuO1xuICB9IGVsc2UgaWYgKHByZXZpb3VzQ29pbkJhbGFuY2UgIT09IG5vcm1hbGl6ZWRDb2luQmFsYW5jZSkge1xuICAgIGNvbnN0IGp1c3RTYXdDYXJkID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwianVzdFNhd0NhcmRcIik7XG5cbiAgICAvKipcbiAgICAgKiBpZiB0aGUgY2FyZCBiYWxhbmNlIGlzIGRpZmZlcmVudCB0aGFuIGJlZm9yZSB3ZSBzZWFyY2hlZCwgYW5kIHdlIGp1c3RcbiAgICAgKiBzYXcgYSBjYXJkLCB3ZSBjYW4gcmVhc29uYWJseSBhc3N1bWUgYSBjYXJkIHdhcyBwdXJjaGFzZWRcbiAgICAgKi9cbiAgICBpZiAoanVzdFNhd0NhcmQgPT09IFwidHJ1ZVwiKSB7XG4gICAgICBjb25zdCBvbGRDb3VudCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInB1cmNoYXNlZENvdW50XCIpO1xuICAgICAgY29uc3QgbmV3Q291bnQgPSBvbGRDb3VudCA/IHBhcnNlSW50KG9sZENvdW50KSArIDEgOiAxO1xuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwicHVyY2hhc2VkQ291bnRcIiwgbmV3Q291bnQudG9TdHJpbmcoKSk7XG5cbiAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFxuICAgICAgICBbXCJzaG91bGRQbGF5Q2FyZFB1cmNoYXNlZFNvdW5kXCIsIFwiZGlzY29yZFdlYmhvb2tDYXJkUHVyY2hhc2VkXCJdLFxuICAgICAgICAoZGF0YSkgPT4ge1xuICAgICAgICAgIGlmIChkYXRhLnNob3VsZFBsYXlDYXJkUHVyY2hhc2VkU291bmQpIHtcbiAgICAgICAgICAgIGNvbnN0IGNhcmRQdXJjaGFzZWRTb3VuZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFxuICAgICAgICAgICAgICBzdHlsZXMuY2FyZFB1cmNoYXNlZFNvdW5kXG4gICAgICAgICAgICApIGFzIEhUTUxBdWRpb0VsZW1lbnQ7XG4gICAgICAgICAgICBjYXJkUHVyY2hhc2VkU291bmQucGxheSgpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChkYXRhLmRpc2NvcmRXZWJob29rQ2FyZFB1cmNoYXNlZCkge1xuICAgICAgICAgICAgZmV0Y2hfcmV0cnkoXG4gICAgICAgICAgICAgIGRhdGEuZGlzY29yZFdlYmhvb2tDYXJkUHVyY2hhc2VkLFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgICBjb250ZW50OiBgQSBjYXJkIHdhcyAocHJvYmFibHkpIGJvdWdodGAsXG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgNVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgLy8gcmVzZXRzIHRoaXMgY2hlY2sgYmVmb3JlIHdlIHNlYXJjaCBhZ2FpblxuICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJqdXN0U2F3Q2FyZFwiLCBcImZhbHNlXCIpO1xuXG4gIHNlYXJjaCghaXNUZXN0UnVuKTtcblxuICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmIChhY3Rpb24gPT09IFwibGlzdFwiKSB7XG4gICAgICAgICAgbGlzdChsaXN0U3RhcnRQcmljZSwgbGlzdEJpblByaWNlKTtcbiAgICAgICAgfSBlbHNlIGlmIChhY3Rpb24gPT09IFwidHJhbnNmZXJcIikge1xuICAgICAgICAgIHNlbmRUb1RyYW5zZmVyTGlzdCgpO1xuICAgICAgICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gXCJjbHViXCIpIHtcbiAgICAgICAgICBzdG9yZUluQ2x1YigpO1xuICAgICAgICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gXCJub25lXCIgfHwgIWFjdGlvbikge1xuICAgICAgICAgIC8vIGRvIG5vdGhpbmdcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZSkge31cblxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGlmIChpc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlKCkpIHtcbiAgICAgICAgICBnb0JhY2soKTtcbiAgICAgICAgfVxuICAgICAgfSwgMjAwKTtcbiAgICB9LCAzMDApO1xuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBpZiAodXNlclNldE1pbkJpbikge1xuICAgICAgICBjb25zdCBtaW5CaWRJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICAgICAgXCJudW1lcmljSW5wdXRcIlxuICAgICAgICApWzBdIGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRNaW5CaWQgPVxuICAgICAgICAgIHBhcnNlSW50KG1pbkJpZElucHV0LnZhbHVlLnJlcGxhY2UoL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csIFwiXCIpKSB8fCAwO1xuXG4gICAgICAgIC8vIElmIGN1cnJlbnQgbWluIGJpZCBpcyBncmVhdGVyIHRoYW4gcmVzZXRQcmljZSwgcmVzZXQuXG4gICAgICAgIGlmIChjdXJyZW50TWluQmlkID49IHJlc2V0UHJpY2UpIHtcbiAgICAgICAgICBtaW5CaWRJbnB1dC52YWx1ZSA9IFwiXCI7XG4gICAgICAgICAgY2hhbmdlTWF4QmluKGluaXRpYWxNYXhCaW4sIG1heEJ1eU5vd1ByaWNlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGluY3JlYXNlTWluQmlkUHJpY2UoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IG1pbkJpbklucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcbiAgICAgICAgICBcIm51bWVyaWNJbnB1dFwiXG4gICAgICAgIClbMl0gYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICAgICAgY29uc3QgY3VycmVudE1pbkJpbiA9XG4gICAgICAgICAgcGFyc2VJbnQobWluQmluSW5wdXQudmFsdWUucmVwbGFjZSgvWy4sIFxcdTAwYTBcXHUyMDJGXSovZywgXCJcIikpIHx8IDA7XG5cbiAgICAgICAgLy8gSWYgY3VycmVudCBtaW4gQklOIGlzIGdyZWF0ZXIgdGhhbiByZXNldFByaWNlLCByZXNldC5cbiAgICAgICAgaWYgKGN1cnJlbnRNaW5CaW4gPj0gcmVzZXRQcmljZSkge1xuICAgICAgICAgIG1pbkJpbklucHV0LnZhbHVlID0gXCJcIjtcbiAgICAgICAgICBjaGFuZ2VNYXhCaW4oaW5pdGlhbE1heEJpbiwgbWF4QnV5Tm93UHJpY2UpO1xuICAgICAgICB9XG5cbiAgICAgICAgaW5jcmVhc2VNaW5CaW5QcmljZSgpO1xuICAgICAgfVxuXG4gICAgICBpZiAoaXNPbikge1xuICAgICAgICBtb25leUZ1bmN0aW9uKHBhcmFtcyk7XG4gICAgICB9XG4gICAgfSwgOTAwKTtcbiAgfSwgaXRlcmF0aW9uVGltZVJlYWwpO1xufTtcblxuLyoqXG4gKiBDaGFuZ2VzIFwibWF4IEJJTlwiIHByaWNlIGluIHNlYXJjaCBmaWx0ZXJcbiAqXG4gKiBAcGFyYW0gaW5pdGlhbE1heEJpbiBNYXggQklOIHNldCBpbiB0aGUgb3JpZ2luYWwgZmlsdGVyXG4gKiBAcGFyYW0gbWF4QnV5Tm93UHJpY2UgVGhlIHByaWNlIHNldCBieSB0aGUgdXNlciBpbiB0aGUgcG9wLXVwXG4gKi9cbmNvbnN0IGNoYW5nZU1heEJpbiA9IChpbml0aWFsTWF4QmluOiBudW1iZXIsIG1heEJ1eU5vd1ByaWNlOiBudW1iZXIpID0+IHtcbiAgaWYgKG1heEJ1eU5vd1ByaWNlIDw9IGluaXRpYWxNYXhCaW4pIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBtYXhCaW5JbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgXCJudW1lcmljSW5wdXRcIlxuICApWzNdIGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gIGNvbnN0IGN1cnJlbnRNYXhCaW4gPVxuICAgIHBhcnNlSW50KG1heEJpbklucHV0LnZhbHVlLnJlcGxhY2UoL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csIFwiXCIpKSB8fCAwO1xuXG4gIGlmIChjdXJyZW50TWF4QmluID09PSAwKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGN1cnJlbnRNYXhCaW4gPj0gbWF4QnV5Tm93UHJpY2UpIHtcbiAgICBtYXhCaW5JbnB1dC52YWx1ZSA9IGluaXRpYWxNYXhCaW4udG9TdHJpbmcoKTtcbiAgICBpbmNyZWFzZU1heEJpblByaWNlKCk7XG4gICAgZGVjcmVhc2VNYXhCaW5QcmljZSgpO1xuICB9IGVsc2Uge1xuICAgIGluY3JlYXNlTWF4QmluUHJpY2UoKTtcbiAgfVxufTtcblxuZnVuY3Rpb24gZ2V0SW50ZXJ2YWwoaXRlcmF0aW9uVGltZTogc3RyaW5nLCBpdGVyYXRpb25UaW1lTWF4OiBzdHJpbmcpIHtcbiAgY29uc3QgbWluID0gcGFyc2VJbnQoaXRlcmF0aW9uVGltZSk7XG4gIGNvbnN0IG1heCA9IHBhcnNlSW50KGl0ZXJhdGlvblRpbWVNYXgpO1xuXG4gIHJldHVybiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAobWF4IC0gbWluICsgMSkgKyBtaW4pO1xufVxuXG5jb25zdCBmZXRjaF9yZXRyeSA9ICh1cmwsIG9wdGlvbnMsIG4pID0+XG4gIGZldGNoKHVybCwgb3B0aW9ucykuY2F0Y2goZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgaWYgKG4gPT09IDEpIHRocm93IGVycm9yO1xuICAgIHJldHVybiBmZXRjaF9yZXRyeSh1cmwsIG9wdGlvbnMsIG4gLSAxKTtcbiAgfSk7XG4iXSwic291cmNlUm9vdCI6IiJ9