/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/eventPage.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/eventPage.ts":
/*!**************************!*\
  !*** ./src/eventPage.ts ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Listen to messages sent from other parts of the extension.
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // onMessage must return "true" if response is async.
    var isResponseAsync = false;
    if (request.startAutobuyer) {
        chrome.storage.sync.set({ isRunning: true });
        chrome.action.setBadgeBackgroundColor({ color: "#000000" });
        chrome.action.setBadgeText({ text: "ON" });
        var resetPoint_1 = request.resetPoint, duration_1 = request.duration, action_1 = request.action, iterationTime_1 = request.iterationTime, iterationTimeMax_1 = request.iterationTimeMax, listStartPrice_1 = request.listStartPrice, listBinPrice_1 = request.listBinPrice, _a = request.isTestRun, isTestRun_1 = _a === void 0 ? false : _a, onInterval_1 = request.onInterval, offInterval_1 = request.offInterval, cycles_1 = request.cycles, maxBuyNowPrice_1 = request.maxBuyNowPrice, minimumCoinBalance_1 = request.minimumCoinBalance, mode_1 = request.mode, maxBidAmount_1 = request.maxBidAmount, bidDuration_1 = request.bidDuration, shouldBidMax_1 = request.shouldBidMax;
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                startAutobuyer: true,
                resetPoint: resetPoint_1,
                duration: duration_1,
                action: action_1,
                iterationTime: iterationTime_1,
                iterationTimeMax: iterationTimeMax_1,
                listStartPrice: listStartPrice_1,
                listBinPrice: listBinPrice_1,
                isTestRun: isTestRun_1,
                onInterval: onInterval_1,
                offInterval: offInterval_1,
                cycles: cycles_1,
                maxBuyNowPrice: maxBuyNowPrice_1,
                minimumCoinBalance: minimumCoinBalance_1,
                mode: mode_1,
                maxBidAmount: maxBidAmount_1,
                bidDuration: bidDuration_1,
                shouldBidMax: shouldBidMax_1,
            });
        });
    }
    else if (request.stopAutobuyer) {
        chrome.storage.sync.set({ isRunning: false });
        chrome.action.setBadgeBackgroundColor({ color: "#000000" });
        chrome.action.setBadgeText({ text: "OFF" });
    }
    else if (request.stopAutobuyerFromPopup) {
        chrome.storage.sync.set({ isRunning: false });
        chrome.action.setBadgeBackgroundColor({ color: "#000000" });
        chrome.action.setBadgeText({ text: "OFF" });
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                stopAutobuyerFromPopup: true,
            });
        });
    }
    else if (request.alert) {
        chrome.storage.sync.get(["discordId", "discordWebhook"], function (data) {
            if (data.discordId) {
                fetch_retry("https://shortfuts-server.herokuapp.com/alert/" + data.discordId, {
                    method: "POST",
                    body: JSON.stringify({ webhook: data.discordWebhook }),
                    headers: { "Content-Type": "application/json" },
                }, 5);
            }
        });
    }
    else if (request.getRunningStatus) {
        isResponseAsync = true;
        chrome.storage.sync.get(["isRunning"], function (data) {
            sendResponse({
                isRunning: data.isRunning,
            });
        });
    }
    else if (request.log) {
        var hasLogged = window.localStorage.getItem("hasReported");
        if (!hasLogged) {
            window.localStorage.setItem("hasReported", "true");
            chrome.identity.getProfileUserInfo(function (userInfo) {
                var email = userInfo.email;
                fetch("https://shortfuts-server.herokuapp.com/log/" + email, 
                // `http://localhost:3000/log/${email}`,
                {
                    method: "GET",
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                    },
                    referrer: "no-referrer",
                });
            });
        }
    }
    else if (request.checkAccess) {
        isResponseAsync = true;
        chrome.identity.getProfileUserInfo(function (userInfo) {
            var email = userInfo.email;
            if (email) {
                try {
                    fetch("https://shortfuts-server.herokuapp.com/check-ab/" + email.toLowerCase(), {
                        method: "GET",
                        headers: {
                            Accept: "application/json",
                            "Content-Type": "application/json",
                        },
                        referrer: "no-referrer",
                    })
                        .then(function (response) { return response.json(); })
                        .then(function (jsonResponse) {
                        sendResponse({ hasAccess: jsonResponse.hasAutobuyerAccess });
                    });
                }
                catch (e) {
                    sendResponse({ hasAccess: false });
                }
            }
            else {
                sendResponse({ hasAccess: false });
            }
        });
    }
    return isResponseAsync;
});
var fetch_retry = function (url, options, n) {
    return fetch(url, options).catch(function (error) {
        if (n === 1)
            throw error;
        return fetch_retry(url, options, n - 1);
    });
};


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2V2ZW50UGFnZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUNsRkEsNkRBQTZEO0FBQzdELE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsWUFBWTtJQUNqRSxxREFBcUQ7SUFDckQsSUFBSSxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBRTVCLElBQUksT0FBTyxDQUFDLGNBQWMsRUFBRTtRQUMxQixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUU3QyxNQUFNLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDNUQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUd6QyxnQkFBVSxHQWlCUixPQUFPLFdBakJDLEVBQ1YsVUFBUSxHQWdCTixPQUFPLFNBaEJELEVBQ1IsUUFBTSxHQWVKLE9BQU8sT0FmSCxFQUNOLGVBQWEsR0FjWCxPQUFPLGNBZEksRUFDYixrQkFBZ0IsR0FhZCxPQUFPLGlCQWJPLEVBQ2hCLGdCQUFjLEdBWVosT0FBTyxlQVpLLEVBQ2QsY0FBWSxHQVdWLE9BQU8sYUFYRyxFQUNaLEtBVUUsT0FBTyxVQVZRLEVBQWpCLFdBQVMsbUJBQUcsS0FBSyxPQUNqQixZQUFVLEdBU1IsT0FBTyxXQVRDLEVBQ1YsYUFBVyxHQVFULE9BQU8sWUFSRSxFQUNYLFFBQU0sR0FPSixPQUFPLE9BUEgsRUFDTixnQkFBYyxHQU1aLE9BQU8sZUFOSyxFQUNkLG9CQUFrQixHQUtoQixPQUFPLG1CQUxTLEVBQ2xCLE1BQUksR0FJRixPQUFPLEtBSkwsRUFDSixjQUFZLEdBR1YsT0FBTyxhQUhHLEVBQ1osYUFBVyxHQUVULE9BQU8sWUFGRSxFQUNYLGNBQVksR0FDVixPQUFPLGFBREcsQ0FDRjtRQUVaLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLEVBQUUsVUFBVSxJQUFJO1lBQ3JFLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xDLGNBQWMsRUFBRSxJQUFJO2dCQUNwQixVQUFVLEVBQUUsWUFBVTtnQkFDdEIsUUFBUSxFQUFFLFVBQVE7Z0JBQ2xCLE1BQU0sRUFBRSxRQUFNO2dCQUNkLGFBQWEsRUFBRSxlQUFhO2dCQUM1QixnQkFBZ0IsRUFBRSxrQkFBZ0I7Z0JBQ2xDLGNBQWMsRUFBRSxnQkFBYztnQkFDOUIsWUFBWSxFQUFFLGNBQVk7Z0JBQzFCLFNBQVMsRUFBRSxXQUFTO2dCQUNwQixVQUFVO2dCQUNWLFdBQVc7Z0JBQ1gsTUFBTTtnQkFDTixjQUFjO2dCQUNkLGtCQUFrQjtnQkFDbEIsSUFBSTtnQkFDSixZQUFZO2dCQUNaLFdBQVc7Z0JBQ1gsWUFBWTthQUNiLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0tBQ0o7U0FBTSxJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUU7UUFDaEMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFFOUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQzVELE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7S0FDN0M7U0FBTSxJQUFJLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRTtRQUN6QyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUU5QyxNQUFNLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDNUQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUU1QyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxFQUFFLFVBQVUsSUFBSTtZQUNyRSxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO2dCQUNsQyxzQkFBc0IsRUFBRSxJQUFJO2FBQzdCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0tBQ0o7U0FBTSxJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUU7UUFDeEIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLGdCQUFnQixDQUFDLEVBQUUsVUFBQyxJQUFJO1lBQzVELElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDbEIsV0FBVyxDQUNULGtEQUFnRCxJQUFJLENBQUMsU0FBVyxFQUNoRTtvQkFDRSxNQUFNLEVBQUUsTUFBTTtvQkFDZCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7b0JBQ3RELE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxrQkFBa0IsRUFBRTtpQkFDaEQsRUFDRCxDQUFDLENBQ0YsQ0FBQzthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQUM7S0FDSjtTQUFNLElBQUksT0FBTyxDQUFDLGdCQUFnQixFQUFFO1FBQ25DLGVBQWUsR0FBRyxJQUFJLENBQUM7UUFFdkIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsVUFBQyxJQUFJO1lBQzFDLFlBQVksQ0FBQztnQkFDWCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7YUFDMUIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7S0FDSjtTQUFNLElBQUksT0FBTyxDQUFDLEdBQUcsRUFBRTtRQUN0QixJQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUU3RCxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2QsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRW5ELE1BQU0sQ0FBQyxRQUFRLENBQUMsa0JBQWtCLENBQUMsVUFBQyxRQUFRO2dCQUMxQyxJQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO2dCQUU3QixLQUFLLENBQ0gsZ0RBQThDLEtBQU87Z0JBQ3JELHdDQUF3QztnQkFDeEM7b0JBQ0UsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsT0FBTyxFQUFFO3dCQUNQLE1BQU0sRUFBRSxrQkFBa0I7d0JBQzFCLGNBQWMsRUFBRSxrQkFBa0I7cUJBQ25DO29CQUNELFFBQVEsRUFBRSxhQUFhO2lCQUN4QixDQUNGLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztTQUNKO0tBQ0Y7U0FBTSxJQUFJLE9BQU8sQ0FBQyxXQUFXLEVBQUU7UUFDOUIsZUFBZSxHQUFHLElBQUksQ0FBQztRQUV2QixNQUFNLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLFVBQUMsUUFBUTtZQUMxQyxJQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO1lBRTdCLElBQUksS0FBSyxFQUFFO2dCQUNULElBQUk7b0JBQ0YsS0FBSyxDQUNILHFEQUFtRCxLQUFLLENBQUMsV0FBVyxFQUFJLEVBQ3hFO3dCQUNFLE1BQU0sRUFBRSxLQUFLO3dCQUNiLE9BQU8sRUFBRTs0QkFDUCxNQUFNLEVBQUUsa0JBQWtCOzRCQUMxQixjQUFjLEVBQUUsa0JBQWtCO3lCQUNuQzt3QkFDRCxRQUFRLEVBQUUsYUFBYTtxQkFDeEIsQ0FDRjt5QkFDRSxJQUFJLENBQUMsVUFBQyxRQUFRLElBQUssZUFBUSxDQUFDLElBQUksRUFBRSxFQUFmLENBQWUsQ0FBQzt5QkFDbkMsSUFBSSxDQUFDLFVBQUMsWUFBWTt3QkFDakIsWUFBWSxDQUFDLEVBQUUsU0FBUyxFQUFFLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLENBQUM7b0JBQy9ELENBQUMsQ0FBQyxDQUFDO2lCQUNOO2dCQUFDLE9BQU8sQ0FBQyxFQUFFO29CQUNWLFlBQVksQ0FBQyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO2lCQUNwQzthQUNGO2lCQUFNO2dCQUNMLFlBQVksQ0FBQyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO2FBQ3BDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7S0FDSjtJQUVELE9BQU8sZUFBZSxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDO0FBRUgsSUFBTSxXQUFXLEdBQUcsVUFBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUM7SUFDbEMsWUFBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxLQUFLO1FBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUM7WUFBRSxNQUFNLEtBQUssQ0FBQztRQUN6QixPQUFPLFdBQVcsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUMxQyxDQUFDLENBQUM7QUFIRixDQUdFLENBQUMiLCJmaWxlIjoiZXZlbnRQYWdlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9zcmMvZXZlbnRQYWdlLnRzXCIpO1xuIiwiLy8gTGlzdGVuIHRvIG1lc3NhZ2VzIHNlbnQgZnJvbSBvdGhlciBwYXJ0cyBvZiB0aGUgZXh0ZW5zaW9uLlxuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChyZXF1ZXN0LCBzZW5kZXIsIHNlbmRSZXNwb25zZSkgPT4ge1xuICAvLyBvbk1lc3NhZ2UgbXVzdCByZXR1cm4gXCJ0cnVlXCIgaWYgcmVzcG9uc2UgaXMgYXN5bmMuXG4gIGxldCBpc1Jlc3BvbnNlQXN5bmMgPSBmYWxzZTtcblxuICBpZiAocmVxdWVzdC5zdGFydEF1dG9idXllcikge1xuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuc2V0KHsgaXNSdW5uaW5nOiB0cnVlIH0pO1xuXG4gICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZUJhY2tncm91bmRDb2xvcih7IGNvbG9yOiBcIiMwMDAwMDBcIiB9KTtcbiAgICBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6IFwiT05cIiB9KTtcblxuICAgIGNvbnN0IHtcbiAgICAgIHJlc2V0UG9pbnQsXG4gICAgICBkdXJhdGlvbixcbiAgICAgIGFjdGlvbixcbiAgICAgIGl0ZXJhdGlvblRpbWUsXG4gICAgICBpdGVyYXRpb25UaW1lTWF4LFxuICAgICAgbGlzdFN0YXJ0UHJpY2UsXG4gICAgICBsaXN0QmluUHJpY2UsXG4gICAgICBpc1Rlc3RSdW4gPSBmYWxzZSxcbiAgICAgIG9uSW50ZXJ2YWwsXG4gICAgICBvZmZJbnRlcnZhbCxcbiAgICAgIGN5Y2xlcyxcbiAgICAgIG1heEJ1eU5vd1ByaWNlLFxuICAgICAgbWluaW11bUNvaW5CYWxhbmNlLFxuICAgICAgbW9kZSxcbiAgICAgIG1heEJpZEFtb3VudCxcbiAgICAgIGJpZER1cmF0aW9uLFxuICAgICAgc2hvdWxkQmlkTWF4LFxuICAgIH0gPSByZXF1ZXN0O1xuXG4gICAgY2hyb21lLnRhYnMucXVlcnkoeyBhY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWUgfSwgZnVuY3Rpb24gKHRhYnMpIHtcbiAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYnNbMF0uaWQsIHtcbiAgICAgICAgc3RhcnRBdXRvYnV5ZXI6IHRydWUsXG4gICAgICAgIHJlc2V0UG9pbnQ6IHJlc2V0UG9pbnQsXG4gICAgICAgIGR1cmF0aW9uOiBkdXJhdGlvbixcbiAgICAgICAgYWN0aW9uOiBhY3Rpb24sXG4gICAgICAgIGl0ZXJhdGlvblRpbWU6IGl0ZXJhdGlvblRpbWUsXG4gICAgICAgIGl0ZXJhdGlvblRpbWVNYXg6IGl0ZXJhdGlvblRpbWVNYXgsXG4gICAgICAgIGxpc3RTdGFydFByaWNlOiBsaXN0U3RhcnRQcmljZSxcbiAgICAgICAgbGlzdEJpblByaWNlOiBsaXN0QmluUHJpY2UsXG4gICAgICAgIGlzVGVzdFJ1bjogaXNUZXN0UnVuLFxuICAgICAgICBvbkludGVydmFsLFxuICAgICAgICBvZmZJbnRlcnZhbCxcbiAgICAgICAgY3ljbGVzLFxuICAgICAgICBtYXhCdXlOb3dQcmljZSxcbiAgICAgICAgbWluaW11bUNvaW5CYWxhbmNlLFxuICAgICAgICBtb2RlLFxuICAgICAgICBtYXhCaWRBbW91bnQsXG4gICAgICAgIGJpZER1cmF0aW9uLFxuICAgICAgICBzaG91bGRCaWRNYXgsXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSBlbHNlIGlmIChyZXF1ZXN0LnN0b3BBdXRvYnV5ZXIpIHtcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLnNldCh7IGlzUnVubmluZzogZmFsc2UgfSk7XG5cbiAgICBjaHJvbWUuYWN0aW9uLnNldEJhZGdlQmFja2dyb3VuZENvbG9yKHsgY29sb3I6IFwiIzAwMDAwMFwiIH0pO1xuICAgIGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dDogXCJPRkZcIiB9KTtcbiAgfSBlbHNlIGlmIChyZXF1ZXN0LnN0b3BBdXRvYnV5ZXJGcm9tUG9wdXApIHtcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLnNldCh7IGlzUnVubmluZzogZmFsc2UgfSk7XG5cbiAgICBjaHJvbWUuYWN0aW9uLnNldEJhZGdlQmFja2dyb3VuZENvbG9yKHsgY29sb3I6IFwiIzAwMDAwMFwiIH0pO1xuICAgIGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dDogXCJPRkZcIiB9KTtcblxuICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0sIGZ1bmN0aW9uICh0YWJzKSB7XG4gICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWJzWzBdLmlkLCB7XG4gICAgICAgIHN0b3BBdXRvYnV5ZXJGcm9tUG9wdXA6IHRydWUsXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSBlbHNlIGlmIChyZXF1ZXN0LmFsZXJ0KSB7XG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoW1wiZGlzY29yZElkXCIsIFwiZGlzY29yZFdlYmhvb2tcIl0sIChkYXRhKSA9PiB7XG4gICAgICBpZiAoZGF0YS5kaXNjb3JkSWQpIHtcbiAgICAgICAgZmV0Y2hfcmV0cnkoXG4gICAgICAgICAgYGh0dHBzOi8vc2hvcnRmdXRzLXNlcnZlci5oZXJva3VhcHAuY29tL2FsZXJ0LyR7ZGF0YS5kaXNjb3JkSWR9YCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyB3ZWJob29rOiBkYXRhLmRpc2NvcmRXZWJob29rIH0pLFxuICAgICAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgNVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0pO1xuICB9IGVsc2UgaWYgKHJlcXVlc3QuZ2V0UnVubmluZ1N0YXR1cykge1xuICAgIGlzUmVzcG9uc2VBc3luYyA9IHRydWU7XG5cbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldChbXCJpc1J1bm5pbmdcIl0sIChkYXRhKSA9PiB7XG4gICAgICBzZW5kUmVzcG9uc2Uoe1xuICAgICAgICBpc1J1bm5pbmc6IGRhdGEuaXNSdW5uaW5nLFxuICAgICAgfSk7XG4gICAgfSk7XG4gIH0gZWxzZSBpZiAocmVxdWVzdC5sb2cpIHtcbiAgICBjb25zdCBoYXNMb2dnZWQgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJoYXNSZXBvcnRlZFwiKTtcblxuICAgIGlmICghaGFzTG9nZ2VkKSB7XG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJoYXNSZXBvcnRlZFwiLCBcInRydWVcIik7XG5cbiAgICAgIGNocm9tZS5pZGVudGl0eS5nZXRQcm9maWxlVXNlckluZm8oKHVzZXJJbmZvKSA9PiB7XG4gICAgICAgIGNvbnN0IGVtYWlsID0gdXNlckluZm8uZW1haWw7XG5cbiAgICAgICAgZmV0Y2goXG4gICAgICAgICAgYGh0dHBzOi8vc2hvcnRmdXRzLXNlcnZlci5oZXJva3VhcHAuY29tL2xvZy8ke2VtYWlsfWAsXG4gICAgICAgICAgLy8gYGh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9sb2cvJHtlbWFpbH1gLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIG1ldGhvZDogXCJHRVRcIixcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVmZXJyZXI6IFwibm8tcmVmZXJyZXJcIixcbiAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0gZWxzZSBpZiAocmVxdWVzdC5jaGVja0FjY2Vzcykge1xuICAgIGlzUmVzcG9uc2VBc3luYyA9IHRydWU7XG5cbiAgICBjaHJvbWUuaWRlbnRpdHkuZ2V0UHJvZmlsZVVzZXJJbmZvKCh1c2VySW5mbykgPT4ge1xuICAgICAgY29uc3QgZW1haWwgPSB1c2VySW5mby5lbWFpbDtcblxuICAgICAgaWYgKGVtYWlsKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgZmV0Y2goXG4gICAgICAgICAgICBgaHR0cHM6Ly9zaG9ydGZ1dHMtc2VydmVyLmhlcm9rdWFwcC5jb20vY2hlY2stYWIvJHtlbWFpbC50b0xvd2VyQ2FzZSgpfWAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG1ldGhvZDogXCJHRVRcIixcbiAgICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHJlZmVycmVyOiBcIm5vLXJlZmVycmVyXCIsXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiByZXNwb25zZS5qc29uKCkpXG4gICAgICAgICAgICAudGhlbigoanNvblJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7IGhhc0FjY2VzczoganNvblJlc3BvbnNlLmhhc0F1dG9idXllckFjY2VzcyB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgc2VuZFJlc3BvbnNlKHsgaGFzQWNjZXNzOiBmYWxzZSB9KTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgaGFzQWNjZXNzOiBmYWxzZSB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHJldHVybiBpc1Jlc3BvbnNlQXN5bmM7XG59KTtcblxuY29uc3QgZmV0Y2hfcmV0cnkgPSAodXJsLCBvcHRpb25zLCBuKSA9PlxuICBmZXRjaCh1cmwsIG9wdGlvbnMpLmNhdGNoKGZ1bmN0aW9uIChlcnJvcikge1xuICAgIGlmIChuID09PSAxKSB0aHJvdyBlcnJvcjtcbiAgICByZXR1cm4gZmV0Y2hfcmV0cnkodXJsLCBvcHRpb25zLCBuIC0gMSk7XG4gIH0pO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==