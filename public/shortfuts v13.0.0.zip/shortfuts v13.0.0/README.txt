Because Google's terribly slow review process, I've made this version of shortfuts available for you to install temporarily until the official version is available in the Chrome Web Store. I'm doing this as a courtesy so you don't miss out on any day 1 deals of the new FUT season.

1. Go to chrome://extensions in Google Chrome.
2. Toggle on the "Developer mode" toggle in the upper-right of the page.
3. Click the "Load unpacked" button in the upper-left of the page.
4. Navigate to the "app" folder you downloaded from my Google Drive and click "Select Folder" to load it.
5. Disable the official version of shortfuts in the meantime so they don't collide.

This version is TEMPORARY and it's much better to use the official version to ensure you get updates. You'll be reminded every time you load the web app of this fact, and that you should keep a close eye on the Discord (http://bit.ly/sf-discord) for an announcement when the official version has been updated.
