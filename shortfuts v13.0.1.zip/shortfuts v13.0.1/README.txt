Because Google's terribly slow review process, I've made this version of shortfuts available for you to install temporarily until the official version is available in the Chrome Web Store.

1. Go to chrome://extensions in Google Chrome.
2. Toggle on the "Developer mode" toggle in the upper-right of the page.
3. Click the "Load unpacked" button in the upper-left of the page.
4. Navigate to the "app" folder you downloaded and click "Select Folder" to load it.
5. Disable the official version of shortfuts in the meantime so they don't collide.

This version is TEMPORARY and it's much better to use the official version to ensure you get updates. You should keep a close eye on the Discord (http://bit.ly/sf-discord) for an announcement when the official version has been updated.

This version will stop working on September 25.
